package hr.fer.zemris.java.custom.collections;

/**This class represents processor with single method, process, which
 * does something on given Object.
 * 
 * @author Ivona
 *
 */
public interface Processor<T> {
	public void process(T value);
}
