package hr.fer.zemris.java.custom.collections;

import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * This class represents implementation of Map. A hash table uses a hash
 * function to compute an index into an array of slots, from which the desired
 * value can be found. The hash function will assign each key to a unique slot.
 * 
 * @author Ivona
 *
 * @param <K> Key type
 * @param <V> Value Type
 */
public class SimpleHashtable<K, V> implements Iterable<SimpleHashtable.TableEntry<K, V>> {

	/**
	 * Table of slots of the table
	 */
	TableEntry<K, V>[] table;

	/**
	 * This variable represents number of modifications which are done on the
	 * HashTable
	 */
	private int modificationCount = 0;

	/**
	 * Number of pairs (key, value) in HasTable
	 */
	int size = 0;

	/**
	 * Size of table - number of slots
	 */
	int numberOfSlots;

	/**
	 * This class represents implementation of basic unit of SimpleHashtable.
	 * TableEntry consists of the Key, Value and Next.
	 * 
	 * @author Ivona
	 *
	 * @param <K> Type of key
	 * @param <V> Type of Value
	 */
	public static class TableEntry<K, V> {

		/**
		 * Key of TableEntry
		 */
		private K key;

		/**
		 * Value of TableEntry
		 */
		private V value;

		/**
		 * It refers to next unit TableEntry which is placed in the same slot of the
		 * table
		 */
		TableEntry<K, V> next;

		/**
		 * Basic constructor
		 * 
		 * @param key   Key of TableEntry
		 * @param value Value of TableEntry
		 */
		public TableEntry(K key, V value) {

			this.key = key;
			this.value = value;
		}

		/**
		 * Constructor
		 * 
		 * @param key   Key of TableEntry
		 * @param value Value of TableEntry
		 * @param next  Reference to the next TableEntry in the same slot of the tablee
		 */
		public TableEntry(K key, V value, TableEntry<K, V> next) {

			this.key = key;
			this.value = value;
			this.next = next;
		}

		/**
		 * Getter for next
		 * 
		 * @return Next
		 */
		public TableEntry<K, V> getNext() {
			return next;
		}

		/**
		 * Getter for Key
		 * 
		 * @return key of TableEntry
		 */
		public K getKey() {
			return key;
		}

		/**
		 * Getter for Value
		 * 
		 * @return value of TableEntry
		 */
		public V getValue() {
			return value;
		}



		@Override
		public int hashCode() {
			return Objects.hash(key, next, value);
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (!(obj instanceof TableEntry))
				return false;
			@SuppressWarnings("rawtypes")
			TableEntry other = (TableEntry) obj;
			return Objects.equals(key, other.key) && Objects.equals(next, other.next)
					&& Objects.equals(value, other.value);
		}

	}

	/**
	 * This method checks if the number is the power of 2.
	 * 
	 * @param n Number to check if it is the power of 2
	 * @return <code>true</code> if n is the power of 2, otherwise false
	 */
	static boolean isPowerOfTwo(int n) {
		return (int) (Math.ceil((Math.log(n) / Math.log(2)))) == (int) (Math.floor(((Math.log(n) / Math.log(2)))));
	}

	/**
	 * Constructor of SimpleHashtable class whose input is number of slots of the
	 * table.
	 * 
	 * @param numberOfSlots Number of slots of the table
	 * @throws IllegalArgumentException if numberOfSlots is less than 1
	 */
	@SuppressWarnings("unchecked")
	public SimpleHashtable(int numberOfSlots) {
		if (numberOfSlots < 1) {
			throw new IllegalArgumentException("Capacity could not be less than 1.");
		}

		for (int i = numberOfSlots;; i++) {
			if (isPowerOfTwo(i) == true) {
				this.numberOfSlots = i;
				table = new TableEntry[numberOfSlots];
				break;
			}
		}

		for (int i = 0; i < numberOfSlots; i++)
			table[i] = null;

	}

	/**
	 * Basic constructor which takes number of Slots equals 16.
	 */
	public SimpleHashtable() {
		this(16);
		/*numberOfSlots = 16;
		table = new TableEntry[numberOfSlots];
		for (int i = 0; i < numberOfSlots; i++)
			table[i] = null;
			*/
	}

	/**
	 * Hash function which uniquely determines in which slot the pair with the key
	 * Key will be placed.
	 * 
	 * @param key Key of the pair
	 * @return Slot in which the pair will be placed.
	 */
	private int hash(K key) {
		return Math.abs(key.hashCode() % numberOfSlots);
	}

	/**
	 * This method gets the Value of TableEntry whose key equals Key. It is legal
	 * for the input key to be null because that key does not even exist in the
	 * table; method returns null.
	 * 
	 * @param key The key of TableEntry
	 * @return Value of pair with the key if that one exists; otherwise null
	 * 
	 */
	public V get(K key) {
		if (key == null) {
			return null;
		}
		TableEntry<K, V> current = table[hash(key)];
		while (current != null) {
			if (current.getKey().equals(key)) {
				return (V) current.getValue();
			}
			current = current.next;
		}

		return null;
	}

	/**
	 * This method adds the pair (key, value) to the map if there is no pair with
	 * the key equals Key. Otherwise, if there is already pair with that key, this
	 * method only overwrites the value.
	 * 
	 * @param key   Key of the pair
	 * @param value Value of the pair
	 * 
	 * @throws NullPointerException if key equals null.
	 */
	@SuppressWarnings("unchecked")
	public void put(K key, V value) {

		if (key == null) {
			throw new NullPointerException("Key cannot be null");
		}
		int index = hash((K) key);

		TableEntry<K, V> entry = table[index];

		if (entry == null) {
			modificationCount++;
			table[index] = new TableEntry<K, V>(key, value);
			size++;
			return;
		}

		while (entry != null) {
			if (entry.getKey().equals(key)) {
				entry.value = value;
				return;
			}
			entry = entry.next;
		}

		modificationCount++;
		// we have to add new pair
		entry = table[index];
		while (entry.next != null)
			entry = entry.next;

		entry.next = new TableEntry<K, V>(key, value);
		size++;

		int newSize = size;

		// System.out.println("Velicina: size = " + size);

		// modification, 4b.
		if ((1.0 * size) / this.numberOfSlots >= 0.75) {
			TableEntry<K, V>[] template = table;
			table = new TableEntry[2 * this.numberOfSlots];
			this.numberOfSlots *= 2;
			// System.out.println("Velicina: slotovi = " + this.numberOfSlots);

			// size = 0;
			for (int i = 0; i < numberOfSlots; i++)
				table[i] = null;

			for (TableEntry<K, V> iterator : template) {
				while (iterator != null) {
					this.put(iterator.key, iterator.value);
					this.size--;
					iterator = iterator.next;
				}
			}
			size = newSize;
		}
		return;
	}

	/**
	 * This method returns number of pairs in the table.
	 * 
	 * @return Number of pairs
	 */
	public int size() {
		return size;
	}

	/**
	 * This method determines if there is a pair with input key in the map. If the
	 * input key equals null, method should return false because that key does not
	 * exist.
	 * 
	 * @param key Key of the pair
	 * @return <code>true</code> if there is pair with the input key; otherwise
	 *         <code>false</code>
	 *
	 */
	public boolean containsKey(Object key) {
		if (key == null) {
			return false;
		}
		try {
			@SuppressWarnings("unchecked")
			TableEntry<K, V> current = table[hash((K) key)];
			while (current != null) {
				if (current.getKey().equals(key)) {
					return true;
				}
				current = current.next;
			}

		} catch (IllegalArgumentException ex) {
			System.out.println("No valid type of key.");
		}

		return false;
	}

	/**
	 * This method determines if there is a pair whose Value equals input value.
	 * Value is allowed to be null.
	 * 
	 * @param value Value of the desired pair
	 * @return <code>true</code> if there is pair with the input value;
	 *         <code>false</code> otherwise.
	 */
	public boolean containsValue(Object value) {
		for (int i = 0; i < numberOfSlots; ++i) {
			TableEntry<K, V> entry = table[i];
			while (entry != null) {
				if (entry.getValue().equals(value)) {
					return true;
				}
				entry = entry.next;
			}
		}
		return false;
	}

	/**
	 * This method removes the pair with input key from the map if that one exists.
	 * If the key equals null, this method works nothing because that key does not
	 * even exist.
	 * 
	 * @param key Key of the pair wanted to be removed.
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void remove(Object key) {
		if (key == null) {
			return;
		}

		int index = hash((K) key);
		TableEntry<K, V> current = table[index];

		if (current == null) {
			return;
		}

		// remove first node
		if (current.getKey().equals(key)) {
			table[hash((K) key)] = current.next;
			modificationCount++;
			size--;
			return;
		}

		while (current.next != null) {
			if (current.next.getKey().equals(key)) {
				current.next = current.next.next;
				size--;
				modificationCount++;
			}
		}

	}

	/**
	 * This method determines if the map is empty.
	 * 
	 * @return <code>true</code> if table is empty; <code>false</code> otherwise.
	 */
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public String toString() {

		String string = "[";
		for (int i = 0; i < numberOfSlots; i++) {
			TableEntry<K, V> current = table[i];
			if (current == null) {
				continue;
			}
			if (i != 0 && current != table[i] && current.next != null) {
				string += ", ";
			}
			while (current.next != null) {
				string += (current.getKey() + "=" + current.getValue() + ", ");
				current = current.next;
			}
			string += (current.getKey() + "=" + current.getValue());
			for (int j = i + 1; j < numberOfSlots; j++)
				if (table[j] != null) {
					string += ", ";
					break;
				}
		}
		string += "]";

		return string;
	}

	/**
	 * This method deletes each pair from the map.
	 */
	public void clear() {
		for (int i = 0; i < numberOfSlots; i++) {
			table[i] = null;
		}
		size = 0;

	}

	/**
	 * This class implements Iterator whose task is to work directly over the table
	 * with open adrressing. It is not allowed to iterator to copy content of the
	 * table to the other structure; it has to work directly on the table.
	 * 
	 * @author Ivona
	 *
	 */
	private class IteratorImpl implements Iterator<SimpleHashtable.TableEntry<K, V>> {

		/**
		 * Index of current slot.
		 */
		private int index = 0;

		/**
		 * This variable modification controls modification of the map. At the moment of
		 * making Iterator, it equals modificationCount from the SimpleHashtable. In
		 * every method of the class IteratorImpl the equality of these 2 variables has
		 * to be checked. If they are not equal, there is some sort of exception.
		 */
		private int modification = modificationCount;

		/**
		 * This variable determines if the method {@link remove()} is already called on
		 * currentEntry. It equals 0 if it has not been called on currentEntry, 1 if it
		 * has been.
		 */
		private int removedCurrent = 0;

		/**
		 * Iterator is placed on TableEntry called currentEntry at the moment. It
		 * belongs to the slot with index {@linkplain index}
		 */
		private TableEntry<K, V> currentEntry;

		/**
		 * Next TableEntry the Iterator will return to the user.
		 */
		private TableEntry<K, V> nextEntry;

		/**
		 * Constructor.
		 */
		public IteratorImpl() {

			currentEntry = null;
			nextEntry = null;

			for (; index < table.length; index++) {
				if (table[index] != null) {
					nextEntry = table[index];
					break;
				}
			}

		}

		@Override
		public boolean hasNext() {

			if (modification != modificationCount) {
				throw new ConcurrentModificationException("Modifications on.s");
			}
			return nextEntry != null ? true : false;
		}

		@Override
		public SimpleHashtable.TableEntry<K, V> next() {

			if (!hasNext()) {
				throw new NoSuchElementException("No more elements.");
			}

			currentEntry = nextEntry;

			nextEntry = null;
			if (currentEntry.next != null) {
				nextEntry = currentEntry.next;
				// System.out.println(currentEntry.getKey());
				removedCurrent = 0;
				return currentEntry;
			}

			if (nextEntry == null) {
				// jump to new index
				for (int j = index + 1; j < table.length; j++) {
					if (table[j] != null) {
						nextEntry = table[j];
						index = j;
						break;
					}
				}

			}
			// System.out.println(currentEntry.getKey());
			removedCurrent = 0;
			return currentEntry;

		}

		@Override
		public void remove() {
			// modificationCount++; modification increases during the call of method
			// remove()
			modification++;
			removedCurrent++;
			if (removedCurrent > 1) {
				throw new IllegalStateException("Two or more calls of remove on current pair.");
			}
			SimpleHashtable.this.remove(currentEntry.getKey());
		}

	}

	/**
	 * This method creates new Iterator for the map.
	 * 
	 * @return IteratorImp which implements Iterator
	 */
	private Iterator<TableEntry<K, V>> giveIterator() {
		return new IteratorImpl();
	}

	@Override
	public java.util.Iterator<TableEntry<K, V>> iterator() {
		return giveIterator();
	}

}