package hr.fer.zemris.java.custom.collections;

/**
 * This class represents object stack. It uses {@link ArrayIndexedCollection}
 * for storing elements.
 * 
 * @author Ivona
 */
public class ObjectStack<T> {

	/**
	 * Collection in which elements will be stored.
	 */
	private ArrayIndexedCollection<T> array;

	/**
	 * Basic constructor.
	 */
	public ObjectStack() {
		array = new ArrayIndexedCollection<T>();
	}

	/**
	 * This method checks if stack is empty.
	 *
	 * @return <code>true</code> if stack is empty, false otherwise
	 */
	public boolean isEmpty() {
		return array.isEmpty();
	}

	/**
	 * This method returns size of stack.
	 *
	 * @return Size of stack.
	 */
	public int size() {
		return array.size();
	}

	/**
	 * This method is used for pushing elements to stack.
	 *
	 * @param value Element that will be pushed to stack
	 */
	public void push(T value) {
		if (value.equals(null)) {
			throw new NullPointerException("Null is not allowed to be pushed to stack!");
		}

		array.add(value);
	}

	/**
	 * This method is used for popping elements from stack.
	 *
	 * @return Popped element
	 */
	public Object pop() {
		if (this.isEmpty()) {
			throw new hr.fer.zemris.java.custom.collections.EmptyStackException("Stack is empty!");
		}

		Object element = array.get(size() - 1);
		array.remove(size() - 1);
		return element;

	}

	/**
	 * This method is used for peeking elements from stack.
	 *
	 * @return Peeked element
	 */
	public Object peek() {
		if (this.isEmpty()) {
			throw new hr.fer.zemris.java.custom.collections.EmptyStackException("Stack je prazan.");
		}

		return array.get(size() - 1);
	}

	/**
	 * This method is used for clearing stack.
	 */
	public void clear() {
		array.clear();
	}
}
