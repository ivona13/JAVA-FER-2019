package hr.fer.zemris.java.custom.collection;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.collections.LinkedListIndexedCollection;
import hr.fer.zemris.java.custom.collections.Processor;


class ArrayTest {

	LinkedListIndexedCollection<String> other;
	LinkedListIndexedCollection<String> collection = new LinkedListIndexedCollection<String>();

	@Test
	public void constructor1Test() {
		LinkedListIndexedCollection<String> collection = new LinkedListIndexedCollection<String>();
		assertEquals(0, collection.size());
	}

	@Test
	public void addTest() {

		collection.add("13");
		collection.add("Ivona");
		collection.add("java");
		
		Object[] array = collection.toArray();

		assertEquals("13", array[0]);
		assertTrue("Ivona".equals(array[1]));
		assertTrue("java".equals(array[2]));

	}

	@Test
	public void constructor2Test() {

		collection.add("13");
		collection.add("Ivona");
		collection.add("java");

		LinkedListIndexedCollection<String> other = new LinkedListIndexedCollection<String>(collection);
		Object[] array = other.toArray();

		assertEquals("13", array[0]);
		assertTrue("Ivona".equals(array[1]));
		assertTrue("java".equals(array[2]));
	}

	@Test
	public void getTest() {

		collection.add("42");
		assertTrue(collection.get(0).equals("42"));

		boolean isOut = true;
		try {
			collection.get(42);
		} catch (IndexOutOfBoundsException ex) {
			isOut = false;
		}
		assertEquals(false, isOut);
	}

	@Test
	public void insertTest() {
		collection.add("13");
		collection.insert("Ivona", 0);
		collection.insert("java", 1);

		Object[] array = collection.toArray();

		assertEquals("Ivona", array[0]);
		assertTrue("java".equals(array[1]));
		assertTrue("13".equals(array[2]));

	}

	@Test
	public void toArrayTest() {
		collection.add("1");
		collection.add("2");
		collection.add("3");

		Object[] array = collection.toArray();

		assertEquals("1", array[0]);
		assertEquals("2", array[1]);
		assertEquals("3", array[2]);
	}

	@Test
	public void indexOfTest() {
		collection.add("13");
		collection.insert("Ivona", 0);
		assertEquals(0, collection.indexOf("Ivona"));
		assertEquals(-1, collection.indexOf("nešto"));

	}

	@Test
	public void removeTest() {
		collection.add("13");
		collection.insert("Ivona", 0);

		// remove(index)
		collection.remove(1);


		// remove(Object)
		collection.insert("nešto", 0);
		collection.insert("ivona", 1);
		assertEquals(true, collection.remove("nešto"));
		assertEquals(0, collection.indexOf("ivona") );
		assertEquals(true, collection.remove("ivona"));

	}

	@Test
	public void sizeTest() {
		collection.add("nešto");
		collection.add("još nešto");

		assertEquals(2, collection.size());
	}

	@Test
	public void containsTest() {
		collection.add("13");

		assertTrue(collection.contains("13"));
		assertTrue(!collection.contains(70));

	}

	@Test
	public void clearTest() {
		collection.add("13");
		collection.clear();
		assertEquals(0, collection.size());
	}

	@Test
	public void forEachTest() {
		class TestProcessor<T> implements Processor<T> {
			int i = 0;

			@Override
			public void process(Object value) {
				i += 2;
			}
		}

		collection.add("13");
		collection.add("13");

		TestProcessor<String> testProcessor = new TestProcessor<String>();
		collection.forEach(testProcessor);
		assertEquals(4, testProcessor.i);

	}

}