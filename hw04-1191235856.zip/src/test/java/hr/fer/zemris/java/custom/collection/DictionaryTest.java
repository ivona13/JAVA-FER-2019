package hr.fer.zemris.java.custom.collection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.collections.ArrayIndexedCollection;
import hr.fer.zemris.java.custom.collections.Dictionary;

public class DictionaryTest {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Test
	public void constructorTest() {

		class KeyValue<K, V> {
			
			@SuppressWarnings("unused")
			private K key;

			@SuppressWarnings("unused")
			private V value;

			public KeyValue(K key, V value) {
				this.key = key;
				this.value = value;
			}

		}
		KeyValue<String, String> object1 = new KeyValue("Ivona", "13");
		KeyValue<String, String> object2 = new KeyValue("FER", "java");

		ArrayIndexedCollection<KeyValue<String, String>> array = new ArrayIndexedCollection<KeyValue<String, String>>();
		array.add(object1);
		array.add(object2);
		Dictionary<String, String> dictionary = new Dictionary(array);
		assertEquals(2, dictionary.size());
	}

	@Test
	public void isEmptyTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		assertTrue(dictionary.isEmpty());
	}

	@Test
	public void sizeTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		assertEquals(0, dictionary.size());
		dictionary.put("Ivona", "13");
		assertEquals(1, dictionary.size());
		dictionary.put("FER", "Java");
		assertEquals(2, dictionary.size());

	}

	@Test
	public void putNewTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		assertEquals(2, dictionary.size());
		assertEquals("java", dictionary.get("Ivona"));
		assertEquals("fer", dictionary.get("13"));
		
	}

	@Test
	public void clearTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		assertEquals(2, dictionary.size());
		dictionary.clear();
		assertEquals(0, dictionary.size());

	}

	@Test
	public void putExistingTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		assertEquals(2, dictionary.size());

	}

	@Test
	public void putOverExistingTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		dictionary.put("13", "nov1");
		dictionary.put("13", "nov02");
		dictionary.put("Ivona", "java2");

		assertEquals(2, dictionary.size());
		assertEquals("nov02", dictionary.get("13"));
		assertEquals("java2", dictionary.get("Ivona"));

	}

	@Test
	public void getTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		assertEquals("java", dictionary.get("Ivona"));
		assertEquals("fer", dictionary.get("13"));

	}

	@Test
	public void getOverExistringTest() {
		Dictionary<String, String> dictionary = new Dictionary<String, String>();
		dictionary.put("Ivona", "java");
		dictionary.put("13", "fer");
		dictionary.put("Ivona", "Ivona");
		assertEquals("Ivona", "Ivona");

	}

}
