package hr.fer.zemris.java.custom.collection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.collections.SimpleHashtable;

public class SimpleHashtableTest {

	@Test
	public void constructor1Test() {
		SimpleHashtable<String, Integer> table = new SimpleHashtable<>();
		assertEquals(0, table.size());
		assertTrue(table.isEmpty());
	}

	@Test
	public void putTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);

		assertEquals(5, examMarks.get("Ivana"));
		assertEquals(2, examMarks.get("Ante"));
		assertEquals(2, examMarks.get("Jasna"));
		assertEquals(5, examMarks.get("Kristina"));
		assertEquals(4, examMarks.size());

	}

	@Test
	public void getNullPointerException() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();

		assertThrows(NullPointerException.class, () -> examMarks.put(null, 4));
	}

	@Test
	public void getValueTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);

		assertEquals(5, examMarks.get("Ivana"));
		assertEquals(2, examMarks.get("Ante"));
		assertEquals(null, examMarks.get("Mario"));
		assertEquals(null, examMarks.get("4"));

	}

	public void sizeTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		assertEquals(2, examMarks.size());

		examMarks.put("Ivona", 5);
		assertEquals(3, examMarks.size());

		examMarks.put("Ivona", 10);
		assertEquals(3, examMarks.size());
		
		examMarks.put("Marko", 10);
		assertEquals(4, examMarks.size());
	}

	public void containKeyTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);

		assertTrue(examMarks.containsKey("Ivana"));
		assertEquals(false, examMarks.get("Ana"));

	}

	@Test
	public void containsValueTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);

		assertTrue(examMarks.containsValue(2));
		assertEquals(false, examMarks.containsValue("Ivona"));
		assertEquals(false, examMarks.containsValue(null));

	}

	@Test
	public void removeTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Ana", 4);
		examMarks.put("Ivona", 13);

		assertEquals(4, examMarks.size());

		examMarks.remove("Ivana");
		assertEquals(3, examMarks.size());

		examMarks.remove("Miaa");
		assertEquals(3, examMarks.size());

		examMarks.remove(null);
		assertEquals(3, examMarks.size());

		examMarks.remove(8);
		assertEquals(3, examMarks.size());
		

	}

	@Test
	public void isEmptyTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>();
		
		assertEquals(true, examMarks.isEmpty());

		examMarks.put("Ivana", 2);
		assertEquals(false, examMarks.isEmpty());

		examMarks.put("Ante", 2);
		assertEquals(false, examMarks.isEmpty());

		examMarks.put("Ana", 4);
		assertEquals(false, examMarks.isEmpty());


	}

	@Test
	public void toStringTest() {

		SimpleHashtable<String, String> empty = new SimpleHashtable<>();

		String emptyTable = "[]";
		assertEquals(emptyTable, empty.toString());

		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);

		// System.out.println(examMarks.toString());
		String string = "[Ante=2, Ivana=5, Jasna=2, Kristina=5]";
		assertEquals(string, examMarks.toString());
		
		SimpleHashtable<Integer, Integer> number = new SimpleHashtable<>(2);
		number.put(2, 4);
		number.put(8, -5);
		number.put(13, 4);
		number.put(-2, -8);

		string = "[8=-5, 2=4, -2=-8, 13=4]";
		//System.out.println(number.toString());
		assertEquals(string, number.toString());

		
	}

	@Test
	public void clearTest() {
		SimpleHashtable<String, Integer> examMarks = new SimpleHashtable<>(2);
		examMarks.put("Ivana", 2);
		examMarks.put("Ante", 2);
		examMarks.put("Jasna", 2);
		examMarks.put("Kristina", 5);
		examMarks.put("Ivana", 5);

		assertEquals(4, examMarks.size());

		examMarks.clear();
		
		assertEquals(0, examMarks.size());
		assertEquals(true, examMarks.isEmpty());


	}
}
