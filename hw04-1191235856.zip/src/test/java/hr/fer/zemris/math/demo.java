package hr.fer.zemris.math;

public class demo {
	public static void main(String[] args) {

		Vector2D vector = new Vector2D(-3, -3);

		vector.rotate(Math.PI);
		System.out.printf("%f\n", vector.getX());
		System.out.printf("%f", vector.getY());

	}
}
