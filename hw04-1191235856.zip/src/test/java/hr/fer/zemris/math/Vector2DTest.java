package hr.fer.zemris.math;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class Vector2DTest {

	 private static final double DELTA = 1E-7;
	@Test
	public void constructorTest() {
		Vector2D vector = new Vector2D(4, 13);
		assertEquals(4, vector.getX());
		assertEquals(13, vector.getY());
	}

	@Test
	public void getXTest() {
		Vector2D vector1 = new Vector2D(4, 5);
		Vector2D vector2 = new Vector2D(-13, 5);

		assertEquals(4.0, vector1.getX());
		assertEquals(-13.0, vector2.getX());

	}

	@Test
	public void getYTest() {
		Vector2D vector1 = new Vector2D(4, 5);
		Vector2D vector2 = new Vector2D(-13, 5);

		assertEquals(5.0, vector1.getY());
		assertEquals(5.0, vector2.getY());
	}

	@Test
	public void translateTest() {

		Vector2D vector = new Vector2D(10.0, 10.0);
		Vector2D translating = new Vector2D(5, -5);

		vector.translate(translating);

		assertEquals(15.0, vector.getX());
		assertEquals(5.0, vector.getY());

		assertEquals(5, translating.getX());
		assertEquals(-5, translating.getY());
	}

	@Test
	public void translatedTest() {

		Vector2D vector = new Vector2D(10.0, 10.0);
		Vector2D translating = new Vector2D(5, -5);

		Vector2D translatedVector = vector.translated(translating);

		assertEquals(15.0, translatedVector.getX());
		assertEquals(5, translatedVector.getY());

		assertEquals(10.0, vector.getX());
		assertEquals(10, vector.getY());

		assertEquals(5, translating.getX());
		assertEquals(-5, translating.getY());

	}

	@Test
	public void rotateTest() {
		Vector2D vector = new Vector2D(3, 3);

		vector.rotate((double) Math.PI);

		assertEquals(-3, vector.getX(), DELTA);
		assertEquals(-3, vector.getY(), DELTA);

	}
	
	@Test
	public void rotateTest2() {
		Vector2D vector = new Vector2D(10, 10);

		vector.rotate((double) Math.PI / 4);

		assertEquals(0, vector.getX(), DELTA);
		assertEquals(10 * Math.sqrt(2), vector.getY(), DELTA);

	}



	@Test
	public void rotatedTest() {
		Vector2D vector = new Vector2D(3, 3);

		Vector2D rotated = vector.rotated(Math.PI);

		assertEquals(-3, rotated.getX(), DELTA);
		assertEquals(-3, rotated.getY(), DELTA);

		assertEquals(3, vector.getX());
		assertEquals(3, vector.getY());

	}

	@Test
	public void scaleTest() {
		Vector2D vector = new Vector2D(10, 10);

		vector.scale(2);

		assertEquals(20, vector.getX());
		assertEquals(20, vector.getY());
	}

	@Test
	public void scaledTest() {
		Vector2D vector = new Vector2D(1, 2);

		Vector2D scaled = vector.scaled(0.5);

		assertEquals(0.5, scaled.getX());
		assertEquals(1, scaled.getY());

		assertEquals(1, vector.getX());
		assertEquals(2, vector.getY());

	}

	@Test
	public void copyTest() {
		Vector2D vector = new Vector2D(13, 3);
		Vector2D copy = vector.copy();

		assertEquals(13, copy.getX());
		assertEquals(3, copy.getY());

		assertEquals(13, vector.getX());
		assertEquals(3, vector.getY());

	}

}