package hr.fer.zemris.java.custom.collections;

/**
 * Thrown to indicate that the stack is empty.
 * 
 * @author Ivona
 *
 */
@SuppressWarnings("serial")
public class EmptyStackException extends RuntimeException {

	/**
	 * Instantiates EmptyStackException with the provided message
	 * 
	 * @param string Message
	 */
	public EmptyStackException(String string) {
		// zovem superclass constructor
		super(string);

	}
}