package hr.fer.zemris.java.custom.collections.demo;

import hr.fer.zemris.java.custom.collections.ObjectStack;

/**
 * This class accepts a single command-line argument: expression which should be
 * evaluated. Expression must be in postfix representation.
 * 
 * @author Ivona
 *
 */
public class StackDemo {

	/**
	 * The main method that executes when the program runs.
	 * 
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("Incorrect number of arguments!");
			System.exit(1);
		}

		// regularan izlaz, jedan ili više razmaka uklanjam
		String[] elements = args[0].split("\\s+");

		ObjectStack stack = new ObjectStack();
		for (int i = 0; i < elements.length; i++) {
			if (isInt(elements[i])) {
				stack.push(Integer.parseInt(elements[i]));
			} else if (stack.size() >= 2) {
				// operator
				int first = (int) stack.pop();
				int second = (int) stack.pop();

				try {
					operation(first, second, elements[i], stack);

				} catch (UnsupportedOperationException ex) {
					System.out.println("Invalid operator.");
					return;
				} catch (ArithmeticException ex) {
					System.out.println("Dividing by zero is not allowed.");
					return;
				}
			} else {
				System.out.println("Expression is not valid. It has to contain at least two numbers.");
				return;
			}
		}

		if (stack.size() != 1) {
			System.out.println("Evaluation of expression did not succeedd.");
		} else {
			System.out.println("Value of postfix expression: " + stack.pop() + ".");
		}

	}

	/**
	 * This method checks if String can be converted to integer.
	 * 
	 * @param string String to check if it can be converted to integer.
	 * @return <code>true</code> if it can be done, <code>false</code> otherwise
	 */
	private static boolean isInt(String string) {
		try {
			Integer.parseInt(string);
		} catch (NumberFormatException e) {
			return false;
		}
		return true;
	}

	/**
	 * This method evaluates the expression.
	 * 
	 * @param expression The array of commands that form the expression.
	 * @return the integer the expression evaluates to
	 */
	private static void operation(int first, int second, String operator, ObjectStack stack) {
		switch (operator) {
		case "%":
			if (first == 0) {
				throw new ArithmeticException();
			}
			stack.push(second % first);
			break;
		case "/":
			if (first == 0) {
				throw new ArithmeticException();
			}
			stack.push(second / first);
			break;
		case "*":
			stack.push(first * second);
			break;
		case "+":
			stack.push(first + second);
			break;
		case "-":
			stack.push(second - first);
			break;
		default:
			throw new UnsupportedOperationException();
		}

	}
}