package hr.fer.zemris.java.custom.collections;

import java.util.Arrays;

/**
 * This class represents array indexed collection used for storing Objects. This
 * collection uses array for its storing.
 * 
 * @author Ivona
 *
 */
public class ArrayIndexedCollection extends Collection {

	/**
	 * Default capacity of collection.
	 */
	public final static int DEFAULT_CAPACITY = 16;

	/**
	 * Size of collection.
	 */
	private int size;

	/**
	 * Capacity of collection.
	 */
	public int capacity;

	/**
	 * Object which stores elements of the collection.
	 */
	private Object[] elements;

	/**
	 * Default constructor which initializes collection of default capacity.
	 */
	public ArrayIndexedCollection() {
		// TODO Auto-generated constructor stub
		this(DEFAULT_CAPACITY);
	}

	/**
	 * Constructor which initializes collection of given capacity.
	 * 
	 * @param initialCapacity Initial capacity
	 */
	public ArrayIndexedCollection(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException("Initial capacity has to be greater than zero.");
		}

		capacity = initialCapacity;
		elements = new Object[initialCapacity];
	}

	/**
	 * Constructor which initializes collection of default capacity and adds all
	 * elements of input collection to this collection.
	 * 
	 * @param other Collection whose elements will be added to this collection
	 */
	public ArrayIndexedCollection(Collection other) {
		this(other, other.size());
	}

	/**
	 * Constructor which initializes collection of given input capacity and adds all
	 * elements of input collection to this collection.
	 * 
	 * @param other           Collection whose elements will be added to this
	 *                        collection
	 * @param initialCapacity Initial capacity of the new collection
	 */
	public ArrayIndexedCollection(Collection other, int initialCapacity) {
		this(initialCapacity);
		this.addAll(other);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void add(Object value) {

		if (value.equals(null)) {
			throw new NullPointerException("Ne može se dodati null vrijednost.");
		}

		if (size == capacity) {
			reallocate();
		}
		elements[size++] = value;

	}

	/**
	 * This method reallocates the array. It doubles the capacity.
	 */
	private void reallocate() {
		elements = Arrays.copyOf(elements, capacity * 2);
		capacity *= 2;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean contains(Object value) {
		return indexOf(value) != -1;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean remove(Object value) {
		if (indexOf(value) == -1) {
			return false;
		}

		remove(indexOf(value));
		return true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object[] toArray() {
		return elements;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void forEach(Processor processor) {
		for (int i = 0; i < size; i++) {
			processor.process(elements[i]);
		}
	}

	/**
	 * This method returns the Object which is stored at the position index of the
	 * array. Valid indexes are 0 to size-1. If index is invalid, method throws the
	 * {@link IndexOutOfBoundsException}. Complexity: O(1).
	 * 
	 * @param index Index
	 * @return Object at given index
	 */
	public Object get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("Indexi su izvan dopustivog raspona");
		}

		return elements[index];
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clear() {
		for (int i = 0; i < elements.length; i++) {
			elements[i] = null;
		}
		size = 0;
	}

	/**
	 * This method inserts Object at given position in array. Elements on places
	 * which are >= position will be shifted one place toward the end, so an
	 * empty place will be created at position. Valid positions are 0 to size. If
	 * position is invalid, it throws {@link IllegalArgumentException}.
	 * 
	 * @param value    Object which needs to be inserted to collection
	 * @param position Position in array where Object will be inserted
	 */
	public void insert(Object value, int position) {
		if (value.equals(null)) {
			throw new IllegalArgumentException("Null is not allowed to be inserted.");
		}

		if (position < 0 || position > size) {
			throw new IndexOutOfBoundsException("Position should be between 0 and " + (size - 1));
		}

		if (size == capacity) {
			reallocate();
		}

		for (int i = size; i > position; i--) {
			elements[i] = elements[i - 1];
		}

		// ako dodajem na poziciju size, odmah skačem ovdje
		elements[position] = value;
		size++;
	}

	/**
	 * This method goes through the array and finds index of the first
	 * appearance of the given value or -1 if the value does not exist in
	 * Collection.
	 * 
	 * 
	 * @param value Object whose index will be found
	 * @return Index of element if element exists, -1 otherwise
	 */
	public int indexOf(Object value) {
		// value moze biti null, ali kako nije nađen, izlaz -1

		if (!value.equals(null)) {
			for (int i = 0; i < size; i++) {
				if (elements[i].equals(value)) {
					return i;
				}
			}
		}

		return -1;
	}

	/**
	 * This method is used for removing element at given index. Valid index is 0 to
	 * size-1. If index is not valid, it throws {@link IndexOutOfBoundsException}.
	 *
	 * @param index Index of element which will be removed
	 */
	public void remove(int index) {
		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index should be between 0 and " + (size - 1) + ".");
		}

		for (int i = index; i < size - 1; i++) {
			elements[i] = elements[i + 1];
		}

		elements[size - 1] = null;
		size--;
	}

}
