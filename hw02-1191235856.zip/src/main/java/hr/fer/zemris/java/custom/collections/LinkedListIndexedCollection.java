package hr.fer.zemris.java.custom.collections;

/**
 * This class represents linked list indexed collection. It useS linked list for
 * storing Objects.
 * 
 * @author Ivona
 */
public class LinkedListIndexedCollection extends Collection {

	/**
	 * Current size of collection.
	 */
	private int size;

	/**
	 * First node of collection.
	 */
	private ListNode first;

	/**
	 * Last node of collection.
	 */
	private ListNode last;

	/**
	 * This class represents list node. It is basic element of this collection.
	 */
	private static class ListNode {

		/**
		 * Previous list node
		 */
		public ListNode previous;

		/**
		 * Next list node
		 */
		public ListNode next;

		/**
		 * Value of node
		 */
		public Object value;
	}

	/**
	 * Basic constructor.
	 */
	public LinkedListIndexedCollection() {

	}

	/**
	 * Constructor which initializes collection and adds all elements of given
	 * collection to the new collection.
	 *
	 * @param other Collection whose elements will be added
	 */
	public LinkedListIndexedCollection(Collection other) {
		this();
		addAll(other);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void add(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("You cannot add " + value + " to this collection.");
		}

		ListNode novi = new ListNode();
		novi.value = value;
		if (first == null) {
			first = last = novi;
		} else {
			novi.previous = last;
			last.next = novi;
			last = last.next;
		}
		size++;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean contains(Object value) {
		return indexOf(value) != -1;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean remove(Object value) {
		if (indexOf(value) == -1) {
			return false;
		}
		remove(indexOf(value));
		return true;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public Object[] toArray() {
		ArrayIndexedCollection array = new ArrayIndexedCollection(this);
		return array.toArray();
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void forEach(Processor processor) {
		for (ListNode node = first; node != null; node = node.next) {
			processor.process(node.value);
		}
	}

	/**
	 * This method is used for getting element at given index. Valid index is 0 to
	 * size-1. If index is not valid, it throws {@link IndexOutOfBoundsException}.
	 * 
	 * @param index Index of element which needs to be got
	 * @return Element at given index
	 */
	public Object get(int index) {
		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index should be between 0 and" + (size - 1) + ".");
		}

		ListNode node = first;
		if (index < size / 2) {
			for (int i = 0; i < index; i++) {
				node = node.next;
			}
		} else {
			node = last;
			for (int i = size - 1; i > index; i--) {
				node = node.previous;
			}
		}
		return node.value;

	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void clear() {
		ListNode node = first;
		while (node != null) {
			ListNode next = node.next;
			node.next = node.previous = null;
			node.value = null;
			node = next;
		}
		first = first.previous = first.next = null;
		size = 0;
	}

	/**
	 * This method inserts Object at given position in list. Elements on places
	 * which are >= position will be shifted one place toward the end, so an empty
	 * place will be created at position. Valid positions are 0 to size. If position
	 * is invalid, it throws {@link IllegalArgumentException}.
	 * 
	 * @param value    Object which needs to be inserted to collection
	 * @param position Position in list where Object will be inserted
	 */
	void insert(Object value, int position) {

		if (position < 0 || position > size) {
			throw new IllegalArgumentException("Objekt dodajemo na mjestu u rasponu od 0 do " + size + ".");
		}

		if (position == size) {
			add(value);
			return;
		}

		ListNode newNode = new ListNode();
		newNode.value = value;
		// pozicija 0, a lista nije prazna
		if (position == 0) {
			newNode.next = first;
			first.previous = newNode;
			first = newNode;

		} else {
			ListNode node = first;
			for (int i = 0; i < position; i++) {
				node = node.next;
			}
			// u node mi se nalazi čvor na poziciji p, umetni novi ispred njega

			node.previous.next = newNode;
			newNode.previous = node.previous;
			newNode.next = node;
			node.previous = newNode;
		}
		size++;

	}

	/**
	 * This method goes through the list and finds index of the first appearance of
	 * the given value or -1 if the value does not exist in Collection.
	 * 
	 * 
	 * @param value Object whose index will be found
	 * @return Index of element if element exists, -1 otherwise
	 */
	public int indexOf(Object value) {

		if (value.equals(null)) {
			return -1;
		}
		ListNode node = first;
		for (int i = 0; i < size; i++) {
			if (node.value.equals(value)) {
				return i;
			}
			node = node.next;

		}
		return -1;
	}

	/**
	 * This method is used for removing element at given index in list. Valid index
	 * is 0 to size-1. If index is not valid, it throws
	 * {@link IndexOutOfBoundsException}.
	 *
	 * @param index Index of element which will be removed
	 */
	public void remove(int index) {

		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index mora biti u rasponu od 0 do " + size + ".");
		}

		if (first == null) {
			return;
		}

		ListNode node = first;

		// brišemo početni čvor liste
		if (index == 0) {
			first = node.next;
		}

		// tražimo prethodni čvor onog kojeg želimo obrisati
		for (int i = 0; node != null && i < index - 1; i++) {
			node = node.next;
		}

		// zelimo izbrisati node.next (na node smo stali, prethodnik ovog kojeg brisemo)
		ListNode next = node.next.next;
		node.next = next;

	}

}