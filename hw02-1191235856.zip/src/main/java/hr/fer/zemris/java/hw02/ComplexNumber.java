package hr.fer.zemris.java.hw02;

/**
 * This class represents an unmodifiable complex number.
 * 
 * @author Ivona
 */
public class ComplexNumber {

	/**
	 * The real part of complex number.
	 */
	private double real;

	/**
	 * The imaginary part of complex number.
	 */
	private double imaginary;

	/**
	 * Basic constructor.
	 */
	public ComplexNumber() {

	}

	/**
	 * Constructor of ComplexNumbe-
	 * 
	 * @param real      Real part of complex number
	 * @param imaginary Imaginary part of complex number
	 */
	public ComplexNumber(double real, double imaginary) {
		this.real = real;
		this.imaginary = imaginary;
	}

	/**
	 * Static method that constructs a ComplexNumber from the real part.
	 *
	 * @param real Real part of the complex number
	 * @return Complex number
	 */
	public static ComplexNumber fromReal(double real) {
		return new ComplexNumber(real, 0);
	}

	/**
	 * Static method that constructs a ComplexNumber from the imaginary part.
	 *
	 * @param imaginary Imaginary party of the complex number
	 * @return Complex number
	 */
	public static ComplexNumber fromImaginary(double imaginary) {
		return new ComplexNumber(0, imaginary);
	}

	/**
	 * Static method that constructs a ComplexNumber from the polar coordinates.
	 *
	 * @param magnitude Magnitude
	 * @param angle     Angle
	 * @return Complex number
	 */
	public static ComplexNumber fromMagnitudeAndAngle(double magnitude, double angle) {
		return new ComplexNumber(Math.cos(angle) * magnitude, Math.sin(angle) * magnitude);
	}

	/**
	 * Parses the String for a Complex number.
	 *
	 * @param s String to parse
	 * @return Resulting Complex number
	 */
	public static ComplexNumber parse(String s) {

		ComplexNumber parsed = null;
		if ((s.contains(String.valueOf("+"))) || (s.contains(String.valueOf("-")) && s.lastIndexOf('-') > 0)) {
			String re = "";
			String im = "";
			// ignoriraj + na pocetku pozitivnog broja, npr. +2, +2i
			if (s.indexOf('+') == 0) {
				s = s.substring(1);
				//System.out.println(s);
				return parse(s);
			}

			s = s.replaceAll("i", "");
			if (s.indexOf('+') > 0) {
				try {
					re = s.substring(0, s.lastIndexOf('+'));
					im = s.substring(s.lastIndexOf('+') + 1, s.length());
					parsed = new ComplexNumber(Double.parseDouble(re), Double.parseDouble(im));
				} catch (IllegalArgumentException ex) {
					throw new RuntimeException("Invalid number format!");
				}
			} else if (s.lastIndexOf('-') > 0) {
				try {
					re = s.substring(0, s.lastIndexOf('-'));
					im = s.substring(s.lastIndexOf('-') + 1, s.length());
					parsed = new ComplexNumber(Double.parseDouble(re), -Double.parseDouble(im));
				} catch (IllegalArgumentException ex) {
					throw new RuntimeException("Invalid number format!");
				}
			}
		} else {
			try {

				if (s.endsWith("i")) {
					s = s.replaceAll("i", "");
					s = s.trim().length() == 0 ? "1" : s;
					parsed = fromImaginary(Double.parseDouble(s));
				} else {

					return new ComplexNumber(Double.parseDouble(s), 0);
				}
			} catch (IllegalArgumentException ex) {
				throw new RuntimeException("Invalid number format!");
			}
		}
		return parsed;
	}

	/**
	 * Gets the real part.
	 *
	 * @return Real part
	 */
	public double getReal() {
		return real;
	}

	/**
	 * Gets the imaginary part.
	 *
	 * @return Imaginary part
	 */
	public double getImaginary() {
		return imaginary;
	}

	/**
	 * Calculates and returns the magnitude of the complex number in polar
	 * coordinates.
	 * 
	 * @return Magnitude of the complex number
	 */
	public double getMagnitude() {
		return Math.hypot(real, imaginary);
	}

	/**
	 * Calculates and returns the angle of the complex number in polar coordinates.
	 * 
	 * @return Angle of the complex number
	 */
	public double getAngle() {
		// ako je kut < 0 , dodajmo 2Pi da bi ušao u traženi raspon
		return Math.atan2(imaginary, real) < 0 ? Math.atan2(imaginary, real) + 2 * Math.PI
				: Math.atan2(imaginary, real);
	}

	/**
	 * This method constructs new ComplexNumber by adding another ComplexNumber to
	 * this ComplexNumber.
	 *
	 * @param c ComplexNumber to add to this ComplexNumber
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber add(ComplexNumber c) {
		return new ComplexNumber(real + c.real, imaginary + c.imaginary);
	}

	/**
	 * This method constructs new ComplexNumber by subtracting another ComplexNumber
	 * from this ComplexNumber.
	 *
	 * @param c ComplexNumber to subtract from to this ComplexNumber
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber sub(ComplexNumber c) {
		return new ComplexNumber(real - c.real, imaginary - c.imaginary);
	}

	/**
	 * This method constructs new ComplexNumber by multiplying another ComplexNumber
	 * with this ComplexNumber.
	 *
	 * @param c ComplexNumber to multiply with this ComplexNumber
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber mul(ComplexNumber c) {
		return new ComplexNumber(real * c.real - imaginary * c.imaginary, real * c.imaginary + imaginary * c.real);
	}

	/**
	 * This method constructs new ComplexNumber by dividing this ComplexNumber with
	 * another ComplexNumber.
	 *
	 * @param c ComplexNumber to divide this ComplexNumber with
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber div(ComplexNumber c) {
		if (c.getReal() == 0 && c.getImaginary() == 0) {
			throw new IllegalArgumentException("Divider is not allowed to be 0.");
		}

		double denominator = c.real * c.real + c.imaginary * c.imaginary;
		double realOfResult = (real * c.real + imaginary * c.imaginary) / denominator;
		double imaginaryOfResult = (imaginary * c.real - real * c.imaginary) / denominator;
		return new ComplexNumber(realOfResult, imaginaryOfResult);
	}

	/**
	 * This method constructs new ComplexNumber by raising this ComplexNumber to the
	 * n-th power.
	 *
	 * @param n Power to raise the ComplexNumber to
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber power(int n) {
		if (n < 0) {
			throw new IllegalArgumentException("Exponent has to be >= 0.");
		}
		double r = getMagnitude();
		double phi = getAngle();

		return new ComplexNumber(Math.pow(r, n) * Math.cos(n * phi), Math.pow(r, n) * Math.sin(n * phi));
	}

	/**
	 * This method calculates and returns the array of nth roots of this complex
	 * number.
	 *
	 * @param n Required root to calculate
	 * @return New constructed ComplexNumber
	 */
	public ComplexNumber[] root(int n) {
		if (n <= 0) {
			throw new IllegalArgumentException("The root order has to be grater than 0.");
		}

		ComplexNumber roots[] = new ComplexNumber[n];
		double thisAngle = this.getAngle();
		double thisMagnitude = this.getMagnitude();
		for (int i = 0; i < n; i++) {
			double angle = (thisAngle + 2 * Math.PI * i) / n;
			double magnitude = Math.pow(thisMagnitude, 1.0 / n);

			roots[i] = ComplexNumber.fromMagnitudeAndAngle(magnitude, angle);
		}

		return roots;

	}

	@Override
	/**
	 * {@inheritDoc}
	 */
	public String toString() {
		if (imaginary == 0 && real == 0) {
			return 0 + "";
		}
		if (real == 0) {
			return imaginary + "i";
		}

		if (imaginary == 0) {
			return real + "";
		}

		if (imaginary < 0) {
			return real + "-" + (-imaginary) + "i";
		}

		return real + "+" + imaginary + "i";
	}

}
