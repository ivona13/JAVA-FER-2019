package hr.fer.zemris.java.custom.collections;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ArrayIndexedCollectionTest {

	@Test
	public void constructor1Test() {
		ArrayIndexedCollection collection = new ArrayIndexedCollection();
		assertEquals(0, collection.size());
		assertEquals(16, collection.capacity);
	}

	public void constructor2Test() {
		ArrayIndexedCollection collection = new ArrayIndexedCollection(18);
		assertEquals(18, collection.size());
		assertEquals(16 * 2, collection.capacity);
	}

	public void constructor3Test() {
		ArrayIndexedCollection other = new ArrayIndexedCollection(2);
		ArrayIndexedCollection collection = new ArrayIndexedCollection(other);
		assertEquals(other.size(), collection.size());
	}

	public void constructor4Test() {
		ArrayIndexedCollection other = new ArrayIndexedCollection(4);
		ArrayIndexedCollection collection = new ArrayIndexedCollection(other, 20);

		assertEquals(other.size(), collection.size());
		assertEquals(collection.size(), 20);

	}

	@Test
	public void addTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);

		collection.add(Integer.valueOf(13));
		collection.add("Ivona");
		collection.add("java");

		Object[] array = collection.toArray();

		assertEquals(13, array[0]);
		assertTrue("Ivona".equals(array[1]));
		assertTrue("java".equals(array[2]));
	}

	@Test
	public void getTest() {
		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);
		collection.add(Integer.valueOf(20));
		collection.add("New York");
		collection.add("San Francisco");

		assertEquals(20, collection.get(0));
		assertEquals("New York", collection.get(1));
		assertEquals("San Francisco", collection.get(2));

		boolean isNull = false;
		try {
			collection.get(-9);

		} catch (IndexOutOfBoundsException ex) {
			isNull = true;
		}
		assertTrue(isNull);

	}

	@Test
	public void clearTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(8);
		collection.clear();
		assertEquals(0, collection.size());
	}

	@Test
	public void insertTest() {
		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);
		collection.add(Integer.valueOf(20));
		collection.add("New York");
		collection.add("San Francisco");

		collection.insert(13, 1);
		assertEquals(20, collection.get(0));
		assertEquals(13, collection.get(1));
		assertEquals("New York", collection.get(2));
		assertEquals("San Francisco", collection.get(3));

		boolean insertNull = false;
		try {
			collection.insert(null, 3);

		} catch (NullPointerException ex) {
			insertNull = true;
		}
		assertTrue(insertNull);

	}

	@Test
	public void indexOfTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);

		collection.add(Integer.valueOf(13));
		collection.add("Ivona");
		collection.add("java");

		assertEquals(1, collection.indexOf("Ivona"));
		assertEquals(2, collection.indexOf("java"));
		assertEquals(0, collection.indexOf(13));
		assertEquals(-1, collection.indexOf("nešto"));

	}

	@Test
	public void removeTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);

		collection.add(Integer.valueOf(13));
		collection.add("Ivona");
		collection.add("java");

		// remove(index)
		collection.remove(1);
		assertEquals("java", collection.get(1));

		boolean isOut = false;
		try {
			collection.remove(8);

		} catch (IndexOutOfBoundsException ex) {
			isOut = true;
		}
		assertTrue(isOut);
		
		// remove(Object)
		collection.insert("nešto", 0);
		assertEquals(true, collection.remove("nešto"));
		assertEquals(false, collection.remove("nešto2"));
		
		
	}

	@Test
	public void containsTest() {
		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);

		collection.add("Ivona");
		assertEquals(true, collection.contains("Ivona"));
		assertEquals(false, collection.contains("nešto"));

	}

	@Test
	public void toArrayTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);
		collection.add(1);
		collection.add(2);
		collection.add(3);
		collection.add(4);

		Object[] array = collection.toArray();

		assertEquals(1, array[0]);
		assertEquals(2, array[1]);
		assertEquals(3, array[2]);
		assertEquals(4, array[3]);
	}

	@Test
	public void forEachTest() {
		class TestProcessor extends Processor {
			int i = 0;

			@Override
			public void process(Object value) {
				i += 3;
			}
		}

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);

		collection.add(1);
		collection.add(2);
		collection.add(3);

		TestProcessor testProcessor = new TestProcessor();

		collection.forEach(testProcessor);

		assertEquals(9, testProcessor.i);

	}

	@Test
	public void isEmptyTest() {

		ArrayIndexedCollection collection = new ArrayIndexedCollection(2);
		assertTrue(collection.isEmpty());
		collection.add(5);
		assertFalse(collection.isEmpty());
	}

	@Test
	public void addAllTest() {
		ArrayIndexedCollection addCollection = new ArrayIndexedCollection();
		addCollection.add(5);
		addCollection.add(6);
		addCollection.add(7);

		ArrayIndexedCollection collection = new ArrayIndexedCollection();

		collection.addAll(addCollection);

		assertEquals(5, collection.get(0));
		assertEquals(6, collection.get(1));
		assertEquals(7, collection.get(2));

	}

}
