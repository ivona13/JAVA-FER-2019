package hr.fer.zemris.java.custom.collections;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class LinkedListIndexedCollectionTest {

	LinkedListIndexedCollection other;
	LinkedListIndexedCollection collection = new LinkedListIndexedCollection();

	@Test
	public void constructor1Test() {
		LinkedListIndexedCollection collection = new LinkedListIndexedCollection();
		assertEquals(0, collection.size());
	}

	@Test
	public void addTest() {

		collection.add(Integer.valueOf(13));
		collection.add("Ivona");
		collection.add("java");

		Object[] array = collection.toArray();

		assertEquals(13, array[0]);
		assertTrue("Ivona".equals(array[1]));
		assertTrue("java".equals(array[2]));

	}

	@Test
	public void constructor2Test() {

		collection.add(Integer.valueOf(13));
		collection.add("Ivona");
		collection.add("java");

		LinkedListIndexedCollection other = new LinkedListIndexedCollection(collection);
		Object[] array = other.toArray();

		assertEquals(13, array[0]);
		assertTrue("Ivona".equals(array[1]));
		assertTrue("java".equals(array[2]));
	}

	@Test
	public void getTest() {

		collection.add(Integer.valueOf(42));
		assertTrue(collection.get(0).equals(42));

		boolean isOut = true;
		try {
			collection.get(42);
		} catch (IndexOutOfBoundsException ex) {
			isOut = false;
		}
		assertEquals(false, isOut);
	}

	@Test
	public void insertTest() {
		collection.add(Integer.valueOf(13));
		collection.insert("Ivona", 0);
		collection.insert("java", 1);

		Object[] array = collection.toArray();

		assertEquals("Ivona", array[0]);
		assertTrue("java".equals(array[1]));
		assertTrue(Integer.valueOf(13).equals(array[2]));

	}

	@Test
	public void toArrayTest() {
		collection.add(1);
		collection.add(2);
		collection.add(3);

		Object[] array = collection.toArray();

		assertEquals(1, array[0]);
		assertEquals(2, array[1]);
		assertEquals(3, array[2]);
	}

	@Test
	public void indexOfTest() {
		collection.add(Integer.valueOf(13));
		collection.insert("Ivona", 0);
		assertEquals(0, collection.indexOf("Ivona"));
		assertEquals(-1, collection.indexOf("nešto"));

	}

	@Test
	public void removeTest() {
		collection.add(Integer.valueOf(13));
		collection.insert("Ivona", 0);

		// remove(index)
		collection.remove(1);

		Object[] array = collection.toArray();
		assertEquals("Ivona", array[0]);
		boolean isOut = true;
		try {
			collection.remove(42);
		} catch (IndexOutOfBoundsException ex) {
			isOut = false;
		}
		assertEquals(false, isOut);

		// remove(Object)
		collection.insert("nešto", 0);
		collection.insert("ivona", 1);
		assertEquals(true, collection.remove("nešto"));
		assertEquals(0, collection.indexOf("ivona") );
		assertEquals(true, collection.remove("ivona"));

	}

	@Test
	public void sizeTest() {
		collection.add("nešto");
		collection.add("još nešto");

		assertEquals(2, collection.size());
	}

	@Test
	public void containsTest() {
		collection.add(13);
		collection.add(26);

		assertTrue(collection.contains(13));
		assertTrue(!collection.contains(70));

	}

	@Test
	public void clearTest() {
		collection.add(13);
		collection.clear();
		assertEquals(0, collection.size());
	}

	@Test
	public void forEachTest() {
		class TestProcessor extends Processor {
			int i = 0;

			@Override
			public void process(Object value) {
				i += 2;
			}
		}

		collection.add(13);
		collection.add(26);

		TestProcessor testProcessor = new TestProcessor();
		collection.forEach(testProcessor);
		assertEquals(4, testProcessor.i);

	}

}
