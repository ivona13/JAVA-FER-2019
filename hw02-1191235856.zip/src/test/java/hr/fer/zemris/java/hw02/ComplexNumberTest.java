package hr.fer.zemris.java.hw02;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ComplexNumberTest {

	private static final double DELTA = 1E-7;

	@Test
	public void constructorTest() {
		ComplexNumber number1 = new ComplexNumber(2, 5);
		assertEquals(2, number1.getReal());
		assertEquals(5, number1.getImaginary());

		ComplexNumber number2 = new ComplexNumber(0, 5);
		assertEquals(0, number2.getReal());
		assertEquals(5, number2.getImaginary());

		boolean isBad = false;
		try {
			new ComplexNumber(Double.parseDouble("nešto"), Double.parseDouble("još nešto"));
		} catch (IllegalArgumentException ex) {
			isBad = true;
		}
		assertEquals(true, isBad);
	}

	ComplexNumber number = new ComplexNumber(8, 9);

	@Test
	public void fromRealTest() {
		number = ComplexNumber.fromReal(4);
		assertEquals(4, number.getReal());
		assertEquals(0, number.getImaginary());
	}

	@Test
	public void fromImaginaryTest() {
		number = ComplexNumber.fromImaginary(9);
		assertEquals(0, number.getReal());
		assertEquals(9, number.getImaginary());
	}

	@Test
	public void fromMagnitudeAndAngleTest() {
		ComplexNumber z = ComplexNumber.fromMagnitudeAndAngle(5, Math.PI / 2);
		assertEquals(0, z.getReal(), DELTA);
		assertEquals(5, z.getImaginary(), DELTA);

		ComplexNumber w = ComplexNumber.fromMagnitudeAndAngle(Math.sqrt(2), Math.PI / 4);
		assertEquals(1, w.getReal(), DELTA);
		assertEquals(1, w.getImaginary(), DELTA);
	}

	@Test
	public void parseNegativeRealPositiveImaginaryTest() {

		ComplexNumber z = ComplexNumber.parse("-13.7+18.2i");
		assertEquals(-13.7, z.getReal(), DELTA);
		assertEquals(18.2, z.getImaginary(), DELTA);
	}

	@Test
	public void parsePositiveRealNegativeImaginary() {

		ComplexNumber c1 = ComplexNumber.parse("13.7-18.2i");
		assertEquals(13.7, c1.getReal(), DELTA);
		assertEquals(-18.2, c1.getImaginary(), DELTA);
	}

	@Test
	public void parseOnlyImaginary() {

		ComplexNumber z = ComplexNumber.parse("-13i");
		assertEquals(0.0, z.getReal());
		assertEquals(-13.0, z.getImaginary());
	}

	@Test
	public void parseOnlyReal() {

		ComplexNumber z = ComplexNumber.parse("13");
		assertEquals(13.0, z.getReal(), DELTA);
		assertEquals(0.0, z.getImaginary(), DELTA);
	}

	@Test
	public void parseImaginaryWithPlus() {

		ComplexNumber z = ComplexNumber.parse("+i");
		assertEquals(0, z.getReal(), DELTA);
		assertEquals(1, z.getImaginary(), DELTA);
	}

	@Test
	public void parsePositiveImaginary() {
		ComplexNumber z = ComplexNumber.parse("13i");
		assertEquals(0, z.getReal());
		assertEquals(13.0, z.getImaginary());
	}

	@Test
	public void parseStringTest() {
		boolean passed = true;
		try {
			ComplexNumber.parse("java");

		} catch (RuntimeException ex) {
			passed = false;
		}
		assertEquals(false, passed);
	}

	@Test
	public void getRealTest() {
		ComplexNumber z = new ComplexNumber(2, 4);
		assertEquals(2, z.getReal(), DELTA);
	}

	@Test
	public void getImaginaryTest() {
		ComplexNumber z = new ComplexNumber(2, 4);
		assertEquals(4, z.getImaginary(), DELTA);
	}

	@Test
	public void getMagnitudeTest() {
		ComplexNumber z = new ComplexNumber(3, 4);
		assertEquals(5, z.getMagnitude(), DELTA);
	}

	@Test
	public void getAngleTest() {
		ComplexNumber z = new ComplexNumber(0, 5);
		assertEquals(Math.PI / 2, z.getAngle(), DELTA);

		ComplexNumber w = new ComplexNumber(1, 1);
		assertEquals(Math.PI / 4, w.getAngle(), DELTA);

	}

	@Test
	public void addTest() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber z2 = new ComplexNumber(5, 15);

		ComplexNumber z3 = z1.add(z2);

		assertEquals(8, z3.getReal(), DELTA);
		assertEquals(28, z3.getImaginary(), DELTA);
	}

	@Test
	public void subTest() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber z2 = new ComplexNumber(5, 15);

		ComplexNumber z3 = z1.sub(z2);

		assertEquals(-2, z3.getReal(), DELTA);
		assertEquals(-2, z3.getImaginary(), DELTA);

	}

	@Test
	public void mulTest() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber z2 = new ComplexNumber(5, 15);

		ComplexNumber z3 = z1.mul(z2);

		assertEquals(-180, z3.getReal(), DELTA);
		assertEquals(110, z3.getImaginary(), DELTA);
	}

	@Test
	public void divTest() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber z2 = new ComplexNumber(5, 15);

		ComplexNumber z3 = z1.div(z2);

		assertEquals(21.0 / 25, z3.getReal(), DELTA);
		assertEquals(2.0 / 25, z3.getImaginary(), DELTA);
	}

	@Test
	public void divByZero() {
		ComplexNumber z1 = new ComplexNumber(1, 1);
		ComplexNumber z2 = new ComplexNumber(0, 0);

		boolean passed=true;
		try {
		z1.div(z2);
		} catch(IllegalArgumentException ex) {
			passed=false;
		}
		assertEquals(false, passed);
	}

	@Test
	public void power() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber z2 = z1.power(5);

		assertEquals(383028, z2.getReal(), DELTA);
		assertEquals(178828, z2.getImaginary(), DELTA);

	}

	@Test
	public void root() {
		ComplexNumber z1 = new ComplexNumber(3, 13);
		ComplexNumber[] roots = z1.root(3);

		ComplexNumber root1 = roots[0];
		ComplexNumber root2 = roots[1];
		ComplexNumber root3 = roots[2];

		assertEquals(2.1377006355853814, root1.getReal(), DELTA);
		assertEquals(1.0273569588802687, root1.getImaginary(), DELTA);

		assertEquals(-1.9585675429377283, root2.getReal(), DELTA);
		assertEquals(1.3376245766629464, root2.getImaginary(), DELTA);

		assertEquals(-0.17913309264765248, root3.getReal(), DELTA);
		assertEquals(-2.3649815355432153, root3.getImaginary(), DELTA);

	}

}
