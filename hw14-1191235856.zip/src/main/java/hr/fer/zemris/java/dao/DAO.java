package hr.fer.zemris.java.dao;

import java.util.List;

import hr.fer.zemris.java.model.Band;
import hr.fer.zemris.java.model.Poll;

/**
 * This interface represents model for communication with database - it enables
 * information to be sent to user through different queries.
 * 
 * @author ivona
 *
 */
public interface DAO {

	/**
	 * This method is used to get all polls from database
	 * 
	 * @return list of polls
	 * @throws DAOException if error happens
	 */
	List<Poll> getPolls() throws DAOException;

	/**
	 * This method is used for getting specific poll - the one with input ID.
	 * 
	 * @param pollID id of poll
	 * @return Poll with input id
	 * @throws DAOException if error happens
	 */
	Poll getPoll(long pollID) throws DAOException;

	/**
	 * This method is used for getting list of options in some poll - the one with
	 * input pollID.
	 * 
	 * @param pollID id of specific poll to get all options from
	 * @return list of options for specific poll
	 * @throws DAOException if error happens
	 */
	List<Band> getResults(long pollID) throws DAOException;

	/**
	 * This method is used for updating poll with specific pollID - in out
	 * application it means increasing votesCount of specific option in some pollID
	 * 
	 * @param pollID id of specific poll where the action of updating will happen
	 * @param id     id of option in poll
	 * @throws DAOException if error happens
	 */
	void updatePoll(long pollID, long id) throws DAOException;

}
