package hr.fer.zemris.java.dao;

import hr.fer.zemris.java.dao.sql.SQLDAO;

/**
 * This class represents provider for database.
 *
 */
public class DAOProvider {

	/**
	 * Instance of DAO provider
	 */
	private static DAO dao = new SQLDAO();

	/**
	 * This method returns instance of DAO provider
	 * 
	 * @return Dao provider
	 */
	public static DAO getDao() {
		return dao;
	}

}