package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.Band;
import hr.fer.zemris.java.model.Poll;

/**
 * This class is used for generating result of voting.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/glasanje-rezultati")
public class GlasanjeRezultatiServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String pollIDString = req.getParameter("pollID");

		if (pollIDString != null) {
			try {
				long pollID = Long.parseLong(pollIDString);

				List<Band> pollOptions = DAOProvider.getDao().getResults(pollID);

				List<Band> best = new ArrayList<Band>();
				best.add(pollOptions.get(0));

				for (int i = 1; i < pollOptions.size(); i++) {
					if (pollOptions.get(i).getVotesNumber().equals(pollOptions.get(0).getVotesNumber())) {
						best.add(pollOptions.get(i));
					} else {
						break;
					}
				}

				Poll poll = DAOProvider.getDao().getPoll(pollID);
				req.setAttribute("poll", poll);
				req.setAttribute("options", pollOptions);
				req.setAttribute("best", best);
				req.setAttribute("pollID", pollID);
			} catch (NumberFormatException ex) {

			}

		}

		req.getRequestDispatcher("/WEB-INF/pages/glasanjeRez.jsp").forward(req, resp);
	}

}
