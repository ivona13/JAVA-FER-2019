package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.Band;
import hr.fer.zemris.java.model.Poll;

/**
 * This class is used to represent web application for voting.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/glasanje")
public class GlasanjeServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String pollIDString = (String) req.getParameter("pollID");

		if (pollIDString != null) {
			long pollID = Long.parseLong(pollIDString);
			List<Band> options = DAOProvider.getDao().getResults(pollID);

			Poll poll = DAOProvider.getDao().getPoll(pollID);
			req.setAttribute("poll", poll);
			req.setAttribute("pollID", pollID);
			req.setAttribute("options", options);
		}

		req.getRequestDispatcher("/WEB-INF/pages/glasanjeIndex.jsp").forward(req, resp);

	}

}
