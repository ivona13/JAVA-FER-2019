package hr.fer.zemris.java.model;

/**
 * This class is used to represent Poll in database of this application.
 * 
 * @author ivona
 *
 */
public class Poll {

	/**
	 * Poll id
	 */
	long id;

	/**
	 * Poll title
	 */
	String title;

	/**
	 * Poll message
	 */
	String message;

	/**
	 * Basic contructor
	 */
	public Poll() {
	}

	/**
	 * Constructor
	 * 
	 * @param id      id
	 * @param title   title
	 * @param message messagge
	 */
	public Poll(long id, String title, String message) {
		this.id = id;
		this.title = title;
		this.message = message;
	}

	/**
	 * Id getter
	 * 
	 * @return id
	 */
	public long getId() {
		return id;
	}

	/**
	 * Title getter
	 * 
	 * @return title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Message getter
	 * 
	 * @return message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Id setter
	 * 
	 * @param id id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Title id
	 * 
	 * @param title title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Message setter
	 * 
	 * @param message message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
