package hr.fer.zemris.java;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.mchange.v2.c3p0.DataSources;

import hr.fer.zemris.java.model.Band;

/**
 * This class represents initialization listener. It is used for initialization
 * of database and connecting to database. If tables in database are not
 * created, this class creates them and fill them.
 * 
 * @author ivona
 *
 */
@WebListener
public class Inicijalizacija implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {

		Properties prop = new Properties();
		try {
			prop.load(sce.getServletContext().getResourceAsStream("/WEB-INF/dbsettings.properties"));
		} catch (IOException e) {
			throw new RuntimeException("Error while loading database properties!");
		}

		if (!(prop.containsKey("host") && prop.containsKey("port") && prop.containsKey("name")
				&& prop.containsKey("user") && prop.containsKey("password"))) {
			throw new RuntimeException("Error while loading database properties!");
		}

		String dbName = prop.getProperty("name");
		String connectionURL = "jdbc:derby://" + prop.getProperty("host") + ":" + prop.getProperty("port") + "/"
				+ dbName + "; user=" + prop.getProperty("user") + ";" + "password=" + prop.getProperty("password")
				+ ";create=true";

		ComboPooledDataSource cpds = new ComboPooledDataSource();
		try {
			cpds.setDriverClass("org.apache.derby.jdbc.ClientDriver");
		} catch (PropertyVetoException e1) {
			throw new RuntimeException("Error while initalizing poll.", e1);
		}
		cpds.setJdbcUrl(connectionURL);

		try (Connection dbConnection = cpds.getConnection()) {
			DatabaseMetaData dbmd = dbConnection.getMetaData();
			ResultSet rs = dbmd.getTables(null, null, "%", null);
			List<String> tables = new ArrayList<>();
			while (rs.next()) {
				tables.add(rs.getString(3));
			}

			if (!tables.contains("POLLS") || !tables.contains("POLLOPTIONS")) {

				boolean containsPools = tables.contains("POLLS");
				boolean containsOptions = tables.contains("POLLOPTIONS");

				List<Band> options1;
				List<Band> options2;

				try {
					// load options for first poll
					options1 = getResults(sce, "glasanje-definicija1.txt", "glasanje-rezultati1.txt");

					// load options for second poll
					options2 = getResults(sce, "glasanje-definicija2.txt", "glasanje-rezultati2.txt");
				} catch (IOException e) {
					throw new RuntimeException("Error while loading pool options!");
				}

				createTables(dbConnection, options1, options2, containsPools, containsOptions);
			} else if (noVotingPool(dbConnection)) {
				List<Band> results1;
				List<Band> results2;

				try {
					results1 = getResults(sce, "glasanje-definicija1.txt", "glasanje-rezultati1.txt");
					results2 = getResults(sce, "glasanje-definicija2.txt", "glasanje-rezultati2.txt");
				} catch (IOException e) {
					throw new RuntimeException("Error while loading pool options!");
				}

				createPoll(dbConnection, results1, "Glasanje za najboljeg nogometaša:",
						"Od sljedećih bendova, koji Vam je bend najdraži? Kliknite na link kako biste glasali!");
				createPoll(dbConnection, results2, "Glasanje za najboljeg nogometaša:",
						"Od sljedecih nogometaša, izaberite najboljeg po Vašem mišljenju!!");
			}

			rs.close();
		} catch (SQLException ex) {
			throw new RuntimeException("Error while creating database!", ex);
		}

		sce.getServletContext().setAttribute("hr.fer.zemris.dbpool", cpds);
	}

	/**
	 * This class is used for creating voting poll for database.
	 * 
	 * @param con     connection
	 * @param results list of bands (options) for poll
	 * @param name    name of poll
	 * @param message message of poll
	 * @throws SQLException if error happenes
	 */
	private void createPoll(Connection con, List<Band> results, String name, String message) throws SQLException {

		PreparedStatement pst = con.prepareStatement("INSERT INTO POLLS (title, message) values (?,?)",
				Statement.RETURN_GENERATED_KEYS);

		pst.setString(1, name);
		pst.setString(2, message);
		pst.executeUpdate();
		ResultSet rset = pst.getGeneratedKeys();

		rset.next();
		long poolId = rset.getLong(1);

		pst = con.prepareStatement(
				"INSERT INTO POLLOPTIONS (optionTitle, optionLink, pollID, votesCount) values (?," + "?,?,?)");
		for (Band result : results) {
			pst.setString(1, result.getName());
			pst.setString(2, result.getLink());
			pst.setLong(3, poolId);
			pst.setInt(4, Integer.parseInt(result.getVotesNumber()));
			pst.executeUpdate();
		}

	}

	/**
	 * This method is used for checking if there is any pool to vote for.
	 *
	 * @param con connection to database
	 * @return true if polls don't exist, false otherwise
	 * @throws SQLException if error happens
	 */
	private boolean noVotingPool(Connection con) throws SQLException {
		PreparedStatement pst = con.prepareStatement("SELECT * FROM POLLS");

		ResultSet rset = pst.executeQuery();

		return !(rset != null && rset.next());
	}

	/**
	 * This method is used for creating tables in database of the application-
	 * 
	 * @param con             connection
	 * @param results         options for first poll - assuming we work with two
	 *                        polls
	 * @param results2        options for second poll - assuming we work with two
	 *                        polls
	 * @param containsPolls   - flag that says if database contains poll
	 * @param containsOptions - flag that says if database contains options
	 * @throws SQLException if error happens
	 */
	private void createTables(Connection con, List<Band> results, List<Band> results2, boolean containsPolls,
			boolean containsOptions) throws SQLException {

		PreparedStatement pst;

		if (!containsPolls) {
			pst = con
					.prepareStatement("CREATE TABLE Polls\n" + " (id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,\n"
							+ " title VARCHAR(150) NOT NULL,\n" + " message CLOB(2048) NOT NULL\n" + ")");

			pst.executeUpdate();
		}

		if (!containsOptions) {
			pst = con.prepareStatement(
					"CREATE TABLE PollOptions\n" + " (id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,\n"
							+ " optionTitle VARCHAR(100) NOT NULL,\n" + " optionLink VARCHAR(150) NOT NULL,\n"
							+ " pollID BIGINT,\n" + " votesCount BIGINT,\n"
							+ " FOREIGN KEY (pollID) REFERENCES Polls(id)\n" + ")");

			pst.executeUpdate();
		}

		createPoll(con, results, "Glasanje za omiljeni bend:",
				"Od sljedećih bendova, koji Vam je bend najdraži? " + "Kliknite na link kako biste glasali!");
		createPoll(con, results2, "Glasanje za najboljeg nogometaša:",
				"Od sljedecih nogometaša, izaberite najboljeg po Vašem mišljenju!!");

	}

	/**
	 * This class is used to load options (content) from defFile and resFile
	 * 
	 * @param sce     servlet context event
	 * @param defFile File with options - id, name, link
	 * @param resFile File with results - id, votesNumber
	 * @return List of options
	 * @throws IOException if error happens
	 */
	private static List<Band> getResults(ServletContextEvent sce, String defFile, String resFile) throws IOException {
		String fileName = sce.getServletContext().getRealPath("/WEB-INF/" + defFile);
		List<String> lines = Files.readAllLines(Paths.get(fileName));

		List<Band> options = new ArrayList<>();
		for (String line : lines) {
			String[] parts = line.split("\\t");
			options.add(new Band(parts[0], parts[1], parts[2]));
		//	System.out.println(parts[0] + "-" + parts[1] + "-" + parts[2]);
		}

		String fileNameResults = sce.getServletContext().getRealPath("/WEB-INF/" + resFile);

		if (!Files.exists(Paths.get(fileNameResults))) {
			Files.createFile(Paths.get(fileNameResults));
		}

		lines = Files.readAllLines(Paths.get(fileNameResults));

		List<Band> results = new ArrayList<>();
		for (String line : lines) {
			String[] parts = line.split("\\t");
			int result = Integer.parseInt(parts[1]);
			String name = "";
			String link = "";
			for (Band band : options) {
				if (band.getId().equals(parts[0])) {
					name = band.getName();
					link = band.getLink();
				}
			}
			results.add(new Band(parts[0], name, link, String.valueOf(result)));
		}

		return results;
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		ComboPooledDataSource cpds = (ComboPooledDataSource) sce.getServletContext()
				.getAttribute("hr.fer.zemris.dbpool");
		if (cpds != null) {
			try {
				DataSources.destroy(cpds);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
