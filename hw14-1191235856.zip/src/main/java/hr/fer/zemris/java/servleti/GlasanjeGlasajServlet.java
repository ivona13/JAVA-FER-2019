package hr.fer.zemris.java.servleti;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;

/**
 * This class is used to represent voting servlet. It is used for voting for the
 * band.
 * 
 * @author ivona
 *
 */
@WebServlet(name = "glasanje-glasaj", urlPatterns = "/servleti/glasanje-glasaj")
public class GlasanjeGlasajServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String pollIDString = req.getParameter("pollID");
		String idString = req.getParameter("id");

		if (idString != null && pollIDString != null) {

			try {
				long pollID = Long.parseLong(pollIDString);
				long id = Long.parseLong(idString);

				DAOProvider.getDao().updatePoll(pollID, id);
			} catch (NumberFormatException ex) {

			}
			resp.sendRedirect(req.getContextPath() + "/servleti/glasanje-rezultati?pollID=" + pollIDString);
		}
	}

}
