package hr.fer.zemris.java.dao.sql;

import java.sql.Connection;

/**
 * This class represents storing connection for current thread.
 *
 */
public class SQLConnectionProvider {
	/**
	 * Thread local object
	 */
	private static ThreadLocal<Connection> connections = new ThreadLocal<>();

	/**
	 * This method is used for setting connection
	 * 
	 * @param con connection to be set
	 */
	public static void setConnection(Connection con) {
		if (con == null) {
			connections.remove();
		} else {
			connections.set(con);
		}
	}

	/**
	 * Connection getter
	 * 
	 * @return connection for database
	 */
	public static Connection getConnection() {
		return connections.get();
	}

}
