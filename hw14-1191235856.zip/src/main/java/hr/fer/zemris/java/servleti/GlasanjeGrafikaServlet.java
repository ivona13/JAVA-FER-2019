package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.Band;

/**
 * This class is used to represent voting graphics servlet. It displays pie
 * chart of voting.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/glasanje-grafika")
public class GlasanjeGrafikaServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("image/png");

		long pollID = Long.parseLong(req.getParameter("pollID"));

		List<Band> options = DAOProvider.getDao().getResults(pollID);
		OutputStream outputStream = resp.getOutputStream();

		PieDataset dataset = createDataset(options);
		JFreeChart chart = createChart(dataset, "");

		int width = 400;
		int height = 450;
		ChartUtilities.writeChartAsPNG(outputStream, chart, width, height);
	}

	/**
	 * This method is used for creating pie data set.
	 * 
	 * @param bands data set to make pie based on
	 * @return pie data set
	 */
	private PieDataset createDataset(List<Band> options) {
		DefaultPieDataset result = new DefaultPieDataset();

		for (Band option : options) {
			result.setValue(option.getName(), Double.parseDouble(option.getVotesNumber()));
		}
		return result;
	}

	/**
	 * This method is used for creating {@link JFreeChart}
	 * 
	 * @param dataset dataset
	 * @param title   title of chart
	 * @return {@link JFreeChart}
	 */
	private JFreeChart createChart(PieDataset dataset, String title) {

		JFreeChart chart = ChartFactory.createPieChart3D(title, // chart title
				dataset, // data
				true, // include legend
				true, false);

		PiePlot3D plot = (PiePlot3D) chart.getPlot();
		plot.setStartAngle(250);
		plot.setDirection(Rotation.CLOCKWISE);
		plot.setForegroundAlpha(0.5f);
		return chart;

	}

}
