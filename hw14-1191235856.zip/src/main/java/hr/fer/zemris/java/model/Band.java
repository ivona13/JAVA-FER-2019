package hr.fer.zemris.java.model;

/**
 * This class represents util class for saving information about some band. It
 * has its id, name, link to the song and number of votes for the band.
 * 
 * @author ivona
 *
 */
public class Band {

	/**
	 * Id of the band
	 */
	private String id;

	/**
	 * Name of the band
	 */
	private String name;

	/**
	 * Link of some song of the band
	 */
	private String link;

	/**
	 * Number of votes
	 */
	private String votesNumber;

	/**
	 * Constructor
	 * 
	 * @param id          id
	 * @param name        name
	 * @param link        link
	 * @param votesNumber number of votes
	 */
	public Band(String id, String name, String link, String votesNumber) {
		this.id = id;
		this.name = name;
		this.link = link;
		this.votesNumber = votesNumber;
	}

	/**
	 * Constructor
	 * 
	 * @param id   id
	 * @param name name
	 * @param link link
	 */
	public Band(String id, String name, String link) {
		this.id = id;
		this.name = name;
		this.link = link;
	}

	/**
	 * Id getter
	 * 
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * Id setter
	 * 
	 * @param id id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Name getter
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Name setter
	 * 
	 * @param name name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Link getter
	 * 
	 * @return link
	 */
	public String getLink() {
		return link;
	}

	/**
	 * Link setter
	 * 
	 * @param link link
	 */
	public void setLink(String link) {
		this.link = link;
	}

	/**
	 * Votes number getter
	 * 
	 * @return votes number
	 */
	public String getVotesNumber() {
		return votesNumber;
	}

	/**
	 * Votes number setter
	 * 
	 * @param votesNumber votesnumber
	 */
	public void setVotesNumber(String votesNumber) {
		this.votesNumber = votesNumber;
	}

}
