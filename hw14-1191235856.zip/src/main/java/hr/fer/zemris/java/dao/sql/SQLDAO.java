package hr.fer.zemris.java.dao.sql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.dao.DAO;
import hr.fer.zemris.java.dao.DAOException;
import hr.fer.zemris.java.model.Band;
import hr.fer.zemris.java.model.Poll;

/**
 * This class is used to represent implementation of {@link DAO} for this
 * application. It has methods to get information from tables in database.
 * 
 * @author ivona
 *
 */
public class SQLDAO implements DAO {

	@Override
	public List<Poll> getPolls() throws DAOException {
		List<Poll> polls = new ArrayList<Poll>();
		Connection connection = SQLConnectionProvider.getConnection();

		PreparedStatement pst = null;

		try {
			pst = connection.prepareStatement("SELECT id, title, message FROM Polls ORDER BY ID");
			try {
				ResultSet rs = pst.executeQuery();
				try {
					while (rs != null && rs.next()) {
						Poll poll = new Poll(rs.getLong(1), rs.getString(2), rs.getString(3));
						polls.add(poll);
					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}
		} catch (Exception ex) {
			throw new DAOException("Error while loading polls.", ex);
		}
		return polls;

	}



	@Override
	public List<Band> getResults(long pollIdLong) {
		List<Band> results = new ArrayList<>();
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst;

		try {

			pst = con.prepareStatement("SELECT id, optionTitle, optionLink, votesCount FROM PollOptions WHERE pollID=?"
					+ " order by votesCount DESC ");
			pst.setLong(1, pollIdLong);
			ResultSet rs = pst.executeQuery();
			while (rs != null && rs.next()) {
				Band result = new Band(String.valueOf(rs.getLong(1)), rs.getString(2), rs.getString(3),
						rs.getString(4));
				results.add(result);
			}

		} catch (SQLException ex) {
			throw new DAOException("Error while loading results.", ex);
		}


		return results;
	}

	@Override
	public void updatePoll(long pollID, long id) throws DAOException {
		List<Band> results = new ArrayList<>();
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst;

		try {

			pst = con.prepareStatement(
					"select id, optionTitle, optionLink,votesCount from PollOptions where pollID=?" + " and id=?");
			pst.setLong(1, pollID);
			pst.setLong(2, id);
			ResultSet rs = pst.executeQuery();
			while (rs != null && rs.next()) {
				Band result = new Band(String.valueOf(rs.getLong(1)), rs.getString(2), rs.getString(3),
						rs.getString(4));
				results.add(result);
			}

			Band result = results.get(0);
			pst = con.prepareStatement("UPDATE PollOptions SET votesCount=? WHERE id=?");

			pst.setLong(1, Long.parseLong(result.getVotesNumber()) + 1);
			pst.setLong(2, id);

			int numberOfAffectedRows = pst.executeUpdate();
			if (numberOfAffectedRows != 1) {
				throw new SQLException("Error while voting.");
			}

		} catch (SQLException | NumberFormatException ex) {
			throw new DAOException("Error while voting.", ex);
		}

	}

	@Override
	public Poll getPoll(long pollID) throws DAOException {
		Poll poll = null;
		Connection con = SQLConnectionProvider.getConnection();
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement("SELECT id, title, message FROM Polls WHERE id=?");
			pst.setLong(1, pollID);
			try {
				ResultSet rs = pst.executeQuery();
				try {
					if (rs != null && rs.next()) {
						poll = new Poll();
						poll.setId(rs.getLong(1));
						poll.setTitle(rs.getString(2));
						poll.setMessage(rs.getString(3));

					}
				} finally {
					try {
						rs.close();
					} catch (Exception ignorable) {
					}
				}
			} finally {
				try {
					pst.close();
				} catch (Exception ignorable) {
				}
			}
		} catch (Exception ex) {
			throw new DAOException("Error while getting poll.", ex);
		}
		return poll;
	}

}