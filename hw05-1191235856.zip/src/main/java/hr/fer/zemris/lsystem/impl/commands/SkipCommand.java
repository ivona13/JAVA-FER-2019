package hr.fer.zemris.lsystem.impl.commands;

import hr.fer.zemris.lsystem.Vector2D;
import hr.fer.zemris.lsystem.impl.Command;
import hr.fer.zemris.lsystem.impl.Context;
import hr.fer.zemris.lsystem.impl.TurtleState;
import hr.fer.zemris.lsystems.Painter;

public class SkipCommand implements Command {

	double step;

	public SkipCommand(double step) {
		super();
		this.step = step;
	}

	public void setStep(double step) {
		this.step = step;
	}

	public double getStep() {
		return step;
	}

	public void execute(Context ctx, Painter painter) {
		TurtleState currentState = ctx.getCurrentState();
		Vector2D currentPosition = currentState.getPosition();
		Vector2D direction = currentState.getDirection();
		double moveLength = currentState.getMovement();
		Vector2D nextPosition = currentPosition.translated(direction.scaled(moveLength * step));
		currentState.setPosition(nextPosition);
	}
}
