package hr.fer.zemris.lsystem.impl.commands;

import java.awt.Color;

import hr.fer.zemris.lsystem.impl.Command;
import hr.fer.zemris.lsystem.impl.Context;
import hr.fer.zemris.lsystems.Painter;

public class ColorCommand implements Command {

	private Color color;

	public ColorCommand(Color color) {
		super();
		this.color = color;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public void execute(Context ctx, Painter painter) {
		ctx.getCurrentState().setColor(this.color);
	}
}
