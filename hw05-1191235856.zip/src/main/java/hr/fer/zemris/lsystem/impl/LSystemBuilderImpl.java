package hr.fer.zemris.lsystem.impl;

import hr.fer.zemris.java.custom.collections.Dictionary;
import hr.fer.zemris.lsystems.LSystem;
import hr.fer.zemris.lsystems.LSystemBuilder;
import hr.fer.zemris.lsystems.Painter;
import hr.fer.zemris.lsystem.Vector2D;
import hr.fer.zemris.lsystem.impl.commands.ColorCommand;
import hr.fer.zemris.lsystem.impl.commands.DrawCommand;
import hr.fer.zemris.lsystem.impl.commands.PopCommand;
import hr.fer.zemris.lsystem.impl.commands.PushCommand;
import hr.fer.zemris.lsystem.impl.commands.RotateCommand;
import hr.fer.zemris.lsystem.impl.commands.SkipCommand;

import java.awt.*;
import java.util.Arrays;
import java.util.stream.Collectors;


public class LSystemBuilderImpl implements LSystemBuilder {

	/**
	 * Unit length.
	 */
	private double unitLength = 0.1;

	/**
	 * Unit length degree scaler.
	 */
	private double unitLengthDegreeScaler = 1;

	/**
	 * Origin.
	 */
	private Vector2D origin = new Vector2D(0, 0);

	/**
	 * Angle.
	 */
	private double angle = 0;

	/**
	 * Axiom.
	 */
	private String axiom = "";

	/**
	 * Commands dictionary.
	 */
	private Dictionary<Character, Command> commands;

	/**
	 * Productions dictionary.
	 */
	private Dictionary<Character, String> productions;

	/**
	 * Basic constructor.
	 */
	public LSystemBuilderImpl() {
		this.commands = new Dictionary<Character, Command>();
		this.productions = new Dictionary<Character, String>();
	}

	@Override
	public LSystemBuilder setUnitLength(double v) {
		unitLength = v;

		return this;
	}

	@Override
	public LSystemBuilder setOrigin(double v, double v1) {
		origin = new Vector2D(v, v1);

		return this;
	}

	@Override
	public LSystemBuilder setAngle(double v) {
		angle = v;

		return this;
	}

	@Override
	public LSystemBuilder setAxiom(String s) {
		axiom = s;

		return this;
	}

	@Override
	public LSystemBuilder setUnitLengthDegreeScaler(double v) {
		unitLengthDegreeScaler = v;

		return this;
	}

	@Override
	public LSystemBuilder registerCommand(char c, String s) {
		String[] parts = s.split("\\s+");

		switch (parts[0]) {
		case "draw":
			try {
				double step = Double.parseDouble(parts[1]);
				DrawCommand drawCommand = new DrawCommand(step);
				commands.put(c, drawCommand);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Broj u komandi crtanja se ne može parsirati!");
			}
			break;
		case "skip":
			try {
				double step = Double.parseDouble(parts[1]);
				SkipCommand skipCommand = new SkipCommand(step);
				commands.put(c, skipCommand);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Broj u komandi skippanja se ne može parsirati!");
			}
			break;
		case "scale":
			try {
				double skip = Double.parseDouble(parts[1]);
				SkipCommand skipCommand = new SkipCommand(skip);
				commands.put(c, skipCommand);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Broj u komandi scaleanja se ne može parsirati!");
			}
			break;
		case "rotate":
			try {
				double rotate = Double.parseDouble(parts[1]);
				RotateCommand rotateCommand = new RotateCommand(rotate * Math.PI / 180);
				commands.put(c, rotateCommand);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Broj u komandi rotiranja se ne može parsirati!");
			}
			break;
		case "push":
			commands.put(c, new PushCommand());
			break;
		case "pop":
			commands.put(c, new PopCommand());
			break;
		case "color":
			try {
				Color color = Color.decode("#" + parts[1]);
				ColorCommand colorCommand = new ColorCommand(color);
				commands.put(c, colorCommand);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Broj u komandi bojanja se ne može parsirati!");
			}
			break;
		default:
			throw new RuntimeException("Nepoznata akcija!");
		}

		return this;
	}

	@Override
	public LSystemBuilder registerProduction(char c, String s) {
		productions.put(c, s);

		return this;
	}

	@Override
	public LSystemBuilder configureFromText(String[] strings) {

		for (String line : strings) {
			if (line.equals("")) {
				continue;
			}

			String[] parts = line.split("\\s+");

			switch (parts[0]) {
			case "origin":
				if (parts.length != 3) {
					throw new RuntimeException("Invalid type of arguments for origin!");
				}

				try {
					double x = Double.parseDouble(parts[1]);
					double y = Double.parseDouble(parts[2]);

					origin = new Vector2D(x, y);
				} catch (NumberFormatException ex) {
					throw new RuntimeException("Origin is not valid!");
				}
				break;
			case "angle":
				if (parts.length != 2) {
					throw new RuntimeException("Invalid number of arguments for angle!");
				}

				try {
					this.angle = Double.parseDouble(parts[1]);
				} catch (NumberFormatException ex) {
					throw new RuntimeException("Angle is not valid!");
				}
				break;
			case "unitLength":
				if (parts.length != 2) {
					throw new RuntimeException("Unit Length is not valid!");
				}

				try {
					this.unitLength = Double.parseDouble(parts[1]);
				} catch (NumberFormatException ex) {
					throw new RuntimeException("Unit Length Degree Scaler is not valid!");
				}
				break;
			case "unitLengthDegreeScaler":
				if (parts.length != 2 && parts.length != 3 && parts.length != 4) {
					throw new RuntimeException("Angle is not valid!");
				}

				String[] unitDegreeArray = Arrays.copyOfRange(parts, 1, parts.length);

				String unitDegree = Arrays.stream(unitDegreeArray).collect(Collectors.joining(""));

				String[] unitDegreeParts = unitDegree.split("/");

				if (unitDegreeParts.length != 1 && unitDegreeParts.length != 2) {
					throw new RuntimeException("Unit Length Degree Scaler nije dobro zadan!");
				}

				try {
					double firstNumber = Double.parseDouble(unitDegreeParts[0]);
					double secondNumber = 1;

					if (unitDegreeParts.length == 2) {

						secondNumber = Double.parseDouble(unitDegreeParts[1]);
					}

					this.unitLengthDegreeScaler = firstNumber / secondNumber;
				} catch (NumberFormatException ex) {
					throw new RuntimeException("Angle nije dobro zadan!");
				}
				break;
			case "command":
				if (parts.length != 3 && parts.length != 4) {
					throw new RuntimeException("Invalid number of command argument!");
				}

				if (parts[1].length() != 1) {
					throw new RuntimeException("Symbol of command is not valid.!");
				}

				char symbol = parts[1].charAt(0);
				String command = parts[2];

				if (parts.length == 4) {
					command += " " + parts[3];
				}

				this.registerCommand(symbol, command);
				break;
			case "axiom":
				if (parts.length != 2) {
					throw new RuntimeException("Axiom is not valid!");
				}

				this.axiom = parts[1];
				break;
			case "production":
				if (parts.length != 3) {
					throw new RuntimeException("Production is not valid!");
				}

				// symbol of profuction
				if (parts[1].length() != 1) {
					throw new RuntimeException("Symbol of production is not valid!");
				}

				char symbolProduction = parts[1].charAt(0);
				this.registerProduction(symbolProduction, parts[2]);
				break;
			default:
				throw new RuntimeException("Command is not recognized.!");
			}

		}

		return this;
	}

	@Override
	public LSystem build() {
		return new LSystem() {
			@Override
			public String generate(int i) {
				// beginning
				String generation = axiom;

				StringBuilder producedGeneration = new StringBuilder();

				for (int iteration = 1; iteration <= i; iteration++) {

					// System.out.println("Iteration : " + iteration );
					char[] characters = generation.toCharArray();
					for (int j = 0; j < generation.length(); j++) {

						// System.out.println(characters[j] + " ");
						// store the command
						String command = (String) LSystemBuilderImpl.this.productions.get(characters[j]);
						if (command != null) {
							producedGeneration.append(command);
						} else {
							// if there is no command with the key character[j], just write the character
							producedGeneration.append(characters[j]);
						}
					}

					generation = producedGeneration.toString();
					producedGeneration.setLength(0);

				}

				return generation;
			}

			@Override
			public void draw(int i, Painter painter) {
				Context context = new Context();
				TurtleState turtleState = new TurtleState(origin,
						new hr.fer.zemris.lsystem.Vector2D(1, 0).rotated(angle).normalized(), Color.BLACK,
						unitLength * Math.pow(unitLengthDegreeScaler, i));
				context.pushState(turtleState);

				// for each character, get the command if that one exists in dictionary
				char[] getCommands = generate(i).toCharArray();

				for (char c : getCommands) {
					Command command = (Command) LSystemBuilderImpl.this.commands.get(c);
					// if the command with that key exists, than execute..
					if (command != null) {
						(command).execute(context, painter);
					}
				}

			}
		};
	}
}