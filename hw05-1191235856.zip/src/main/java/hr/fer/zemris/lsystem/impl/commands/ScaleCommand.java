package hr.fer.zemris.lsystem.impl.commands;

import hr.fer.zemris.lsystem.impl.Command;
import hr.fer.zemris.lsystem.impl.Context;
import hr.fer.zemris.lsystem.impl.TurtleState;
import hr.fer.zemris.lsystems.Painter;

public class ScaleCommand implements Command {

	private double factor;

	public ScaleCommand(double factor) {
		super();
		this.factor = factor;
	}

	public double getFactor() {
		return factor;
	}

	public void setFactor(double factor) {
		this.factor = factor;
	}

	public void execute(Context ctx, Painter painter) {
		TurtleState current = ctx.getCurrentState();
		current.setMovement(current.getMovement() * factor);
	}
}
