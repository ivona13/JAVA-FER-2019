package hr.fer.zemris.lsystem.impl;

import hr.fer.zemris.lsystems.Painter;

public interface Command {
	void execute(Context ctx, Painter painter);
}
