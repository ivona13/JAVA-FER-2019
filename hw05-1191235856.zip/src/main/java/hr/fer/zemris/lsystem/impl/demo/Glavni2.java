package hr.fer.zemris.lsystem.impl.demo;

import hr.fer.zemris.lsystem.impl.LSystemBuilderImpl;
import hr.fer.zemris.lsystems.LSystem;
import hr.fer.zemris.lsystems.LSystemBuilderProvider;
import hr.fer.zemris.lsystems.gui.LSystemViewer;

public class Glavni2 {
	private static LSystem hilbertCurve(LSystemBuilderProvider provider) {
		return provider.createLSystemBuilder()
		.registerCommand('F', "draw 1")
		.registerCommand('+', "rotate 90")
		.registerCommand('-', "rotate -90")
		.setOrigin(0.05, 0.05)
		.setAngle(0)
		.setUnitLength(0.9)
		.setUnitLengthDegreeScaler(1.0/2.0)
		.registerProduction( 'L', "+RF-LFL-FR+")
		.registerProduction('R', "-LF+RFR+FL-")
		.setAxiom("L")
		.build();
		}

	public static void main(String[] args) {
		LSystemViewer.showLSystem(hilbertCurve(LSystemBuilderImpl::new));

	}
}
