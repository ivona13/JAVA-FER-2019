package hr.fer.zemris.lsystem.impl;

import hr.fer.zemris.java.custom.collections.ObjectStack;

public class Context {

	public ObjectStack<TurtleState> stack;
	

	public Context() {
		this.stack = new ObjectStack<TurtleState>();
	}

	public TurtleState getCurrentState() {
		if (stack.isEmpty()) {
			throw new RuntimeException("No more turtle states.");
		}

		return (TurtleState) stack.peek();
	}

	public void pushState(TurtleState state) {
		this.stack.push(state);
	}

	public void popState() {
		if (stack.isEmpty()) {
			throw new RuntimeException("No more states to be popped.");
		}

		stack.pop();
	}
}
