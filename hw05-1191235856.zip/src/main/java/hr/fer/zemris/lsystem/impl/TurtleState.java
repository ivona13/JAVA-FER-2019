package hr.fer.zemris.lsystem.impl;

import java.awt.Color;

import hr.fer.zemris.lsystem.Vector2D;

public class TurtleState {

	private Vector2D position;

	private Vector2D direction;

	private Color color;

	private double movement;

	public TurtleState(Vector2D position, Vector2D direction, Color color, double movement) {
		this.position = position;
		this.direction = direction;
		this.color = color;
		this.movement = movement;
	}

	public Vector2D getPosition() {
		return position;
	}

	public Vector2D getDirection() {
		return direction;
	}

	public Color getColor() {
		return color;
	}

	public double getMovement() {
		return movement;
	}

	
	public void setPosition(Vector2D position) {
		this.position = position;
	}

	public void setDirection(Vector2D direction) {
		this.direction = direction;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public void setMovement(double movement) {
		this.movement = movement;
	}

	public TurtleState copy() {
		return new TurtleState(position.copy(), direction.copy(), new Color(color.getRGB()), movement);
	}
}
