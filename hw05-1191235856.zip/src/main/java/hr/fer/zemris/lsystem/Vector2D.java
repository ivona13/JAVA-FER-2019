package hr.fer.zemris.lsystem;

/**
 * This class represents Vector in two dimension space. Every VectorD2D has x
 * and y coordinate.
 * 
 * @author Ivona
 *
 */
public class Vector2D {

	/**
	 * x - coordinate of vector
	 */
	private double x;

	/**
	 * y - coordinate of vector
	 */
	private double y;

	/**
	 * Constructor of the vector.
	 * 
	 * @param x x - coordinate of vector
	 * @param y y - coordinate of vector
	 */
	public Vector2D(double x, double y) {
		super();
		this.x = x;
		this.y = y;
	}

	/**
	 * Getter of x - coordinate
	 * 
	 * @return x - coordinate of the vector
	 */
	public double getX() {
		return x;
	}

	/**
	 * Getter of y - coordinate
	 * 
	 * @return y - coordinate of the vector
	 */
	public double getY() {
		return y;
	}

	/**
	 * This method is used for translating vector with input offset.
	 * 
	 * @param offset Offset of the vector to be translated
	 */
	public void translate(Vector2D offset) {
		x += offset.getX();
		y += offset.getY();
	}

	/**
	 * This method is used for translating vector with input offset.
	 * 
	 * @param offset Offset of the vector to be translated
	 * @return Translated vector
	 */
	public Vector2D translated(Vector2D offset) {
		return new Vector2D(x + offset.getX(), y + offset.getY());
	}

	/**
	 * This method is used for rotating the vector for some angle.
	 * 
	 * @param angle Angle of rotation
	 */
	public void rotate(double angle) {
		double rotatedX = Math.cos(angle) * x - Math.sin(angle) * y;
		double rotatedY = Math.sin(angle) * x + Math.cos(angle) * y;

		this.x = rotatedX;
		this.y = rotatedY;
	}

	/**
	 * This method is used for rotating the vector for some angle.
	 * 
	 * @param angle Angle of rotation
	 * @return Vector2D obtained by rotating the vector for angle
	 */
	public Vector2D rotated(double angle) {
		return new Vector2D(Math.cos(angle) * x - Math.sin(angle) * y, Math.sin(angle) * x + Math.cos(angle) * y);
	}

	/**
	 * This method is used for scaling the vector by input scaler.
	 * 
	 * @param scaler Scalar
	 */
	public void scale(double scaler) {
		x *= scaler;
		y *= scaler;
	}

	/**
	 * This method is used for scaling the vector by input scaler.
	 * 
	 * @param scaler Scalar
	 * @return Vector obtained by scaling the vector
	 */
	public Vector2D scaled(double scaler) {
		return new Vector2D(x * scaler, y * scaler);
	}

	/**
	 * This method is used for copying the vector.
	 * 
	 * @return Vector which is copy of this vector.
	 */
	public Vector2D copy() {
		return new Vector2D(x, y);
	}

	public Vector2D normalized() {
		double magnitude = Math.sqrt(x * x + y * y);

		if (magnitude <= 0) {
			return new Vector2D(x, y);
		}

		return new Vector2D(x / magnitude, y / magnitude);
	}
}
