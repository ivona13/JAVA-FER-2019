package hr.fer.zemris.java.hw05.db;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDB {
	/**
	 * Main method
	 *
	 * @param args Arguments of command line
	 */
	public static void main(String[] args) {

		List<String> lines = null;

		try {
			lines = Files.readAllLines(Paths.get("database.txt"), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.out.println("Problem while loading file.");
			System.exit(1);
		}

		StudentDatabase database = new StudentDatabase(lines);
		Scanner sc = new Scanner(System.in);
		String query;

		while (true) {
			System.out.print("> ");
			query = sc.nextLine();
			query = query.trim();
			if (query.equals("exit")) {
				System.out.println("Goodbye!");
				break;
			}

			if (query.isEmpty()) {
				System.out.println("Empty command!");
				continue;
			}

			QueryParser parser;
			try {
				parser = new QueryParser(query.substring("query".length()));
			} catch (RuntimeException ex) {
				System.out.println("Invalid command!");
				continue;
			}
			List<StudentRecord> records;

			if (parser.isDirectQuery()) {
				System.out.println("Using index for record retrieval.");
				records = new ArrayList<>();
				StudentRecord record = database.forJMBAG(parser.getQueriedJMBAG());
				if (record != null) {
					records.add(record);
				}

			} else {
				records = database.filter(new QueryFilter(parser.getQuery()));
			}

			if (records.size() > 0) {
				write(records);
			}
			System.out.println("Records selected: " + records.size());
		}

		sc.close();
	}

	/**
	 * This method is used for transforming given List of {@link StudentRecord} into
	 * String that can be outputted to console.
	 *
	 * @param records List of {@link StudentRecord}
	 * @return
	 * @return String for output
	 */
	private static void write(List<StudentRecord> records) {
		int longestJmbag = 0;
		int longestLastName = 0;
		int longestFirstName = 0;
		int longestFinalGrade = 0;

		for (StudentRecord record : records) {
			if (record.getJmbag().length() > longestJmbag) {
				longestJmbag = record.getJmbag().length();
			}
			if (record.getLastName().length() > longestLastName) {
				longestLastName = record.getLastName().length();
			}
			if (record.getFirstName().length() > longestFirstName) {
				longestFirstName = record.getFirstName().length();
			}
			if (record.getFinalGrade().length() > longestFinalGrade) {
				longestFinalGrade = record.getFinalGrade().length();
			}
		}

		StringBuilder string = new StringBuilder();
		string.append("+");
		for (int i = 0; i < longestJmbag + 2; i++)
			string.append("=");
		string.append("+");
		for (int i = 0; i < longestLastName + 2; i++)
			string.append("=");
		string.append("+");
		for (int i = 0; i < longestFirstName + 2; i++)
			string.append("=");
		string.append("+");

		for (int i = 0; i < longestFinalGrade + 2; i++)
			string.append("=");
		string.append("+");

		System.out.println(string.toString());

		for (StudentRecord record : records) {
			StringBuilder content = new StringBuilder();
			content.append("| ");
			content.append(record.getJmbag());
			content.append(" | ");
			content.append(record.getLastName());
			for(int i = 0; i < ( - record.getLastName().length() + longestLastName); i++)
				content.append(" ");
			content.append(" | ");
			content.append(record.getFirstName());
			for(int i = 0; i < ( - record.getFirstName().length() + longestFirstName); i++)
				content.append(" ");
			content.append(" | ");
			content.append(record.getFinalGrade());
			for(int i = 0; i < ( - record.getFinalGrade().length() + longestFinalGrade); i++)
				content.append(" ");
			content.append(" | ");
			System.out.println(content.toString());
		}
		System.out.println(string.toString());

	}
}
