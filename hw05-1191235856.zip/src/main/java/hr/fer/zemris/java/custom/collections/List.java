package hr.fer.zemris.java.custom.collections;

/**
 * This interface inherits interface Collection.
 * 
 * @author Ivona
 *
 */
public interface List<T> extends Collection<T>   {

	/**
	 * This method get Object with index index.
	 * 
	 * @param index Position of Object that we want to get.
	 * @return Object
	 */
	Object get(int index);

	/**
	 * This method inserts Object value in a position position.
	 * 
	 * @param value    Object to be added to Collection
	 * @param position Place to add Object value
	 */
	void insert(T value, int position);

	/**
	 * This method gets index of Object value.
	 * 
	 * @param value Object which position is questioned.
	 * @return position
	 */
	int indexOf(Object value);

	/**
	 * This method removes Object placed on position index.
	 * 
	 * @param index Position on which we want to remove Object
	 */
	void remove(int index);
}
