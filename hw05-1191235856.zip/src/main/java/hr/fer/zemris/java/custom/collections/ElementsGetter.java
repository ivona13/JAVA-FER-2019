package hr.fer.zemris.java.custom.collections;

import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;

/**
 * This interface lists methods which are used by an Object whose task is to
 * return element by element of some Collection when user asks for it.
 * 
 * @author Ivona
 *
 */
public interface ElementsGetter<T> {

	/**
	 * This method determines if there is any element in Collection which has not
	 * been returned to user by this method yet.
	 * 
	 * @return <code>true</code> if there is any element which user has not recieved
	 *         yet
	 */
	public boolean hasNextElement();

	/**
	 * This method gives next undelivered Object to user.
	 * 
	 * @return Object that has not been delievered to user yet.
	 * @throws NoSuchElementException if there is no more elements to be reached.
	 * @throws ConcurrentModificationException if Collection has changed.
	 */
	public Object getNextElement();

	/**
	 * This method calls input Processor p on every left element of the Collection.
	 * 
	 * @param p Processor which will be executed on every left element of Collection
	 */
	public default void forEachRemaining(Processor p) {
		while (hasNextElement()) {
			p.process(getNextElement());
		}
	}

	/**
	 * This method is used to make reference to Collection's elements.
	 */
	public void active();

}
