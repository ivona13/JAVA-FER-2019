package hr.fer.zemris.java.custom.collections;

/**
 * This class represents Dyctionary as a type of Collection. Dyctionary consists
 * of elements called KeyValue. Every element KeyValue consists of key and its
 * value.
 * 
 * @author Ivona
 *
 * @param <K> type of Key
 * @param <T> type of Value
 */
public class Dictionary<K, V> {

	/**
	 * This class represents basic unit of collection Dictionary. It consists of key
	 * and its value.
	 * 
	 * @author Ivona
	 *
	 */
	private class KeyValue {
		/**
		 * Key of pair KeyValue in Dictionary
		 */
		private K key;

		/**
		 * Value of pair KeyValue in Dictionary
		 */
		private V value;

		/**
		 * Basic constructor of KeyValue.
		 * 
		 * @param key   Key of KeyValue
		 * @param value Value of KeyValue
		 */
		public KeyValue(K key, V value) {
			this.key = key;
			this.value = value;
		}

		@SuppressWarnings("unchecked")
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			KeyValue keyValue = (KeyValue) obj;
			if (keyValue.key != key)
				return false;
			if (keyValue.value != value)
				return false;
			return true;
		}

	}

	/**
	 * It is used for storing pairs in Dictionary. In other words, it is an array of
	 * elements KeyValues.
	 */
	private ArrayIndexedCollection<KeyValue> array;

	/**
	 * Basic constructor of Dictionary.
	 */
	public Dictionary() {
		this.array = new ArrayIndexedCollection<Dictionary<K, V>.KeyValue>();
	}

	/**
	 * This constructor takes input array of type KeyValue and initializes array of
	 * Dictionary as the input array.
	 */
	public Dictionary(ArrayIndexedCollection<KeyValue> array) {
		this.array = (ArrayIndexedCollection<Dictionary<K, V>.KeyValue>) new ArrayIndexedCollection<KeyValue>();
		this.array = (ArrayIndexedCollection<Dictionary<K, V>.KeyValue>) array;
	}

	/**
	 * This method checks if Dictionary is empty.
	 * 
	 * @return <code>true</code> if Dictionary is empty, otherwise
	 *         <code>false</code>
	 */
	public boolean isEmpty() {
		return array.isEmpty();
	}

	/**
	 * This method returns the size of Dictionary.
	 * 
	 * @return Size of Dictionary
	 */
	public int size() {
		return array.size();
	}

	/**
	 * This method clears the Dictionary.
	 */
	public void clear() {
		array.clear();
	}

	/**
	 * This method puts KeyValue(key, value) in the Dictionary if it does not exist.
	 * If there already exists the key, this method only changes the value of Value.
	 * 
	 * @param key   Key of KeyValue
	 * @param value Value of KeyValue
	 * 
	 * @throws NullPointerException if key is null. It is allowed for Value to be
	 *                              null.
	 */
	public void put(K key, V value) {
		if (key == null) {
			throw new NullPointerException("Key cannot be null.");
		}

		for (int i = 0; i < array.size(); i++) {
			if (array.get(i).key.equals(key)) {
				array.get(i).value = value;
				return;
			}
		}

		KeyValue k = new KeyValue(key, value);
		array.add(k);
	}

	/**
	 * This method gets the value whose key equals Key if that one exists. Key can
	 * be with type of Object. We compare keys with method equals, which compares
	 * its types too.
	 * 
	 * @param key Key whose element we want to achieve.
	 * @return Value whose key if Key, if the Key exists; otherwise null
	 * 
	 * @throws NullPointerException if the Key is null; Key is not allowed to be null.
	 */
	@SuppressWarnings("unchecked")
	public V get(Object key) {
		if (key == null) {
			throw new NullPointerException("No such key.");
		}

		Object[] collectionArray = (V[]) array.toArray();

		for (Object keyValue : collectionArray) {
			if (((KeyValue) keyValue).key.equals(key)) {
				return ((KeyValue) keyValue).value;
			}
		}
		return null;
	}

}
