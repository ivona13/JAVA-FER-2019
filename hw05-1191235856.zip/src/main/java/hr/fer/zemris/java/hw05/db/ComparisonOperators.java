package hr.fer.zemris.java.hw05.db;

/**
 * This class represents Comparison Operators <, <=, >, >=, =, !=, *.
 * 
 * @author ivona
 */
public class ComparisonOperators {

	/**
	 * This operator returns <code>true</code> if value1 < value2; otherwise
	 * <code>false</false>
	 * 
	 */
	public static final IComparisonOperator LESS = (value1, value2) -> value1.compareTo(value2) < 0;

	/**
	 * This operator returns <code>true</code> if value1 <= value2; otherwise
	 * <code>false</code>
	 */
	public static final IComparisonOperator LESS_OR_EQUAL = (value1, value2) -> value1.compareTo(value2) <= 0;

	/**
	 * This operator returns <code>true</code> if value1 > value2; otherwise
	 * <code>false</code>
	 */
	public static final IComparisonOperator GREATER = (value1, value2) -> value1.compareTo(value2) > 0;

	/**
	 * This operator returns <code>true</code> if value1 >= value2; otherwise
	 * <code>false</code>
	 */
	public static final IComparisonOperator GREATER_OR_EQUAL = (value1, value2) -> value1.compareTo(value2) >= 0;

	/**
	 * This operator returns <code>true</code> if value1 == value2; otherwise
	 * <code>false</code>
	 */
	public static final IComparisonOperator EQUALS = (value1, value2) -> value1.compareTo(value2) == 0;

	/**
	 * This operator returns <code>true</code> if value1 != value2; otherwise
	 * <code>false</code>
	 */
	public static IComparisonOperator NOT_EQUALS = (value1, value2) -> value1.compareTo(value2) != 0;

	/**
	 * In LIKE operator, first argument will be string to be checked, and the second
	 * argument pattern to be checked. It works as LIKe operator in SQL.
	 */
	public static IComparisonOperator LIKE = (value1, value2) -> {

		int indexOfLikeOperator = value2.indexOf("*");

		if (indexOfLikeOperator != -1) {
			// * appers in String value2
			if (value2.lastIndexOf("*") != indexOfLikeOperator) {
				throw new RuntimeException(" * operator is allowed to appear only once.");
			}

			// * last character
			if (indexOfLikeOperator == value2.length() - 1) {
				return value1.subSequence(0, value2.length() - 1).equals(value2.subSequence(0, value2.length() - 1));
			}

			// * is not the last character
			String[] parts = value2.split("\\*");
			String firstPart = parts[0];
			String secondPart = parts[1];

			if (secondPart.isEmpty()) {
				return firstPart.equals(value1.subSequence(0, firstPart.length()));
			}

			return (firstPart.equals(value1.subSequence(0, firstPart.length()))
					&& secondPart.equals(value1.subSequence(value1.length() - secondPart.length(), value1.length())));
		}

		return value1.equals(value2);

	};

}