package hr.fer.zemris.java.hw05.db;

/**
 * This class represents request of user through expression with three
 * variables: field to get the value of, comparios operator and string to
 * request something on.
 * 
 * @author ivona
 *
 */
public class ConditionalExpression {

	/**
	 * Field whose information we want to get.
	 */
	private IFieldValueGetter fieldGetter;

	/**
	 * Comparison operator
	 */
	private IComparisonOperator comparisonOperator;

	/**
	 * Literal string
	 */
	private String stringLiteral;

	/**
	 * Basic constructor
	 * 
	 * @param fieldGetter        Field getter
	 * @param stringLiteral      Literal String
	 * @param comparisonOperator Comparison operator
	 */
	public ConditionalExpression(IFieldValueGetter fieldGetter, String stringLiteral,
			IComparisonOperator comparisonOperator) {

		this.fieldGetter = fieldGetter;
		this.comparisonOperator = comparisonOperator;
		this.stringLiteral = stringLiteral;
	}

	/**
	 * Getter of field
	 * 
	 * @return fieldGetter
	 */
	public IFieldValueGetter getFieldGetter() {
		return fieldGetter;
	}

	/**
	 * Getter of comparison operator
	 * 
	 * @return comparisonOperator
	 */
	public IComparisonOperator getComparisonOperator() {
		return comparisonOperator;
	}

	/**
	 * Getter for literal string
	 * 
	 * @return stringLiterals
	 */
	public String getStringLiteral() {
		return stringLiteral;
	}

}
