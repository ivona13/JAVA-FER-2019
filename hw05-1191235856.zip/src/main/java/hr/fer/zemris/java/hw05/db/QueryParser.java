package hr.fer.zemris.java.hw05.db;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents a parser of query statement and it gets query string
 * through constructor (actually, it must get everything user entered after
 * query keyword; you must skip this keyword)
 * 
 * @author ivona
 *
 */
public class QueryParser {

	/**
	 * Lexer for generating tokens
	 */
	private QueryLexer lexer;

	/**
	 * List of parsed expressions.
	 */
	private List<ConditionalExpression> queries;

	/**
	 * Basic constructor.
	 *
	 * @param data Query text
	 */
	public QueryParser(String data) {
		this.lexer = new QueryLexer(data);
		this.queries = new ArrayList<>();
		parse();
	}

	/**
	 * This method check if query is direct. Query is direct if it is of the form
	 * jmbag="xxx" (i.e. it must have only one comparison, on attribute jmbag , and
	 * operator must be equals).
	 *
	 * @return True if it is, false otherwise
	 */
	public boolean isDirectQuery() {
		if (queries.size() != 1) {
			return false;
		}

		ConditionalExpression expression = queries.get(0);

		return expression.getFieldGetter() == FieldValueGetters.JMBAG
				&& expression.getComparisonOperator() == ComparisonOperators.EQUALS;
	}

	/**
	 * This method is used for getting jmbag of direct query.
	 *
	 * @return JMBAG of given query
	 * @throws IllegalStateException If query is not direct
	 */
	public String getQueriedJMBAG() {
		if (!isDirectQuery()) {
			throw new IllegalStateException("Not direct query!");
		}
	//	System.out.println("Direct jmbag");
	//	System.out.println(queries.get(0).getStringLiteral());
		return queries.get(0).getStringLiteral();
	}

	/**
	 * This method is used for getting list of ConditionalExpression parsed for
	 * query.
	 *
	 * @return List of {@link ConditionalExpression}
	 */
	public List<ConditionalExpression> getQuery() {
		return queries;
	}

	/**
	 * This method is used for parsing query given in constructor into {@link List}
	 * of {@link ConditionalExpression}.
	 */
	private void parse() {

		QueryToken token = lexer.nextToken();
		// System.out.println(token.getType());

		while (true) {
			if (token.getType() != QueryTokenType.FIELD) {
				throw new RuntimeException("First token is not field!");
			}
			IFieldValueGetter getter = parseGetter(token);

			token = lexer.nextToken();
			// System.out.println(token.getType());

			if (token.getType() != QueryTokenType.OPERATOR) {
				throw new RuntimeException("Second token is not operator!");
			}

			IComparisonOperator operator = parseOperator(token);
			token = lexer.nextToken();
			// System.out.println(token.getType());

			if (token.getType() != QueryTokenType.STRING) {
				throw new RuntimeException("Third token is not string!");
			}

			String stringLiteral = token.getValue();

			queries.add(new ConditionalExpression(getter, stringLiteral, operator));

			token = lexer.nextToken();

			if (token.getType() == QueryTokenType.AND) {
				token = lexer.nextToken();
			} else if (token.getType() == QueryTokenType.EOF) {
				break;
			} else {
				throw new RuntimeException("Could not be parsed!");
			}

		}
	}

	/**
	 * This method is used for parsing tokne into ICOmp.Operator
	 *
	 * @param token {@link QueryToken}
	 * @return Parsed {@link IComparisonOperator}
	 */
	private IComparisonOperator parseOperator(QueryToken token) {
		switch (token.getValue()) {
		case ">":
			return ComparisonOperators.GREATER;
		case ">=":
			return ComparisonOperators.GREATER_OR_EQUAL;
		case "<":
			return ComparisonOperators.LESS;
		case "<=":
			return ComparisonOperators.LESS_OR_EQUAL;
		case "=":
			return ComparisonOperators.EQUALS;
		case "!=":
			return ComparisonOperators.NOT_EQUALS;
		case "LIKE":
			return ComparisonOperators.LIKE;
		default:
			throw new RuntimeException("Invalid operator!");
		}
	}

	/**
	 * This method is used for parsing QueryToken into IFieldValueGetter
	 *
	 * @param token input QueryToken
	 * @return Parsed IFIeldValueGetter
	 */
	private IFieldValueGetter parseGetter(QueryToken token) {
		switch (token.getValue()) {
		case "firstName":
			return FieldValueGetters.FIRST_NAME;
		case "lastName":
			return FieldValueGetters.LAST_NAME;
		case "jmbag":
			return FieldValueGetters.JMBAG;
		default:
			throw new RuntimeException("Invalid getter!");
		}
	}

}
