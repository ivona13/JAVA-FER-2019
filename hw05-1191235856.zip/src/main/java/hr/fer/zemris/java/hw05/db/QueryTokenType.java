package hr.fer.zemris.java.hw05.db;

/**
 * This enum represents types of Query token.
 * 
 * @author ivona
 *
 */
public enum QueryTokenType {

	/**
	 * It could be first_name, last_name, jmbag
	 */
	FIELD,

	/**
	 * >, >=, <, <= , = , !=
	 */
	OPERATOR,

	/**
	 * value of FIELD, FIELD="value"
	 */
	STRING,

	/**
	 * .. AND ... ; logic operator
	 */
	AND,

	/**
	 * End of input
	 */
	EOF

}
