package hr.fer.zemris.java.hw05.db;

/**
 * This class represents group of variables of type IFieldValueGetter. Each of
 * variables gets some value from StudentRecord.
 * 
 * @author ivona
 *
 */
public class FieldValueGetters {

	/**
	 * This variable gets JMBAG of student whose record is StudentRecord.
	 */
	public static final IFieldValueGetter JMBAG = (StudentRecord record) -> {
		return record.getJmbag();
	};

	/**
	 * This variable gets first name of student whose record is StudentRecord.
	 */
	public static final IFieldValueGetter FIRST_NAME = (StudentRecord record) -> {
		return record.getFirstName();
	};

	/**
	 * This variable gets last name of student whose record is StudentRecord.
	 */
	public static final IFieldValueGetter LAST_NAME = (StudentRecord record) -> {
		return record.getLastName();
	};

}
