package hr.fer.zemris.java.hw05.db;

/**
 * This interface models Comparison operators.
 * 
 * @author ivona
 *
 */
public interface IComparisonOperator {

	/**
	 * This method checks if the conditions is satisfied for input values valu1 and
	 * value2.
	 * 
	 * @param value1 first value
	 * @param value2 second value
	 * @return <code>true</code> if values satisfy condition (depends on operator)
	 */
	public boolean satisfied(String value1, String value2);
}
