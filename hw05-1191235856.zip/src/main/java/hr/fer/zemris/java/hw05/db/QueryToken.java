package hr.fer.zemris.java.hw05.db;

/**
 * This class represents query token.
 * 
 * @author ivona
 *
 */
public class QueryToken {

	/**
	 * Value of token
	 */
	private String value;

	/**
	 * Type of token
	 */
	private QueryTokenType type;

	/**
	 * Basic constructor
	 * 
	 * @param value Value
	 * @param type  Type
	 */
	public QueryToken(String value, QueryTokenType type) {
		this.value = value;
		this.type = type;
	}

	/**
	 * Value getter
	 * 
	 * @return value of token
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Type getter
	 * 
	 * @return type of token
	 */
	public QueryTokenType getType() {
		return type;
	}

}
