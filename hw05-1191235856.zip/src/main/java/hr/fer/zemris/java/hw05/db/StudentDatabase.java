package hr.fer.zemris.java.hw05.db;

import java.util.ArrayList;
import java.util.List;

/**
 * This class represents database of students which was created in database.txt.
 * It has List of StrudentRecords and creates a map where the key is JMBAG of
 * Student and its value record of Student. Every student is uniquely determined
 * by its JMBAG.
 * 
 * @author ivona
 *
 */
public class StudentDatabase {

	/**
	 * List of student records
	 */
	private List<StudentRecord> recordsList;

	/**
	 * Map of student records.
	 */
	private SimpleHashtable<String, StudentRecord> recordsMap;

	/**
	 * Getter for list of records
	 * @return recordList
	 */
	public List<StudentRecord> getRecordsList() {
		return recordsList;
	}

	/**
	 * Getter for map with students
	 * @return recordsMap
	 */
	public SimpleHashtable<String, StudentRecord> getRecordsMap() {
		return recordsMap;
	}

	/**
	 * Basic constructor
	 *
	 * @param records List of Strings with details about student - student record
	 */
	public StudentDatabase(List<String> records) {
		this.recordsList = new ArrayList<>(records.size());
		this.recordsMap = new SimpleHashtable<>(records.size());
		parseRecords(records);
	}

	/**
	 * This method is used for parsing student records to database from the List of
	 * Strings.
	 *
	 * @param records String list of Student records
	 */
	private void parseRecords(List<String> records) {

		for (String record : records) {
			String[] parts = record.split("\t");

			if (parts.length != 4) {
				throw new RuntimeException("There is missing information about studetn!");
			}

			try {

				// try to parse to int
				int grade = Integer.parseInt(parts[3]);
				if (grade < 1 || grade > 5) {
					System.out.println("Grade is not in allowed range.");
					return;
				}
			} catch (RuntimeException e) {
				System.out.println("Not valid type of grade.");
			}

			StudentRecord student = new StudentRecord(parts[0], parts[1], parts[2], parts[3]);

			// lets check if there is already student with that jmbag - then throw an
			// exception because it is not allowed
			if (recordsMap.get(parts[0]) != null) {
				throw new RuntimeException("Not valid database: there are two or more students with the same JMBAG.");
			}

			recordsList.add(student);
			recordsMap.put(student.getJmbag(), student);

		}
	}

	/**
	 * This method is used to get StudentRecord for given JMBAG.
	 *
	 * @param jmbag JMBAG of Student
	 * @return StudentRecord whose jmbag equals to input jmbag 
	 */
	public StudentRecord forJMBAG(String jmbag) {
		return recordsMap.get(jmbag);
	}

	/**
	 * This method is used for filter database with given filter, which means
	 * that is accept all Students who satisfy the condition of filter. 
	 *
	 * @param filter Filter with appropriate attribute to select students
	 * @return Database after filtering 
	 */
	public List<StudentRecord> filter(IFilter filter) {
		List<StudentRecord> filteredDatabase = new ArrayList<>();

		for (StudentRecord studentRecord : recordsList) {
			if (filter.accepts(studentRecord)) {
				filteredDatabase.add(studentRecord);
			}
		}

		return filteredDatabase;
	}
}
