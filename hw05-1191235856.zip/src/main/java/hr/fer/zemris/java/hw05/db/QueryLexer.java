package hr.fer.zemris.java.hw05.db;


/**
 * * This class represents QueryLexer. It is used for parsing text into
 * QueryToken.
 * 
 * @author ivona
 *
 */
public class QueryLexer {

	/**
	 * Char array of input text.
	 */
	private char[] data;

	/**
	 * Last generated token.
	 */
	private QueryToken token;

	/**
	 * Index of first not parsed character in array.
	 */
	private int currentIndex;

	/**
	 * Basic constructor.
	 *
	 * @param input Text that will be parsed into tokens
	 */
	public QueryLexer(String string) {
		currentIndex = 0;
		this.data = string.toCharArray();
	}

	/**
	 * This method is used to generate new token.
	 *
	 * @return New token
	 */
	public QueryToken nextToken() {
		
		
		
		QueryTokenType type = QueryTokenType.EOF;

		token = new QueryToken(null, type);

		boolean quotes = false;
		StringBuilder string = new StringBuilder();

		if (token.getType() == QueryTokenType.EOF && currentIndex > data.length) {
			System.out.println("Current index: " + currentIndex);
			throw new RuntimeException("We came to the end. no more tokens.");
		}

		for (; currentIndex < data.length; currentIndex++) {

			skipSpaces();
			if(currentIndex > data.length) {
				break;
			}

			// if (token.getType() == QueryTokenType.EOF && currentIndex >= data.length) {
			// throw new RuntimeException("We came to the end.");
			// }

			if (!quotes) {
				skipSpaces();
				if (data[currentIndex] == '"') {
					quotes = true;
					continue;
				}

				if (isOperator()) {
					if (type == QueryTokenType.EOF) {
						checkValidIndex();
						type = QueryTokenType.OPERATOR;
						string.append(data[currentIndex]);
						currentIndex++;
						if (!isOperator()) {
							return new QueryToken(string.toString(), type);
						}
					} else if (type == QueryTokenType.OPERATOR) {
						string.append(data[currentIndex++]);
						return new QueryToken(string.toString(), type);
					}
				}
				// otherwise
				string.append(data[currentIndex]);
				// System.out.println(string.toString());
				type = QueryTokenType.FIELD;
				//System.out.println("Tu sam.");
				if (data[currentIndex + 1] == ' ' && !string.toString().toUpperCase().equals("AND")
						&& !string.toString().toUpperCase().equals("LIKE")) {
					currentIndex++;
					//System.out.println("Ovdje sam");
					return new QueryToken(string.toString(), QueryTokenType.FIELD);
				}

				if (checkIfSpace()) {

					return new QueryToken(string.toString(), QueryTokenType.FIELD);
				}
				currentIndex++;
				if (isOperator()) {
					// System.out.println("Tu sam.");
					// System.out.println(string.toString());
					return new QueryToken(string.toString(), type);
				}

				// checkIfSpace();
				//System.out.println(string.toString().toUpperCase());
				if (string.toString().toUpperCase().equals("AND") || string.toString().toUpperCase().equals("LIKE")) {
					//System.out.println("tu sam , nasao sam and ili like");
					type = QueryTokenType.AND;
					if (string.toString().toUpperCase().equals("LIKE")) {
						type = QueryTokenType.OPERATOR;
					}
					return new QueryToken(string.toString(), type);
				}

				skipSpaces();
				if (data[currentIndex + 1] == '"') {
					return new QueryToken(string.toString(), type);
				}
				currentIndex--;

			}

			if (quotes) {
				// we came to the end " "
				if (data[currentIndex] == '"') {
					currentIndex++;
					type = QueryTokenType.STRING;
					return new QueryToken(string.toString(), type);
				}
				string.append(data[currentIndex]);
				skipSpaces();
			}

		}

		if(currentIndex == data.length) {
			currentIndex++;
			return new QueryToken(null, QueryTokenType.EOF);
		} else {
			throw new RuntimeException("No more tokens.");
		}

	}

	/**
	 * This method is used to check if <code>data[currentIndex]</code> is of type
	 * operator
	 *
	 * @return <code>true</code> if <code>data[currentIndex]</code> is operator;
	 *         otherwise <code>false</code>
	 */
	private boolean isOperator() {
		return data[currentIndex] == '=' || data[currentIndex] == '>' || data[currentIndex] == '<'
				|| data[currentIndex] == '!';
	}

	/**
	 * This method is used for getting last generated token.
	 *
	 * @return Last generated token
	 */
	public QueryToken getToken() {
		return token;
	}

	/**
	 * This method is used to check if currentIndex is on space.
	 *
	 * @return <code>true</code> if <code>data[currentINdex] == " "</code>;
	 *         otherwise <code>false</code>
	 */
	private boolean checkIfSpace() {
		return data[currentIndex] == ' ' || data[currentIndex] == '\r' || data[currentIndex] == '\t'
				|| data[currentIndex] == '\n';
	}

	/**
	 * This method is used for skipping spaces.
	 */
	private void skipSpaces() {

		while (true) {
			if (currentIndex >= data.length || !checkIfSpace()) {
				break;
			}
			currentIndex++;
		}
	}

	/**
	 * This method is used for validation of currentIndex
	 */
	private void checkValidIndex() {
		if (currentIndex >= data.length) {
			throw new RuntimeException("We already reached the end of input!");
		}
	}

}
