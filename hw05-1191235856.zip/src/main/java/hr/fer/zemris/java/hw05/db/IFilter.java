package hr.fer.zemris.java.hw05.db;

/**
 * This interface is used to represent filters which have single method whose
 * task is to accept input student record which depends on each filter and its
 * type.
 * 
 * @author ivona
 *
 */
public interface IFilter {

	/**
	 * This method is used to determine if studentRecord will be accepted.
	 * 
	 * @param record input StudentRecord
	 * @return <code>true</code> if StudentRecord is accepted, otherwise
	 *         <code>false</code>
	 */
	public boolean accepts(StudentRecord record);
}
