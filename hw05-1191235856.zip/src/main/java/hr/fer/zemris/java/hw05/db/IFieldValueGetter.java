package hr.fer.zemris.java.hw05.db;

/**
 * This interface represents stategy which is responsible for obtaining a
 * request field value from given StudentRecord.
 * 
 * @author ivona
 *
 */
public interface IFieldValueGetter {

	/**
	 * This method gets some information about StudentRecord; which one exactly
	 * depends on concrete request.
	 * 
	 * @param record Record of students whose information we want to get.
	 * @return information we wanted to get.
	 */
	public String get(StudentRecord record);
}
