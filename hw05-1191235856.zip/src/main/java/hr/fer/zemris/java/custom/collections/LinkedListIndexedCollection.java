package hr.fer.zemris.java.custom.collections;

import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;

/**
 * This class represents linked list indexed collection. It useS linked list for
 * storing Objects.
 * 
 * @author Ivona
 */
public class LinkedListIndexedCollection<T> implements List<T> {

	/**
	 * Variable which determines if there was any modification of List
	 */
	private static long modificationCount;

	/**
	 * Current size of collection.
	 */
	private int size;

	/**
	 * First node of collection.
	 */
	private ListNode<T> first;

	/**
	 * Last node of collection.
	 */
	private ListNode<T> last;

	/**
	 * This class represents list node. It is basic element of this collection.
	 */
	public static class ListNode<T> {

		/**
		 * Previous list node
		 */
		public ListNode<T> previous;

		/**
		 * Next list node
		 */
		public ListNode<T> next;

		/**
		 * Value of node
		 */
		public T value;
	}

	/**
	 * Basic constructor.
	 */
	public LinkedListIndexedCollection() {

	}

	/**
	 * Constructor which initializes collection and adds all elements of given
	 * collection to the new collection.
	 *
	 * @param other Collection whose elements will be added
	 */
	public LinkedListIndexedCollection(Collection<T> other) {
		this();
		addAll(other);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void add(T value) {
		if (value == null) {
			throw new IllegalArgumentException("You cannot add " + value + " to this collection.");
		}

		ListNode<T> novi = new ListNode<T>();
		novi.value = value;
		if (first == null) {
			first = last = novi;
		} else {
			novi.previous = last;
			last.next = novi;
			last = last.next;
		}
		size++;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean contains(Object value) {
		return indexOf(value) != -1;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean remove(Object value) {
		if (indexOf(value) == -1) {
			return false;
		}
		remove(indexOf(value));
		return true;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public T[] toArray() {
		ArrayIndexedCollection<T> array = new ArrayIndexedCollection<T>(this);
		return array.toArray();
	}

	/**
	 * {@inheritDoc}}
	 */
	/*
	 * @Override public void forEach(Processor processor) { for (ListNode node =
	 * first; node != null; node = node.next) { processor.process(node.value); } }
	 */

	/**
	 * This method is used for getting element at given index. Valid index is 0 to
	 * size-1. If index is not valid, it throws {@link IndexOutOfBoundsException}.
	 * 
	 * @param index Index of element which needs to be got
	 * @return Element at given index
	 */
	public Object get(int index) {
		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index should be between 0 and" + (size - 1) + ".");
		}

		ListNode<T> node = first;
		if (index < size / 2) {
			for (int i = 0; i < index; i++) {
				node = node.next;
			}
		} else {
			node = last;
			for (int i = size - 1; i > index; i--) {
				node = node.previous;
			}
		}
		return node.value;

	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void clear() {
		ListNode<T> node = first;
		while (node != null) {
			ListNode<T> next = node.next;
			node.next = node.previous = null;
			node.value = null;
			node = next;
		}
		first = first.previous = first.next = null;
		size = 0;
		modificationCount++;
	}

	/**
	 * This method inserts Object at given position in list. Elements on places
	 * which are >= position will be shifted one place toward the end, so an empty
	 * place will be created at position. Valid positions are 0 to size. If position
	 * is invalid, it throws {@link IllegalArgumentException}.
	 * 
	 * @param value    Object which needs to be inserted to collection
	 * @param position Position in list where Object will be inserted
	 */
	
	public void insert(T value, int position) {

		if (position < 0 || position > size) {
			throw new IllegalArgumentException("Objekt dodajemo na mjestu u rasponu od 0 do " + size + ".");
		}

		if (position == size) {
			add(value);
			return;
		}

		ListNode<T> newNode = new ListNode<T>();
		newNode.value = value;
		// pozicija 0, a lista nije prazna
		if (position == 0) {
			newNode.next = first;
			first.previous = newNode;
			first = newNode;

		} else {
			ListNode<T> node = first;
			for (int i = 0; i < position; i++) {
				node = node.next;
			}
			// u node mi se nalazi čvor na poziciji p, umetni novi ispred njega

			node.previous.next = newNode;
			newNode.previous = node.previous;
			newNode.next = node;
			node.previous = newNode;
		}
		size++;
		modificationCount++;

	}

	/**
	 * This method goes through the list and finds index of the first appearance of
	 * the given value or -1 if the value does not exist in Collection.
	 * 
	 * 
	 * @param value Object whose index will be found
	 * @return Index of element if element exists, -1 otherwise
	 */
	public int indexOf(Object value) {

		if (value.equals(null)) {
			return -1;
		}
		ListNode<T> node = first;
		for (int i = 0; i < size; i++) {
			if (node.value.equals(value)) {
				return i;
			}
			node = node.next;

		}
		return -1;
	}

	/**
	 * This method is used for removing element at given index in list. Valid index
	 * is 0 to size-1. If index is not valid, it throws
	 * {@link IndexOutOfBoundsException}.
	 *
	 * @param index Index of element which will be removed
	 */
	public void remove(int index) {

		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index mora biti u rasponu od 0 do " + size + ".");
		}

		if (first == null) {
			return;
		}

		ListNode<T> node = first;

		// brišemo početni čvor liste
		if (index == 0) {
			first = node.next;
		}

		// tražimo prethodni čvor onog kojeg želimo obrisati
		for (int i = 0; node != null && i < index - 1; i++) {
			node = node.next;
		}

		// zelimo izbrisati node.next (na node smo stali, prethodnik ovog kojeg brisemo)
		ListNode<T> next = node.next.next;
		node.next = next;
		modificationCount++;

	}

	/**
	 * This class represents some sort of Object whose task is to enable user to get
	 * element by element of the Collection.
	 * 
	 * @author Ivona
	 *
	 */
	private static class ElementsGetterList<T> implements ElementsGetter<T> {

		/**
		 * Index of the first unreturned element
		 */
		private int i;

		/**
		 * Size of the Collection whose elements are got by ElementsGetter
		 */
		private static int size;

		/**
		 * This variable stores Collection's ListNode first. Since ListNode first of the
		 * Collection is private, this variable is got through the method
		 * createElementsGetter(); Since this class has to use intern data structure of
		 * the Collection, we have to remember reference to the list.
		 */
		@SuppressWarnings("rawtypes")
		private static ListNode node;

		/**
		 * This node is used to iterate over Collection's list. The reason of adding
		 * this node is the possible situation where two or more ElemetsGetter are
		 * referred to the same list. Each of ElementsGetters has to behave independent,
		 * so iterating through the list using this node will still secure that the
		 * other ElementsGetter will have correct reference to the List(it will be
		 * stored in ListNode node).
		 */
		private ListNode<T> active;

		/**
		 * This variable stores modificationCount of the Collection at the moment of
		 * creation this ElementsGetter.
		 */
		private long savedModificationCount;

		/**
		 * Constructor of ElementsGetter.
		 */
		public ElementsGetterList() {
			i = 0;
			savedModificationCount = modificationCount;
		}

		/**
		 * This method initializes ListNode active as ListNode node. At the beginning the  node
		 * through which we will be iterating over List equals ListNode node. 
		 */
		@SuppressWarnings("unchecked")
		public void active() {
			active = node;
		}

		/**
		 * {@inheritDoc}
		 */
		public boolean hasNextElement() {

			if (modificationCount != savedModificationCount) {
				throw new ConcurrentModificationException("Collection has changed.");
			}
			if (i < size) {
				return true;
			}
			return false;
		}

		/**
		 * {@inheritDoc}
		 */
		@SuppressWarnings("unchecked")
		public Object getNextElement() {

			if (modificationCount != savedModificationCount) {
				throw new ConcurrentModificationException("Collection has changed.");
			}
			if (hasNextElement()) {
				// System.out.println(i);
				// System.out.println(ElementsGetterList.node.value);

				Object value = active.value;
				active = active.next;
				i++;

				return (T) value;
			}
			return new NoSuchElementException("There are no elements anymore.");
		}

	}

	/**
	 * This method creates ElementsGetter whose task is to reach elements of
	 * Collection.
	 * 
	 * @return ElementsGetter through which user will access elements of Collection
	 */
	public ElementsGetter<T> createElementsGetter() {
		ElementsGetter<T> getter = new ElementsGetterList<T>();
		ElementsGetterList.size = this.size();
		ElementsGetterList.node = this.first;
		// System.out.println(ElementsGetterList.node.value);
		getter.active();

		return getter;
	}

}