package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class QueryParserTest {

	@Test
	public void directQueryTest() {
		QueryParser query = new QueryParser(" jmbag =\"0123456789\"");
		assertTrue(query.isDirectQuery());
	
	//	String s = query.getQueriedJMBAG();
		//System.out.println(s);
		assertEquals("0123456789", query.getQueriedJMBAG());
		assertEquals(1, query.getQuery().size());
	}

	@Test
	public void query2Test() {
		QueryParser query = new QueryParser("jmbag=\"1191235856\" and lastName>\"Ivona\"");
		assertFalse(query.isDirectQuery());
		assertEquals(2, query.getQuery().size());
	}

	@Test
	public void notDirectQueryTest() {
		QueryParser query = new QueryParser("lastName>\"Ivona\" and lastName>\"Ivona\"");
		assertFalse(query.isDirectQuery());
	}

	@Test
	public void getJMBAGTest() {
		QueryParser query = new QueryParser("jmbag=\"000444\"");
		assertEquals("000444", query.getQueriedJMBAG());
	}
	
}
