package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ConditionalExpressionTest {

	@Test
	public void lastNameTest() {
		ConditionalExpression expr = new ConditionalExpression(FieldValueGetters.LAST_NAME, "Raguž*",
				ComparisonOperators.LIKE);

		StudentRecord record = new StudentRecord("1191235856", "Raguž", "Ivona", "5");
		boolean recordSatisfies = expr.getComparisonOperator().satisfied(expr.getFieldGetter().get(record),
				expr.getStringLiteral());

		assertTrue(recordSatisfies);
	}

	@Test
	public void firstNameTest() {
		ConditionalExpression expr = new ConditionalExpression(FieldValueGetters.FIRST_NAME, "Ivona",
				ComparisonOperators.EQUALS);

		StudentRecord record = new StudentRecord("1191235856", "Raguž", "Ivona", "5");
		boolean recordSatisfies = expr.getComparisonOperator().satisfied(expr.getFieldGetter().get(record),
				expr.getStringLiteral());

		assertTrue(recordSatisfies);
	}
	
	@Test
	public void jmbagTest() {
		ConditionalExpression expr = new ConditionalExpression(FieldValueGetters.JMBAG, "1191235857",
				ComparisonOperators.LESS);

		StudentRecord record = new StudentRecord("1191235856", "Raguž", "Ivona", "5");
		boolean recordSatisfies = expr.getComparisonOperator().satisfied(expr.getFieldGetter().get(record),
				expr.getStringLiteral());

		assertTrue(recordSatisfies);
	}
	
	
}
