package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class QueryLexerTest {

	@Test
	public void basicTest() {
		QueryLexer lexer = new QueryLexer("jmbag =\"0123456789\"");

		QueryToken correctData[] = { new QueryToken("jmbag", QueryTokenType.FIELD),
				new QueryToken("=", QueryTokenType.OPERATOR), new QueryToken("0123456789", QueryTokenType.STRING),
				new QueryToken(null, QueryTokenType.EOF) };

		/*
		 * QueryToken token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); token = lexer.nextToken();
		 * System.out.println(token.getType()); System.out.println(token.getValue());
		 * token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); token = lexer.nextToken();
		 * System.out.println(token.getType()); System.out.println(token.getValue());
		 * 
		 */

		checkIfOK(lexer, correctData);
	}

	@Test
	public void spacesTest() {
		QueryLexer lexer = new QueryLexer(" lastName = \"Raguž\"");

		QueryToken correctData[] = { new QueryToken("lastName", QueryTokenType.FIELD),
				new QueryToken("=", QueryTokenType.OPERATOR), new QueryToken("Raguž", QueryTokenType.STRING),
				new QueryToken(null, QueryTokenType.EOF) };
		// QueryToken token = lexer.nextToken();
		// System.out.println(token.getType());
		// System.out.println(token.getValue());

		checkIfOK(lexer, correctData);
	}

	@Test
	public void oneAndTest() {
		QueryLexer lexer = new QueryLexer("firstName>\"Ivona\"");

		QueryToken correctData[] = { new QueryToken("firstName", QueryTokenType.FIELD),
				new QueryToken(">", QueryTokenType.OPERATOR), new QueryToken("Ivona", QueryTokenType.STRING),
				new QueryToken(null, QueryTokenType.EOF) };

		/*
		 * QueryToken token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); assertEquals(QueryTokenType.FIELD,
		 * token.getType()); assertEquals("firstName", token.getValue());
		 * 
		 * token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); assertEquals(QueryTokenType.OPERATOR,
		 * token.getType()); assertEquals(">", token.getValue());
		 * 
		 * token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); assertEquals(QueryTokenType.STRING,
		 * token.getType()); assertEquals("A", token.getValue());
		 * 
		 * token = lexer.nextToken(); System.out.println(token.getType());
		 * System.out.println(token.getValue()); assertEquals(QueryTokenType.EOF,
		 * token.getType()); assertEquals(null, token.getValue());
		 */
		checkIfOK(lexer, correctData);

	}

	@Test
	public void multiAndTest() {
		QueryLexer lexer2 = new QueryLexer(
				"firstName>\"A\" and firstName<\"C\" and lastName LIKE \"B*ć\" and jmbag>\"0000000002\"");

		QueryToken correctData[] = { new QueryToken("firstName", QueryTokenType.FIELD),
				new QueryToken(">", QueryTokenType.OPERATOR), new QueryToken("A", QueryTokenType.STRING),
				new QueryToken("and", QueryTokenType.AND), new QueryToken("firstName", QueryTokenType.FIELD),
				new QueryToken("<", QueryTokenType.OPERATOR), new QueryToken("C", QueryTokenType.STRING),
				new QueryToken("and", QueryTokenType.AND), new QueryToken("lastName", QueryTokenType.FIELD),
				new QueryToken("LIKE", QueryTokenType.OPERATOR), new QueryToken("B*ć", QueryTokenType.STRING),
				new QueryToken("and", QueryTokenType.AND), new QueryToken("jmbag", QueryTokenType.FIELD),
				new QueryToken(">", QueryTokenType.OPERATOR), new QueryToken("0000000002", QueryTokenType.STRING),

				new QueryToken(null, QueryTokenType.EOF) };
		checkIfOK(lexer2, correctData);
	}

	@Test
	public void mixedTest() {
		QueryLexer lexer2 = new QueryLexer("jmbag=\"0123456789\" and lastName>\"J\"");

		QueryToken correctData[] = { new QueryToken("jmbag", QueryTokenType.FIELD),
				new QueryToken("=", QueryTokenType.OPERATOR), new QueryToken("0123456789", QueryTokenType.STRING),
				new QueryToken("and", QueryTokenType.AND), new QueryToken("lastName", QueryTokenType.FIELD),
				new QueryToken(">", QueryTokenType.OPERATOR), new QueryToken("J", QueryTokenType.STRING),
				new QueryToken(null, QueryTokenType.EOF) };
		checkIfOK(lexer2, correctData);
	}

	private void checkIfOK(QueryLexer lexer, QueryToken[] correctData) {
		for (QueryToken expected : correctData) {
			QueryToken actual = lexer.nextToken();
			System.out.println("Tip: " + actual.getType());
			System.out.println("Očekivano: " + expected.getType());
			System.out.println("Vrijednost: " + actual.getValue());
			System.out.println("Očekivano: " + expected.getValue());

			assertEquals(expected.getType(), actual.getType());
			System.out.println("tipovi ok.");
			assertEquals(expected.getValue(), actual.getValue());
			System.out.println("Vrijednosti ok.");
		}

	}
}
