package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class ComparisonOperatorTest {

	@Test
	public void lessOperatorTest() {
		IComparisonOperator oper1 = ComparisonOperators.LESS;

		assertTrue(oper1.satisfied("Ana", "Jasna"));

		assertTrue(oper1.satisfied("Ivona", "Žarko"));

		assertTrue(oper1.satisfied("1", "2"));
	}

	@Test
	public void lessOrEqualOperatorTest() {
		IComparisonOperator oper = ComparisonOperators.LESS_OR_EQUAL;

		assertTrue(oper.satisfied("Ana", "Jasna"));

		assertTrue(oper.satisfied("Ivona", "Ivona"));

		assertTrue(oper.satisfied("1", "2"));

		assertTrue(oper.satisfied("2", "2"));
	}

	@Test
	public void greaterTest() {
		IComparisonOperator oper = ComparisonOperators.GREATER;

		assertTrue(oper.satisfied("HAna", "Ana"));

		assertTrue(oper.satisfied("ivona", "ana"));

		assertTrue(oper.satisfied("2", "1"));

		assertTrue(oper.satisfied("ana", "Ana"));
	}

	@Test
	public void greaterOrEqualTest() {
		IComparisonOperator oper = ComparisonOperators.GREATER_OR_EQUAL;

		assertTrue(oper.satisfied("HAna", "Ana"));

		assertTrue(oper.satisfied("ivona", "ana"));

		assertTrue(oper.satisfied("2", "1"));

		assertTrue(oper.satisfied("ana", "Ana"));

		assertTrue(oper.satisfied("ana", "ana"));

		assertTrue(oper.satisfied("aaaaaa", "aaaaaa"));
	}

	@Test
	public void equalTest() {
		IComparisonOperator oper = ComparisonOperators.EQUALS;

		assertTrue(oper.satisfied("Ana", "Ana"));

		assertTrue(oper.satisfied("ivona", "ivona"));

		assertTrue(oper.satisfied("2", "2"));

		assertTrue(oper.satisfied("ana", "ana"));

		assertTrue(oper.satisfied("aaaaaa", "aaaaaa"));

		assertFalse(oper.satisfied("Ivona", "ivona"));
	}

	@Test
	public void notEqualTest() {
		IComparisonOperator oper = ComparisonOperators.NOT_EQUALS;

		assertTrue(oper.satisfied("Ana", "aa"));

		assertTrue(oper.satisfied("ivona", "nešto"));

		assertTrue(oper.satisfied("2", "1"));

		assertTrue(oper.satisfied("ana", "Hanaa"));

		assertTrue(oper.satisfied("aaaaaa", "aa"));

		assertFalse(oper.satisfied("Ivona", "Ivona"));
	}

	@Test
	public void likeOperatorTest1() {

		IComparisonOperator oper = ComparisonOperators.LIKE;

		assertTrue(oper.satisfied("Ivona", "Ivon*a"));

		assertTrue(oper.satisfied("Ivona", "Ivona*"));

		assertTrue(oper.satisfied("Ivona", "*Ivona"));

		assertTrue(oper.satisfied("Ivona", "I*vona"));

		assertTrue(oper.satisfied("Ivona", "I*"));

		assertTrue(oper.satisfied("Ivona", "*a"));

	}

	@Test
	public void likeOperatorTest2() {

		IComparisonOperator oper = ComparisonOperators.LIKE;

		assertTrue(oper.satisfied("Raguž", "Raguž"));

		assertTrue(oper.satisfied("Raguž", "R*"));

		assertTrue(oper.satisfied("Raguž", "*ž"));

		assertTrue(oper.satisfied("Raguž", "*Raguž"));

		assertTrue(oper.satisfied("Raguž", "Raguž*"));

		assertTrue(oper.satisfied("Raguž", "R*už"));

		assertTrue(oper.satisfied("Raguž", "*"));
	}

	public void likeOperatorExceptionTest() {

		assertThrows(RuntimeException.class, () -> {

			IComparisonOperator oper = ComparisonOperators.LIKE;
			assertTrue(oper.satisfied("Raguž", "Rag*u*"));

		});
	}
}
