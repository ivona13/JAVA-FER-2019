package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

/*
 * Test that forJMBAG(...) works. In test class, write two private classes
implementing IFilter : one which always returns true and one which always return false . Test
that database method filter(...) returns all records when given an instance of first class and no
records when given an instance of second class. Instead of classes, you can use lambda expressions.
 */

public class StudentDatabbaseTest {

	@Test
	public void forJmbagTest() throws IOException {

		StudentDatabase database;
		List<String> lines = Files.readAllLines(Paths.get("database.txt"), StandardCharsets.UTF_8);
		database = new StudentDatabase(lines);

		assertEquals(database.forJMBAG("0000000001").getFirstName(), "Marin");
		assertEquals(database.forJMBAG("0000000001").getLastName(), "Akšamović");
		assertEquals(database.forJMBAG("0000000001").getFinalGrade(), "2");

		assertEquals(database.forJMBAG("0000000006").getFirstName(), "Ivan");
		assertEquals(database.forJMBAG("0000000006").getLastName(), "Cvrlje");
		assertEquals(database.forJMBAG("0000000006").getFinalGrade(), "3");

		assertEquals(database.forJMBAG("0000000013").getFirstName(), "Mateja");
		assertEquals(database.forJMBAG("0000000013").getLastName(), "Gagić");
		assertEquals(database.forJMBAG("0000000013").getFinalGrade(), "2");

	}

	// lambdaa expressions for filters
	IFilter filter1 = (StudentRecord record) -> {
	    return true;
	};
	
	IFilter filter2 = (StudentRecord record) -> {
		return false;
	};
	
	/**
	 * Test for correct behave of true - filter
	 * @throws IOException
	 */
	@Test
	public void filterTrueTest() throws IOException {
		StudentDatabase database;
		List<String> lines = Files.readAllLines(Paths.get("database.txt"), StandardCharsets.UTF_8);
		database = new StudentDatabase(lines);
		
		
		assertEquals(database.getRecordsList(), database.filter(filter1));

	}
	
	/**
	 * Test for correct behave of false - filter
	 * @throws IOException
	 */
	@Test
	public void filterFalseTest() throws IOException {
		StudentDatabase database;
		List<String> lines = Files.readAllLines(Paths.get("database.txt"), StandardCharsets.UTF_8);
		database = new StudentDatabase(lines);
		
		List<StudentRecord> emptyList = new ArrayList<StudentRecord>();
		assertEquals(emptyList, database.filter(filter2));

	}
	
	
	
	
}
