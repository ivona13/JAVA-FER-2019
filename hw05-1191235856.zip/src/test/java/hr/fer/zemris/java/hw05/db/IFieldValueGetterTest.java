package hr.fer.zemris.java.hw05.db;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;


import org.junit.jupiter.api.Test;

public class IFieldValueGetterTest {

	
	@Test
	public void firstNameGettert() throws IOException {
		
		
		StudentRecord student1 = new StudentRecord("1191235856", "Raguž", "Ivona", "4");
		IFieldValueGetter getter1 = FieldValueGetters.FIRST_NAME;
		assertEquals("Ivona", getter1.get(student1));
		
		

		StudentRecord student2 = new StudentRecord("1191235756", "Raić", "Ivan", "4");
		IFieldValueGetter getter = FieldValueGetters.FIRST_NAME;
		assertEquals("Ivan", getter.get(student2));
	}
}
