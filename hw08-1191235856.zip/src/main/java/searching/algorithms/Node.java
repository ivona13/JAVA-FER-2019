package searching.algorithms;

/**
 * This class is used to store reference to the state we are currently in. It
 * stores parent node and cost of getting to this state.
 * 
 * @author ivona
 *
 * @param <S> type of Node
 */
public class Node<S> {

	/**
	 * Parent NODE
	 */
	Node<S> parent;

	/**
	 * State
	 */
	S state;

	/**
	 * Cost of getting to this state
	 */
	double cost;

	/**
	 * Basic constructor
	 * 
	 * @param parent parent node
	 * @param state  state
	 * @param cost   cost
	 */
	public Node(Node<S> parent, S state, double cost) {
		this.parent = parent;
		this.state = state;
		this.cost = cost;
	}

	/**
	 * Parent node getter
	 * 
	 * @return parent node
	 */
	public Node<S> getParent() {
		return parent;
	}

	/**
	 * State getter
	 * 
	 * @return state
	 */
	public S getState() {
		return state;
	}

	/**
	 * Cost getter
	 * 
	 * @return cost
	 */
	public double getCost() {
		return cost;
	}

}
