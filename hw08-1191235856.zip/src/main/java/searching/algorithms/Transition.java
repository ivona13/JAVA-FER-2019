package searching.algorithms;

/**
 * This class is used to represent ordered pair (s, c). S represents state and c
 * represents cost.
 * 
 * @author ivona
 *
 * @param <S> type of Transition
 */
public class Transition<S> {

	/**
	 * State
	 */
	S state;

	/**
	 * Cost
	 */
	double cost;

	/**
	 * Basic constructor
	 * 
	 * @param state state
	 * @param cost  cost
	 */
	public Transition(S state, double cost) {
		this.state = state;
		this.cost = cost;
	}

	/**
	 * State getter
	 * 
	 * @return state
	 */
	public S getState() {
		return state;
	}

	/**
	 * Cost getter
	 * 
	 * @return cost
	 */
	public double getCost() {
		return cost;
	}
}
