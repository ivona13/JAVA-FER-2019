package searching.algorithms;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import searching.algorithms.Node;
import searching.algorithms.Transition;

/**
 * This class is used to represent static method for exploring states while
 * playing puzzle. If solution exists, it returns it.
 * 
 * @author ivona
 *
 */
public class SearchUtil {

	/**
	 * This method is used for finding solution of the puzzle if it exists. States
	 * are stored in list. Popping is done from the beginning, adding is done to the
	 * end of the list.
	 * 
	 * @param s0   start state
	 * @param succ Function which returns list of neighbor states of s0
	 * @param goal Function which is used for checking if solution is found
	 * @return
	 */
	public static <S> Node<S> bfs(Supplier<S> s0, Function<S, List<Transition<S>>> succ, Predicate<S> goal) {

		LinkedList<Node<S>> zaIstraziti = new LinkedList<Node<S>>();
		zaIstraziti.add(new Node<S>(null, s0.get(), 0));

		while (!zaIstraziti.isEmpty()) {
			Node<S> ni = zaIstraziti.pollFirst();

			if (goal.test(ni.getState())) {
				return ni;
			}

			List<Transition<S>> dodaj = new LinkedList<Transition<S>>();

			dodaj = succ.apply(ni.getState());

			for (Transition<S> element : dodaj) {
				double cost = ni.getCost();
				Node<S> node = new Node<S>(ni, element.getState(), cost + 1);
				zaIstraziti.add(node);

			}

		}

		return null;
	}

	/**
	 * This method is used for finding solution of the puzzle if it exists. States
	 * are stored in list. Popping is done from the beginning, adding is done to the
	 * end of the list. It uses set to store already visited states.
	 * 
	 * @param s0   start state
	 * @param succ Function which returns list of neighbor states of s0
	 * @param goal Function which is used for checking if solution is found
	 * @return
	 */
	public static <S> Node<S> bfsv(Supplier<S> s0, Function<S, List<Transition<S>>> succ, Predicate<S> goal) {

		LinkedList<Node<S>> zaIstraziti = new LinkedList<Node<S>>();
		HashSet<S> posjećeni = new HashSet<S>();
		zaIstraziti.add(new Node<S>(null, s0.get(), 0));
		posjećeni.add(s0.get());

		while (!zaIstraziti.isEmpty()) {
			Node<S> ni = zaIstraziti.pollFirst();

			if (goal.test(ni.getState())) {
				return ni;
			}

			List<Transition<S>> dodaj = new LinkedList<Transition<S>>();

			dodaj = succ.apply(ni.getState());

			for (Transition<S> element : dodaj)
				if (!posjećeni.contains(element.getState())) {
					double cost = ni.getCost();
					Node<S> node = new Node<S>(ni, element.getState(), cost + 1);
					zaIstraziti.add(node);

				}

		}

		return null;
	}
}
