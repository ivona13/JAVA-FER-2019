package searching.slagalica;

/**
 * This class is used to represent configuration of puzzle. It has private
 * variable to store configuration.
 * 
 * @author ivona
 *
 */
public class KonfiguracijaSlagalice {

	/**
	 * Variable to store configuration
	 */
	private int polje[];

	/**
	 * Basic constructor
	 * 
	 * @param polje polje
	 */
	public KonfiguracijaSlagalice(int[] polje) {
		this.polje = polje;
	}

	/**
	 * Getter for variable polje
	 * 
	 * @return copy of variable polje
	 */
	public int[] getPolje() {
		int copy[] = new int[9];
		int index = 0;
		for (int element : polje) {
			copy[index++] = element;

		}
		return copy;
	}

	/**
	 * This method is used to return index of element 0 in variable polje
	 * 
	 * @return index of 0
	 */
	public int indexOfSpace() {

		for (int index = 0; index < polje.length; index++) {
			if (polje[index] == 0) {
				return index;
			}
		}

		throw new RuntimeException("No such argument.");
	}

	@Override
	public String toString() {
		StringBuilder string = new StringBuilder();
		for (int i = 0; i < 9; i++) {

			if (polje[i] == 0) {
				string.append("* ");
			} else {
				string.append(polje[i] + " ");
			}

			if (i > 0 && i % 3 == 2) {
				string.append('\n');
			}

		}
		return string.toString();
	}
}
