package searching.slagalica;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import searching.algorithms.Transition;
import searching.slagalica.KonfiguracijaSlagalice;

public class Slagalica implements Supplier<KonfiguracijaSlagalice>,
		Function<KonfiguracijaSlagalice, List<Transition<KonfiguracijaSlagalice>>>, Predicate<KonfiguracijaSlagalice> {

	private KonfiguracijaSlagalice konfiguracija;

	public Slagalica(KonfiguracijaSlagalice konfiguracijaSlagalice) {
		this.konfiguracija = konfiguracijaSlagalice;
	}

	public KonfiguracijaSlagalice getKonfiguracija() {
		return this.konfiguracija;
	}

	@Override
	public boolean test(KonfiguracijaSlagalice t) {
		for (int i = 0; i < t.getPolje().length - 1; i++) {
			if (t.getPolje()[i] != i + 1) {
				return false;
			}
		}
		return true;
	}

	@Override
	public List<Transition<KonfiguracijaSlagalice>> apply(KonfiguracijaSlagalice t) {
		List<Transition<KonfiguracijaSlagalice>> list = new LinkedList<Transition<KonfiguracijaSlagalice>>();

		int index = t.indexOfSpace();
		int polje1[] = t.getPolje();

		// desno
		if (index % 3 != 2 && (index + 1) % 3 != 0) {
			int polje[] = t.getPolje();

			if (polje[index + 1] == index + 1 && polje[index] == 0) {
				polje[index + 1] = 0;
				polje[index] = index + 1;
				KonfiguracijaSlagalice konf = new KonfiguracijaSlagalice(polje);

				// this.konfiguracija = new KonfiguracijaSlagalice(polje);
				// System.out.println("Usla sam u apply : " + konf.toString());

				list.add(new Transition<KonfiguracijaSlagalice>(konf, 1));

			}
		}
		// dolje
		if (index + 3 <= 8) {
			if (polje1[index + 3] == index + 1) {
				int polje[] = t.getPolje();

				int element = polje[index + 3];
				polje[index + 3] = 0;
				polje[index] = element;

				KonfiguracijaSlagalice konf = new KonfiguracijaSlagalice(polje);
				// this.konfiguracija = new KonfiguracijaSlagalice(polje);
				// System.out.println("Usla sam u apply : " + konf.toString());

				list.add(new Transition<KonfiguracijaSlagalice>(konf, 1));

			}
		}

		// gore
		if (index - 3 >= 0) {
			if (polje1[index - 3] == index + 1) {
				int polje[] = t.getPolje();

				int element = polje[index - 3];
				polje[index - 3] = 0;
				polje[index] = element;

				KonfiguracijaSlagalice konf = new KonfiguracijaSlagalice(polje);
				// this.konfiguracija = new KonfiguracijaSlagalice(polje);
				// System.out.println("Usla sam u apply : " + konf.toString());

				list.add(new Transition<KonfiguracijaSlagalice>(konf, 1));

			}
		}

		// lijevo
		if (index - 1 >= 0) {
			if (polje1[index - 1] == index + 1) {
				int polje[] = t.getPolje();

				int element = polje[index - 1];
				polje[index - 1] = 0;
				polje[index] = element;
				KonfiguracijaSlagalice konf = new KonfiguracijaSlagalice(polje);
				list.add(new Transition<KonfiguracijaSlagalice>(konf, 1));

			}
		}

		return list;

	}

	@Override
	public KonfiguracijaSlagalice get() {
		return this.konfiguracija;
	}

}
