package coloring.algorithms;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * This class is used to store different algorithms of coloring picture: bfs,
 * dfs, bfvs algorithms.
 * 
 * @author ivona
 *
 */
public class SubspaceExploreUtil {

	/**
	 * This method is used to represent algorithm of coloring. It puts new states
	 * which have to be explored to the end of the list. Elements are taken from the
	 * beginning of the list.
	 * 
	 * @param s0         start state
	 * @param process    Function which sets pixel color
	 * @param succ       Function which returns list of neighbours of state s0
	 * @param acceptable Predicate which returns <code>true</code> if state has to
	 *                   be explored; <code>false</code> otherwise
	 */
	public static <S> void bfs(Supplier<S> s0, Consumer<S> process, Function<S, List<S>> succ,
			Predicate<S> acceptable) {

		LinkedList<S> zaIstraziti = new LinkedList<S>();
		zaIstraziti.add(s0.get());

		while (!zaIstraziti.isEmpty()) {

			S si = zaIstraziti.pop();

			if (!acceptable.test(si)) {
				continue;
			}

			process.accept(si);
			LinkedList<S> dodaj = (LinkedList<S>) succ.apply(si);

			zaIstraziti.addAll(dodaj);

		}

	}

	/**
	 * This method is used to represent algorithm of coloring. It puts new states
	 * which have to be explored to the begin of the list. Elements are taken from
	 * the beginning of the list.
	 * 
	 * @param s0         start state
	 * @param process    Function which sets pixel color
	 * @param succ       Function which returns list of neighbours of state s0
	 * @param acceptable Predicate which returns <code>true</code> if state has to
	 *                   be explored; <code>false</code> otherwise
	 */
	public static <S> void dfs(Supplier<S> s0, Consumer<S> process, Function<S, List<S>> succ,
			Predicate<S> acceptable) {

		LinkedList<S> zaIstraziti = new LinkedList<S>();
		zaIstraziti.add(s0.get());

		while (!zaIstraziti.isEmpty()) {

			S si = zaIstraziti.pop();

			if (!acceptable.test(si)) {
				continue;
			}
			process.accept(si);
			LinkedList<S> dodaj = (LinkedList<S>) succ.apply(si);

			zaIstraziti.addAll(0, dodaj);

		}
	}

	/**
	 * This method is used to represent algorithm of coloring. It puts new states
	 * which have to be explored to the end of the list. Elements are taken from the
	 * beginning of the list. It has set of already visited states, and they are
	 * skipped in after exploring.
	 * 
	 * @param s0         start state
	 * @param process    Function which sets pixel color
	 * @param succ       Function which returns list of neighbours of state s0
	 * @param acceptable Predicate which returns <code>true</code> if state has to
	 *                   be explored; <code>false</code> otherwise
	 * 
	 */
	public static <S> void bfsv(Supplier<S> s0, Consumer<S> process, Function<S, List<S>> succ,
			Predicate<S> acceptable) {

		LinkedList<S> zaIstraziti = new LinkedList<S>();
		HashSet<S> posjećeno = new HashSet<S>();
		zaIstraziti.add(s0.get());

		while (!zaIstraziti.isEmpty()) {

			S si = zaIstraziti.pop();

			if (!acceptable.test(si)) {
				continue;
			}
			process.accept(si);
			LinkedList<S> djeca = (LinkedList<S>) succ.apply(si);

			for (S element : djeca) {
				if (!posjećeno.contains(element)) {
					zaIstraziti.add(element);
				}
			}

			posjećeno.addAll(djeca);

		}
	}
}
