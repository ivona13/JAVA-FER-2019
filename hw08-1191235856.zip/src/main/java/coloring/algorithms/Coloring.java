package coloring.algorithms;

import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import marcupic.opjj.statespace.coloring.Picture;

/**
 * Thiis class is used to represent coloring of picture. It has referenced
 * pixel, picture, referenced color and fill color.
 * 
 * @author ivona
 *
 */
public class Coloring
		implements Predicate<Coloring>, Consumer<Coloring>, Supplier<Coloring>, Function<Coloring, List<Coloring>> {

	/**
	 * Referenced pixel
	 */
	private Pixel reference;

	/**
	 * Picture
	 */
	private Picture picture;

	/**
	 * Color of filling
	 */
	private int fillColor;

	/**
	 * Referenced color
	 */
	private int refColor;

	/**
	 * Basic constructor
	 * 
	 * @param reference referenced pixel
	 * @param picture   picture
	 * @param fillColor fillColor
	 */
	public Coloring(Pixel reference, Picture picture, int fillColor) {
		this.reference = reference;
		this.picture = picture;
		this.fillColor = fillColor;
		this.refColor = picture.getPixelColor(reference.x, reference.y);
	}

	@Override
	public boolean test(Coloring t) {
		return t.picture.getPixelColor(t.reference.x, t.reference.y) == refColor;

	}

	@Override
	public void accept(Coloring t) {
		t.picture.setPixelColor(t.reference.x, t.reference.y, this.fillColor);
	}

	@Override
	public Coloring get() {
		return this;
	}

	@Override
	public List<Coloring> apply(Coloring t) {

		LinkedList<Coloring> succ = new LinkedList<Coloring>();

		// all neighbours of current state (with the same ref color) are added to the
		// list

		// check right pixel
		if (t.reference.x + 1 < picture.getWidth()) {
			Pixel pixel = new Pixel(t.reference.x + 1, t.reference.y);
			Coloring object = new Coloring(pixel, t.picture, t.fillColor);
			if (t.test(object)) {
				succ.add(object);
			}

		}

		// check left pixel
		if (t.reference.x - 1 >= 0) {
			Pixel pixel = new Pixel(t.reference.x - 1, t.reference.y);
			Coloring object = new Coloring(pixel, t.picture, t.fillColor);
			if (t.test(object)) {
				succ.add(object);
			}

		}

		// check upper pixel
		if (t.reference.y - 1 >= 0) {
			Pixel pixel = new Pixel(t.reference.x, t.reference.y - 1);
			Coloring object = new Coloring(pixel, t.picture, t.fillColor);
			if (t.test(object)) {

				succ.add(object);
			}

		}

		// check lower pixel
		if (t.reference.y + 1 < picture.getHeight()) {
			Pixel pixel = new Pixel(t.reference.x, t.reference.y + 1);
			Coloring object = new Coloring(pixel, t.picture, t.fillColor);
			if (t.test(object)) {
				succ.add(object);
			}

		}

		// return list of neighbours
		return succ;

	}

	@Override
	public String toString() {
		return reference.toString();
	}

}