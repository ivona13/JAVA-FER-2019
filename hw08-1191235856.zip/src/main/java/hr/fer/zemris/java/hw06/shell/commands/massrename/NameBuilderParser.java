package hr.fer.zemris.java.hw06.shell.commands.massrename;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used for representing Name builder parser
 * 
 * @author ivona
 *
 */
public class NameBuilderParser {

	/**
	 * Lexer of parser
	 */
	private NameBuilderLexer lexer;

	/**
	 * All parsed namebuilders composed
	 */
	private NameBuilder compositionNameBuilder;

	/**
	 * Basic constructor.
	 *
	 * @param izraz expression to be parsed
	 */
	public NameBuilderParser(String izraz) {
		this.lexer = new NameBuilderLexer(izraz);
		parseBuilder();
	}

	/**
	 * This method is used for parsing izraz
	 */
	private void parseBuilder() {
		List<NameBuilder> builders = new ArrayList<>();

		NameBuilderToken token;

		while (true) {
			token = lexer.nextToken();
			if (token.getType() == NameBuilderTokenType.EOF) {
				break;
			} else if (token.getType() == NameBuilderTokenType.BEGINCOMMAND) {
				lexer.setInsideCommand(true);

				token = lexer.nextToken();
				if (token.getType() != NameBuilderTokenType.NUMBER) {
					throw new RuntimeException("Invalid command!");
				}
				int groupNumber = Integer.parseInt(token.getValue());
				token = lexer.nextToken();
				if (token.getType() == NameBuilderTokenType.ENDCOMMAND) {
					lexer.setInsideCommand(false);
					builders.add(group(groupNumber));
				} else if (token.getType() == NameBuilderTokenType.COMMA) {
					token = lexer.nextToken();
					if (token.getType() != NameBuilderTokenType.NUMBER) {
						throw new RuntimeException("Invalid command!");
					}

					builders.add(group(groupNumber, token.getValue().charAt(0), Integer.parseInt(token.getValue())));

					token = lexer.nextToken();

					if (token.getType() != NameBuilderTokenType.ENDCOMMAND) {
						throw new RuntimeException("Invalid command!");
					}
					lexer.setInsideCommand(false);
				}
			} else if (token.getType() == NameBuilderTokenType.STRING) {
				builders.add(text(token.getValue()));
			}

		}

		compositionNameBuilder = composition(builders);
	}

	/**
	 * Name builder getter
	 *
	 * @return Name builder
	 */
	public NameBuilder getNameBuilder() {
		return compositionNameBuilder;
	}

	/**
	 * This method is used to build lambda expression for one kind of NameBuilder
	 * 
	 * @param t String to be written in stringBuilder
	 * @return NameBuilder
	 */
	static NameBuilder text(String t) {
		return (result, sb) -> sb.append(t);
	}

	/**
	 * This method is used to build lambda expression for one kind of NameBuilder
	 * 
	 * @param index index of group which will be written in StringBuilder
	 * @return NameBuilder
	 */
	static NameBuilder group(int index) {
		return (result, sb) -> {
			sb.append(result.group(index));
		};
	}

	/**
	 * This method is used to build lambda expression for one kind of NameBuilder
	 * 
	 * @param index    index of group to be written
	 * @param padding  char to be written if length of group is less than minWidth
	 * @param minWidth minimal width of string
	 * @return
	 */
	static NameBuilder group(int index, char padding, int minWidth) {
		return (result, sb) -> {

			int length = result.group(index).length();
			while (length < minWidth) {
				sb.append(padding);
				length++;
			}
			sb.append(result.group(index));

		};
	}

	/**
	 * This method is used to build lambda expression for one kind of NameBuilder
	 * 
	 * 
	 * @param builders list of NameBuilders
	 * @return generated NameBuilder
	 */
	static NameBuilder composition(List<NameBuilder> builders) {
		return (result, sb) -> {
			for (NameBuilder builder : builders) {
				builder.execute(result, sb);
			}
		};
	}
}
