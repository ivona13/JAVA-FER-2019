package hr.fer.zemris.java.hw06.shell.commands;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent pwd command. It gets current woking
 * directory.
 * 
 * @author ivona
 *
 */
public class PwdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		if (arguments.length() != 0) {
			env.writeln("No arguments needed.");
			env.writeln(env.getPromptSymbol() + "");
			return ShellStatus.CONTINUE;
		}

		env.writeln(env.getCurrentDirectory().toString());
		env.write(env.getPromptSymbol() + "");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "pwd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<String>();

		commandDescription.add("Pwd command.");
		commandDescription.add("It gets current woking directory.");

		return commandDescription;
	}

}
