package hr.fer.zemris.java.hw06.shell.commands.massrename;

/**
 * This class if used to represent lexer for Name builder.
 * 
 * @author ivona
 *
 */
public class NameBuilderLexer {

	/**
	 * Data of lexer
	 */
	private char[] data;

	/**
	 * Last generated token
	 */
	private NameBuilderToken currentToken;

	/**
	 * Current index of lexer
	 */
	private int currentIndex;

	/**
	 * Boolean flag for switching states between inside and outside of command
	 */
	private boolean insideCommand;

	/**
	 * Basic constructor
	 *
	 * @param izraz Iexpression to be lexed
	 */
	public NameBuilderLexer(String izraz) {
		this.data = izraz.toCharArray();
	}

	/**
	 * This method is used for generating next token.
	 *
	 * @return Namebuilder
	 */
	public NameBuilderToken nextToken() {
		if (currentToken != null && currentToken.getType() == NameBuilderTokenType.EOF) {
			throw new RuntimeException("End already reached.");
		}

		StringBuilder sb = new StringBuilder();
		NameBuilderTokenType currentType = NameBuilderTokenType.EOF;

		while (true) {
			if (currentIndex == data.length) {
				if (currentType != NameBuilderTokenType.EOF)
					break;

				currentToken = new NameBuilderToken(null, NameBuilderTokenType.EOF);
				return currentToken;
			}

			if (insideCommand) {
				skipSpaces();
				if (data[currentIndex] == ',') {
					if (currentType != NameBuilderTokenType.EOF) {
						break;
					}
					currentIndex++;
					currentToken = new NameBuilderToken(",", NameBuilderTokenType.COMMA);
					return currentToken;
				} else if (data[currentIndex] == '}') {
					if (currentType != NameBuilderTokenType.EOF) {
						break;
					}
					currentIndex++;
					currentToken = new NameBuilderToken("}", NameBuilderTokenType.ENDCOMMAND);
					return currentToken;
				} else if (Character.isDigit(data[currentIndex])) {
					currentType = NameBuilderTokenType.NUMBER;
					sb.append(data[currentIndex++]);
				} else {
					throw new RuntimeException("Invalid command!");
				}
			} else {
				if (data[currentIndex] == '$') {
					if (currentType != NameBuilderTokenType.EOF) {
						break;
					}
					currentIndex++;
					checkValidIndex();
					if (data[currentIndex] != '{') {
						throw new RuntimeException("Invalid start of command!");
					}
					currentIndex++;
					currentToken = new NameBuilderToken("${", NameBuilderTokenType.BEGINCOMMAND);
					return currentToken;
				}
				currentType = NameBuilderTokenType.STRING;
				sb.append(data[currentIndex++]);
			}

		}

		currentToken = new NameBuilderToken(sb.toString(), currentType);

		return currentToken;
	}

	/**
	 * Inside command flag setter
	 *
	 * @param insideCommand indsideCommand
	 */
	public void setInsideCommand(boolean insideCommand) {
		this.insideCommand = insideCommand;
	}

	/**
	 * This method is used to check validation of index
	 */
	private void checkValidIndex() {
		if (currentIndex > data.length) {
			throw new IndexOutOfBoundsException("Index out of bounds in izraz!");
		}

	}

	/**
	 * This method is used to check if data at current index is space character
	 *
	 * @return <code>true</code> true if it is,; otherwise <code>false</code>
	 */
	private boolean checkIfSpace() {
		return data[currentIndex] == ' ' || data[currentIndex] == '\r' || data[currentIndex] == '\t'
				|| data[currentIndex] == '\n';
	}

	/**
	 * This method is used for skipping spaces
	 */
	private void skipSpaces() {
		while (true) {
			if (currentIndex < data.length && checkIfSpace()) {
				currentIndex++;
			} else {
				break;
			}
		}
	}

}