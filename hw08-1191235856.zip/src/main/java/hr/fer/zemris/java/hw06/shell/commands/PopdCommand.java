package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent popd command. It popps directory from stack
 * and sets that directory as current working directory.
 * 
 * @author ivona
 *
 */
public class PopdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {

		if (arguments.length() != 0) {
			env.writeln("Invalid number of arguments.");
			env.write(env.getPromptSymbol() + "");
			return ShellStatus.CONTINUE;
		}

		@SuppressWarnings("unchecked")
		Stack<Path> stack = (Stack<Path>) env.getSharedData("cdstack");

		if (stack == null || stack.isEmpty()) {
			env.writeln("No directories to be popped.");
		} else {

			Path newDirectory = stack.pop();
			if (!Files.exists(newDirectory)) {
				env.writeln("Directory does not exist");
			} else {

				env.setCurrentDirectory(newDirectory);
				env.writeln("Directory changed : " + env.getCurrentDirectory());
			}
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "popd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Popd command.");
		commandDescription.add("It popps directory from stack and sets that directory as current working directory.");

		return commandDescription;
	}

}
