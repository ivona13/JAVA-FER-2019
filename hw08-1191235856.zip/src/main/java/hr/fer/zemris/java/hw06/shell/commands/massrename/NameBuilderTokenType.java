package hr.fer.zemris.java.hw06.shell.commands.massrename;

/**
 * This class represents enumeration of token type for NameBuilderToken
 * 
 * @author ivona
 *
 */
public enum NameBuilderTokenType {

	/**
	 * String type
	 */
	STRING,

	/**
	 * Begin command type
	 */
	BEGINCOMMAND,

	/**
	 * End command type
	 */
	ENDCOMMAND,

	/**
	 * Number type
	 */
	NUMBER,

	/**
	 * Comma type (appears in gruops { ... , .. })
	 */
	COMMA,

	/**
	 * End of file
	 */
	EOF
}
