package hr.fer.zemris.java.hw06.shell;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;

import hr.fer.zemris.java.hw06.shell.commands.CatCommand;
import hr.fer.zemris.java.hw06.shell.commands.CdCommand;
import hr.fer.zemris.java.hw06.shell.commands.CharsetCommand;
import hr.fer.zemris.java.hw06.shell.commands.CopyCommand;
import hr.fer.zemris.java.hw06.shell.commands.DropdCommand;
import hr.fer.zemris.java.hw06.shell.commands.ExitCommand;
import hr.fer.zemris.java.hw06.shell.commands.HelpCommand;
import hr.fer.zemris.java.hw06.shell.commands.HexdumpCommand;
import hr.fer.zemris.java.hw06.shell.commands.ListdCommand;
import hr.fer.zemris.java.hw06.shell.commands.LsCommand;
import hr.fer.zemris.java.hw06.shell.commands.MkdirCommand;
import hr.fer.zemris.java.hw06.shell.commands.PopdCommand;
import hr.fer.zemris.java.hw06.shell.commands.PushdCommand;
import hr.fer.zemris.java.hw06.shell.commands.PwdCommand;
import hr.fer.zemris.java.hw06.shell.commands.SymbolCommand;
import hr.fer.zemris.java.hw06.shell.commands.TreeCommand;
import hr.fer.zemris.java.hw06.shell.commands.massrename.MassrenameCommand;

/**
 * This class is used for representing environmet which is used in
 * {@link MyShell}.
 * 
 * @author ivona
 *
 */
public class ShellEnvironment implements Environment {

	/**
	 * This scener is used for reading from console
	 */
	Scanner sc = new Scanner(System.in);

	/**
	 * This character represents prompt symbol
	 */
	private Character promptSymbol = '>';

	/**
	 * This character represents symbol for multiline
	 */
	private Character multiLineSymbol = '|';

	/**
	 * This character represents symbol for moreLines
	 */
	private Character moreLinesSymbol = '\\';

	/**
	 * This map is used for storing command of shell
	 */
	private SortedMap<String, ShellCommand> commands;

	/**
	 * Basic constructor for Shell Environmet
	 */
	public ShellEnvironment() {
		System.out.print("Welcome to MyShell v 1.0\n> ");
		this.commands = new TreeMap<>();
		addCommands();
	}

	/**
	 * Current directory of our shell.
	 */
	private Path currentDirectory = Paths.get("").toAbsolutePath().normalize();

	/**
	 * Map to store shared data.
	 */
	private Map<String, Object> sharedData = new HashMap<>();

	/**
	 * This class is used for adding command to be supported by shell
	 */
	private void addCommands() {
		ShellCommand charset = new CharsetCommand();
		commands.put(charset.getCommandName(), charset);
		ShellCommand symbol = new SymbolCommand();
		commands.put(symbol.getCommandName(), symbol);
		ShellCommand exit = new ExitCommand();
		commands.put(exit.getCommandName(), exit);
		ShellCommand cat = new CatCommand();
		commands.put(cat.getCommandName(), cat);
		ShellCommand copy = new CopyCommand();
		commands.put(copy.getCommandName(), copy);
		ShellCommand ls = new LsCommand();
		commands.put(ls.getCommandName(), ls);
		ShellCommand mkdir = new MkdirCommand();
		commands.put(mkdir.getCommandName(), mkdir);
		ShellCommand hexdump = new HexdumpCommand();
		commands.put(hexdump.getCommandName(), hexdump);
		ShellCommand tree = new TreeCommand();
		commands.put(tree.getCommandName(), tree);
		ShellCommand help = new HelpCommand();
		commands.put(help.getCommandName(), help);
		ShellCommand pwd = new PwdCommand();
		commands.put(pwd.getCommandName(), pwd);
		ShellCommand cd = new CdCommand();
		commands.put(cd.getCommandName(), cd);
		ShellCommand pushd = new PushdCommand();
		commands.put(pushd.getCommandName(), pushd);
		ShellCommand popd = new PopdCommand();
		commands.put(popd.getCommandName(), popd);
		ShellCommand listd = new ListdCommand();
		commands.put(listd.getCommandName(), listd);
		ShellCommand dropd = new DropdCommand();
		commands.put(dropd.getCommandName(), dropd);
		ShellCommand massrename = new MassrenameCommand();
		commands.put(massrename.getCommandName(), massrename);
	}

	@Override
	public String readLine() {
		StringBuilder string = new StringBuilder();
		String line = sc.nextLine();
		while (line.endsWith(moreLinesSymbol.toString())) {
			string.append(line, 0, line.length() - 1);
			write(multiLineSymbol + " ");
			line = sc.nextLine();
		}

		string.append(line);
		return string.toString();
	}

	@Override
	public void write(String text) {
		System.out.print(text);

	}

	@Override
	public void writeln(String text) {
		System.out.println(text);
	}

	@Override
	public SortedMap<String, ShellCommand> commands() {
		return new TreeMap<String, ShellCommand>(commands);

	}

	@Override
	public Character getMultilineSymbol() {
		return multiLineSymbol;
	}

	@Override
	public void setMultilineSymbol(Character symbol) {
		this.multiLineSymbol = symbol;
	}

	@Override
	public Character getPromptSymbol() {
		return promptSymbol;
	}

	@Override
	public void setPromptSymbol(Character symbol) {
		this.promptSymbol = symbol;

	}

	@Override
	public Character getMorelinesSymbol() {
		return moreLinesSymbol;
	}

	@Override
	public void setMorelinesSymbol(Character symbol) {
		this.moreLinesSymbol = symbol;
	}

	@Override
	public Path getCurrentDirectory() {
		return currentDirectory;
	}

	@Override
	public void setCurrentDirectory(Path path) {
		if (!Files.exists(path)) {
			this.writeln("File does not exist.");

		}
		this.currentDirectory = path;
	}

	@Override
	public Object getSharedData(String key) {
		return sharedData.get(key);
	}

	@Override
	public void setSharedData(String key, Object value) {
		if (key == null) {
			this.writeln("Key can not be null.");
		}
		sharedData.put(key, value);
	}

}
