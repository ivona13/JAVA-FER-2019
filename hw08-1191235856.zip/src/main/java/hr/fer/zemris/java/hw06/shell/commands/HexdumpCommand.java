package hr.fer.zemris.java.hw06.shell.commands;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class represents hexdump command. It takes single argument which is file
 * name. It gives hex output of given file.
 * 
 * @author ivona
 *
 */
public class HexdumpCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		String pathString = Utility.parsePath(arguments, env);

		Path path = Paths.get(pathString);

		if (Files.isDirectory(path)) {
			env.writeln("File is directory - not valid.");
			env.writeln(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		try {
			hexDump(env, path);

		} catch (IOException e) {
			env.writeln("Error while opening file.");
			env.writeln(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	/**
	 * This class dump hex data of input file to environment.
	 * 
	 * @param env  environment
	 * @param path path to file
	 * @throws IOException If something went wrong
	 */
	private void hexDump(Environment env, Path path) throws IOException {
		try (InputStream stream = new BufferedInputStream(new FileInputStream(path.toFile()))) {

			int read = 0;
			int counter = 0;

			while (true) {
				byte[] data = new byte[16];
				read = stream.read(data);

				if (read == -1) {
					break;
				}

				String hex = bytesToHexdump(data, read);
				String alphaNum = bytesToAlphanum(data, read);

				env.writeln(String.format("%08x: %s| %s", counter, hex.toUpperCase(), alphaNum));
				counter += read;
			}
		}
	}

	/**
	 * This class convers bytes array to alphanum value. If bytes < 37 or > 127,
	 * thay are shown as '.'
	 * 
	 * @param data byte array
	 * @param read size of filled data
	 * @return string
	 */
	private String bytesToAlphanum(byte[] data, int read) {
		StringBuilder builder = new StringBuilder();

		for (int i = 0; i < read; i++) {
			int val = Byte.valueOf(data[i]).intValue();
			if (val < 37 || val > 127) {
				builder.append(".");
			} else {
				builder.append(Character.toChars(val));
			}
		}

		return builder.toString();
	}

	/**
	 * COnverts bytes to hex representation
	 * 
	 * @param data byte array
	 * @param read size of filled data in array
	 * @return hex representation
	 */
	private String bytesToHexdump(byte[] data, int read) {
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < data.length; i++) {
			if (i < read) {
				buffer.append(Integer.toString((data[i] & 0xff) + 0x100, 16).substring(1));
			} else {
				buffer.append("  ");
			}

			if (i == 7)
				buffer.append("|");
			else
				buffer.append(" ");
		}

		return buffer.toString();
	}

	@Override
	public String getCommandName() {
		return "hexdump";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Hexdump command.");
		commandDescription.add("It takes a single argument which has to be file name.");
		commandDescription.add("It produces hex-output of given file.");

		return commandDescription;
	}
}
