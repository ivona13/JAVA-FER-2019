package hr.fer.zemris.java.hw06.shell.commands.massrename;

/**
 * This interface represents object used for generating parts of name of files.
 * 
 * @author ivona
 *
 */
public interface NameBuilder {

	/**
	 * This method is used for generating parts of name by writing it to StringBuilder sb.
	 * @param result result
	 * @param sb string builder
	 */
	void execute(FilterResult result, StringBuilder sb);

}
