package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent listd command. It lists all paths stored on
 * stack.
 * 
 * @author ivona
 *
 */
public class ListdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {
		if (arguments.length() != 0) {
			env.writeln("Listd command must be called without arguments!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		@SuppressWarnings("unchecked")
		Stack<Path> stack = (Stack<Path>) env.getSharedData("cdstack");

		if (stack == null || stack.isEmpty()) {
			env.writeln("No stored directories.");
		} else {

			List<Path> list = new ArrayList<Path>();
			list.addAll(stack);
			Collections.reverse(list);

			for (Path directory : list) {
				env.writeln(directory.toString());
			}
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	@Override
	public String getCommandName() {
		return "listd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Listd command.");
		commandDescription.add("It lists all paths stored in stack.");

		return commandDescription;
	}

}
