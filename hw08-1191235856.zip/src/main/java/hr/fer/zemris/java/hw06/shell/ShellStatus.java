package hr.fer.zemris.java.hw06.shell;

/**
 * This enum is used for representing Shell Status
 * 
 * @author ivona
 *
 */
public enum ShellStatus {

	/**
	 * Status for continue working
	 */
	CONTINUE,

	/**
	 * Stop
	 */
	TERMINATE;

}
