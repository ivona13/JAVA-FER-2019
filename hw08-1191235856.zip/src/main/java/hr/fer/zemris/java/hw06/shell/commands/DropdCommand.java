package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent dropd command. It poppes directory from the
 * stack.
 * 
 * @author ivona
 *
 */
public class DropdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {
		if (arguments.length() != 0) {
			env.writeln("Invalid number of arguments.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		@SuppressWarnings("unchecked")
		Stack<Path> stack = (Stack<Path>) env.getSharedData("cdstack");

		if (stack == null || stack.isEmpty()) {
			env.writeln("No directories to be dropped.");
		} else {
			stack.pop();
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "dropd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Dropd command.");
		commandDescription.add("It poppes directory from stack.");
		return commandDescription;
	}

}
