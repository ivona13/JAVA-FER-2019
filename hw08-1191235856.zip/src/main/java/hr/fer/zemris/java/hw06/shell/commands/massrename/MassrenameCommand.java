package hr.fer.zemris.java.hw06.shell.commands.massrename;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent massrename command. It is used for renaming
 * all contents of folder and moving it to another directory. Command has four
 * subcommands and one of them must be given as an argument. Subcommands are:
 * filter,groups,show and execute. Files will be selected with Pattern regex
 * which must also be provided as argument. Files will be renamed with Izraz
 * regex.
 * 
 * @author ivona
 *
 */
public class MassrenameCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {
		// Parse source
		String sourceString = Utility.parsePath(arguments);
		int currentIndexInArgument = sourceString.length();
		if (arguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, sourceString.length())
					.filter(i -> sourceString.charAt(i) == '"' || sourceString.charAt(i) == '\\').count();

		}
		currentIndexInArgument++;

		// Parse destination
		String destinationArguments = arguments.substring(currentIndexInArgument).trim();
		String destinationString = Utility.parsePath(destinationArguments);
		currentIndexInArgument += destinationString.length();
		if (destinationArguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, destinationString.length())
					.filter(i -> destinationString.charAt(i) == '"' || destinationString.charAt(i) == '\\').count();

		}
		currentIndexInArgument++;

		// Parse command
		String command = arguments.substring(currentIndexInArgument).trim().split(" ")[0];
		currentIndexInArgument += command.length() + 1;

		// Parse mask
		String maskArguments = arguments.substring(currentIndexInArgument).trim();
		String maskString = Utility.parsePath(maskArguments);
		currentIndexInArgument += maskString.length();
		if (maskArguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, maskString.length())
					.filter(i -> maskString.charAt(i) == '"' || maskString.charAt(i) == '\\').count();
		}
		currentIndexInArgument++;

		// Parse izraz
		String izrazString = null;
		if (command.equals("execute") || command.equals("show")) {
			String izrazArguments = arguments.substring(currentIndexInArgument).trim();
			izrazString = Utility.parsePath(izrazArguments);
			currentIndexInArgument += izrazString.length();

			final String lambdaString = izrazString;
			if (izrazArguments.startsWith("\"")) {
				currentIndexInArgument += 2;
				currentIndexInArgument += IntStream.range(0, izrazString.length())
						.filter(i -> lambdaString.charAt(i) == '"' || lambdaString.charAt(i) == '\\').count();
			}
			currentIndexInArgument++;
		}

		// Check if there are more arguments
		if (arguments.length() > currentIndexInArgument) {
			env.writeln("Invalid number of arguments.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		// Convert to dir
		Path source = env.getCurrentDirectory().resolve(sourceString);
		Path destination = env.getCurrentDirectory().resolve(destinationString);
		if (!Files.isDirectory(source) || !Files.isDirectory(destination)) {
			env.writeln("Not directory.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		try {
			List<FilterResult> results = FilterResult.filter(source, maskString);
			switch (command) {
			case "filter":
			case "groups":
				for (FilterResult file : results) {
					env.write(file.toString());
					if (command.contentEquals("groups"))
						for (int i = 0; i <= file.numberOfGroups(); i++) {
							env.write(" " + i + ": ");
							env.write(file.group(i));
						}
					env.writeln("");
				}
				break;

			case "show":
			case "execute":
				NameBuilderParser parser = new NameBuilderParser(izrazString);
				NameBuilder builder = parser.getNameBuilder();
				for (FilterResult file : results) {

					StringBuilder sb = new StringBuilder();
					builder.execute(file, sb);
					String newName = sb.toString();
					if (command.contentEquals("show")) {

						env.writeln(file.toString() + " => " + newName);
					} else {
						DirectoryStream<Path> directoryStream = Files.newDirectoryStream(source);
						for (Path path : directoryStream)
							if (path.getFileName().toString().equals(file.toString())) {
								Path movePath = destination.resolve(newName);
								Files.move(path, movePath, StandardCopyOption.REPLACE_EXISTING);
								env.writeln(sourceString + "/" + file.toString() + " => " + destinationString + "/"
										+ newName);
							}
					}
				}

				break;
			default:
				env.writeln("Invalid massrename function!");
				env.write(env.getPromptSymbol() + " ");
				break;
			}

		} catch (IOException e) {

		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "massrename";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Massrename command.");
		commandDescription.add("It is used for renaming all contents of folder and moving it to another directory.");
		commandDescription.add("Command has four subcommands and one of them must be given as an argument.");
		commandDescription.add("Subcommands are: filter,groups,show and execute.");
		commandDescription.add("Files will be selected with Pattern regex which must also be provided as argument.");
		commandDescription.add("Files will be renamed with Izraz regex.");

		return commandDescription;
	}

}
