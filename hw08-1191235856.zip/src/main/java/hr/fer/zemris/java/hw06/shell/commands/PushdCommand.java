package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent pushd command. "It pushed current directory
 * to stack and changes current directory to directory whose name is given in
 * argument.
 *
 * @author ivona
 *
 */
public class PushdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {
		String newDirectoryString = Utility.parsePath(arguments);

		String[] parts = newDirectoryString.split("\\s+");
		if (parts.length != 1) {
			env.writeln("Invalid number of arguments.");
			env.write(env.getPromptSymbol() + "");
			return ShellStatus.CONTINUE;
		}

		Path newDirectory = env.getCurrentDirectory().resolve(newDirectoryString);

		if (!Files.exists(newDirectory)) {
			env.writeln("No such file.");
			env.write(env.getPromptSymbol() + "");
			return ShellStatus.CONTINUE;
		}

		Path oldDirectory = env.getCurrentDirectory();

		env.setCurrentDirectory(newDirectory);
		@SuppressWarnings("unchecked")
		Stack<Path> stack = (Stack<Path>) env.getSharedData("cdstack");

		if (stack == null) {
			stack = new Stack<Path>();
		}

		stack.push(oldDirectory);

		env.setSharedData("cdstack", stack);
		env.writeln("Directory changed: " + env.getCurrentDirectory());
		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "pushd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<String>();

		commandDescription.add("Pushd command.");
		commandDescription.add(
				"It pushed current directory to stack and changes current directory to directory whose name is given in argument.");

		return commandDescription;
	}

}
