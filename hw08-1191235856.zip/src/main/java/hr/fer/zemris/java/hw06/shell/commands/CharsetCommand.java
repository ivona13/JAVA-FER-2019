package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent charset command. It takes no arguments and
 * lists names of all supported charsets(one per line).
 * 
 * @author ivona
 *
 */
public class CharsetCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {

		if (arguments.length() != 0) {
			env.writeln("There is not allowed to have arguments. INput must be empty.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		SortedMap<String, Charset> map = Charset.availableCharsets();
		Set<String> names = map.keySet();
		for (String string : names) {
			env.writeln(string);
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "charsets";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<String>();

		commandDescription.add("Charset command.");
		commandDescription.add("It lists name of all supported charsets.");
		commandDescription.add("A single charset name is written per line.");

		return commandDescription;
	}

}
