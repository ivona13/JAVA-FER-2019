package hr.fer.zemris.java.hw06.shell;

import java.nio.file.NoSuchFileException;

/**
 * This class is used to represent MyShell. It is used for communication between
 * Shell and user over commands.
 * 
 * @author ivona
 *
 */
public class MyShell {

	/**
	 * Main method
	 * @param args Command line arguments
	 */
	public static void main(String[] args) throws NoSuchFileException {
		Environment env = new ShellEnvironment();
		ShellStatus status = ShellStatus.CONTINUE;
		while (status != ShellStatus.TERMINATE) {
			String line = env.readLine();
			String commandName = Utility.parseName(line, env);
			String arguments = line.substring(commandName.length()).trim();

			ShellCommand command = env.commands().get(commandName);

			if (command == null) {
				env.writeln("Unknown command!");
				env.write(env.getPromptSymbol() + " ");
			} else {
				status = command.executeCommand(env, arguments);
			}
		}
	}

}
