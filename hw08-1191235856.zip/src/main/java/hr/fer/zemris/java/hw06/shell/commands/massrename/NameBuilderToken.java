package hr.fer.zemris.java.hw06.shell.commands.massrename;

/**
 * This class is used to represent token for NameBuilderLexer
 * 
 * @author ivona
 *
 */
public class NameBuilderToken {

	/**
	 * Token value
	 */
	private String value;

	/**
	 * Token type
	 */
	private NameBuilderTokenType type;

	/**
	 * Basic constructor
	 *
	 * @param value value
	 * @param type  Type
	 */
	public NameBuilderToken(String value, NameBuilderTokenType type) {
		this.value = value;
		this.type = type;
	}

	/**
	 * Value getter
	 *
	 * @return value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Type getter
	 *
	 * @return type
	 */
	public NameBuilderTokenType getType() {
		return type;
	}
}
