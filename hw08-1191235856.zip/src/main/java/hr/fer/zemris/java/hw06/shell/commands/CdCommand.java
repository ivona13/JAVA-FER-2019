package hr.fer.zemris.java.hw06.shell.commands;

import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent cd command. It changes current shell
 * directory.
 * 
 * @author ivona
 *
 */
public class CdCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) throws NoSuchFileException {
		String newDirectoryString = Utility.parsePath(arguments);

		String parts[] = newDirectoryString.split("\\s+");

		if (parts.length != 1) {
			env.writeln("Invalid number of aguments.");
			env.writeln(env.getPromptSymbol() + "");
			return ShellStatus.CONTINUE;
		}

		Path newDirectory = env.getCurrentDirectory().resolve(newDirectoryString).normalize();

		if (!Files.exists(newDirectory)) {
			env.writeln("No such file.");
			return ShellStatus.CONTINUE;
		}
		env.setCurrentDirectory(newDirectory);
		env.writeln("Current directory changed: " + env.getCurrentDirectory());

		env.write(env.getPromptSymbol() + "");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "cd";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<String>();

		commandDescription.add("Cd command.");
		commandDescription.add("It changes current shell directory.");

		return commandDescription;
	}

}
