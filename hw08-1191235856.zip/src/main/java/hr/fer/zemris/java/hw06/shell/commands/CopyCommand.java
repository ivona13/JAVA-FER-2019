package hr.fer.zemris.java.hw06.shell.commands;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent copy command. It takes two arguments - first
 * one is sourceFile, and second one is destinationFile. If both arguments are
 * provided, the user is asked if he wants to overwrite it.
 * 
 * @author ivona
 *
 */
public class CopyCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		String sourceString = Utility.parsePath(arguments, env);
		// System.out.println(sourceString);

		int currentIndexInArgument = sourceString.length();

		if (arguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, sourceString.length())
					.filter(i -> sourceString.charAt(i) == '"' || sourceString.charAt(i) == '\\').count();

		}

		String destinationArguments = arguments.substring(currentIndexInArgument).trim();

		// lets get destination file name
		String destinationString = Utility.parsePath(destinationArguments, env);

		// System.out.println("destination " + destinationString);

		currentIndexInArgument += destinationString.length();

		if (destinationArguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, destinationString.length())
					.filter(i -> destinationString.charAt(i) == '"' || destinationString.charAt(i) == '\\').count();

		}

		currentIndexInArgument++;

		if (arguments.length() > currentIndexInArgument) {
			env.writeln("Invalid number of arguments to copy function!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		Path source = Paths.get(sourceString);
		Path destination = Paths.get(destinationString);

		if (Files.isDirectory(destination)) {
			// create new File in current directory with the same name as the file we want
			// to copy
			// than continue with action as it was file

			// System.out.println("You are in directory");
			File newFile = new File(destination + File.separator + source.getFileName());
			// System.out.println(newFile.getName());
			destination = newFile.toPath();
			// System.out.println(destination + " is directory " +
			// Files.isDirectory(destination));

		}

		if (source.equals(destination)) {
			env.writeln("Cannot copy file to itself!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		if (Files.exists(destination)) {
			env.writeln("Do you want to overwrite file?(Y/N)");
			env.write(env.getPromptSymbol() + " ");
			String answer = env.readLine();
			if (!(answer.equals("Y") || answer.equals("y"))) {
				env.writeln("File will not be copied!");
				env.write(env.getPromptSymbol() + " ");
				return ShellStatus.CONTINUE;
			}
		}

		try (InputStream inputStream = Files.newInputStream(source, StandardOpenOption.READ);
				OutputStream outputStream = Files.newOutputStream(destination, StandardOpenOption.CREATE)) {
			byte[] buffer = new byte[4096];
			while (true) {
				int b = inputStream.read(buffer);
				if (b == -1)
					break;

				outputStream.write(buffer, 0, b);
			}

		} catch (IOException e) {
			env.writeln("Error while opening files!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		env.writeln("File copied.");
		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	@Override
	public String getCommandName() {
		return "copy";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Copy command.");
		commandDescription.add("Expects two arguments: source file name and destination file name.");
		commandDescription.add("If destination file exists, you should ask user is it allowed to overwrite it.");
		commandDescription.add(
				"If the second argument is directory, you should assume that user wants to copy the original file into that directory using the original file name.");

		return commandDescription;
	}

}
