package hr.fer.zemris.java.hw06.shell.commands.massrename;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to represent object which represents a file with all
 * information about number of found groups and a method for getting the group
 * after filtering.
 * 
 * @author ivona
 *
 */
public class FilterResult {

	/**
	 * Matcher
	 */
	private Matcher matcher;

	/**
	 * File name
	 */
	String fileName;

	/**
	 * Basic constructor
	 * 
	 * @param fileName fileName
	 * @param matcher  matcher
	 */
	public FilterResult(String fileName, Matcher matcher) {
		this.fileName = fileName;
		this.matcher = matcher;
	}

	@Override
	public String toString() {
		return fileName;
	}

	/**
	 * This method returns number of found groups.
	 * 
	 * @return number of groupss
	 */
	public int numberOfGroups() {
		return matcher.groupCount();
	}

	/**
	 * This method is used for getting group of index given as paramether
	 * 
	 * @param index index of group
	 * @return group
	 */
	public String group(int index) {
		try {
			return matcher.group(index);
		} catch (IndexOutOfBoundsException ex) {
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * This method is used for storing object of type FilterResult in given
	 * directory which satisfy given pattern.
	 * 
	 * @param dir           directory in which files are searched
	 * @param patternString pattern
	 * @return list of objects of type FilterResult
	 * @throws IOException if error occurs while reading from directory
	 */
	public static List<FilterResult> filter(Path dir, String patternString) throws IOException {
		List<FilterResult> list = new LinkedList<FilterResult>();

		Pattern pattern = Pattern.compile(patternString);

		DirectoryStream<Path> directory = Files.newDirectoryStream(dir);

		for (Path entry : directory) {
			Matcher m = pattern.matcher(entry.getFileName().toString());
			if (m.matches()) {
				list.add(new FilterResult(entry.getFileName().toString(), m));
			}
		}

		return list;

	}

}
