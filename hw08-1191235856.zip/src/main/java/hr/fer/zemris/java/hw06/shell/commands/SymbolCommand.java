package hr.fer.zemris.java.hw06.shell.commands;

import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class represent symbol command. If it has no arguments and is used only
 * with SYMBOL, it prints symbol for SYMBOL. If it is called with two arguments,
 * it sets SYMBOL to appropriate symbol.
 * 
 * @author ivona
 *
 */
public class SymbolCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		String[] arg = arguments.split(" ");

		if (arg.length == 1) {
			Character symbol;
			switch (arg[0]) {
			case "PROMPT":
				symbol = env.getPromptSymbol();
				break;
			case "MORELINES":
				symbol = env.getMorelinesSymbol();
				break;

			case "MULTILINE":
				symbol = env.getMultilineSymbol();
				break;

			default:
				env.write("Invalid symbol name.");
				env.write(env.getPromptSymbol() + " ");
				return ShellStatus.CONTINUE;

			}
			env.writeln("Symbol for " + arg[0] + " is '" + symbol + "'");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		if (arg[1].length() != 1) {
			env.write("Invalid symbol.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;

		}

		Character symbol = arg[1].charAt(0);

		switch (arg[0]) {
		case "PROMPT":
			env.writeln("Symbol for PROMPT changed from '" + env.getPromptSymbol() + "' to '" + symbol + "'");
			env.setPromptSymbol(symbol);
			break;

		case "MORELINES":
			env.writeln("Symbol for MORELINES changed from '" + env.getMorelinesSymbol() + "' to '" + symbol + "'");
			env.setMorelinesSymbol(symbol);
			break;

		case "MULTILINE":
			env.writeln("Symbol for MULTILINE changed from " + env.getMultilineSymbol() + " to " + symbol + " .");
			env.setMultilineSymbol(symbol);
			break;

		default:
			env.writeln("Invalid symbol.");
		}
		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	@Override
	public String getCommandName() {
		return "symbol";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Symbol command.");
		commandDescription.add("If used with only symbol name it print symbol of MyShell for given symbol name.");
		commandDescription.add("If used with two arguments, it sets symbol of given name to given character.");

		return commandDescription;

	}

}
