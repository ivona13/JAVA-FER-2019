package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

/**
 * This class represents Element whose value is of type integer.
 * 
 * @author Ivona
 *
 */
public class ElementConstantInteger extends Element {

	/**
	 * Value of element
	 */
	private int value;

	/**
	 * Constructor of ElementConstantInteger
	 * 
	 * @param value Value to be set as the value of Element
	 */
	public ElementConstantInteger(int value) {
		this.value = value;
	}

	@Override
	public String asText() {
		return Integer.toString(value);
	}

	/**
	 * This method returns value of Element
	 * 
	 * @return Value
	 */
	public int getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ElementConstantInteger))
			return false;
		ElementConstantInteger other = (ElementConstantInteger) obj;
		return value == other.value;
	}
	
	
}
