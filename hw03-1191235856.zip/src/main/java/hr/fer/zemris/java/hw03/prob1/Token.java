package hr.fer.zemris.java.hw03.prob1;

import java.util.Objects;

/**
 * This class represents token. Token is basic unit of parsed data in Lexer.
 * 
 * @author Ivona
 *
 */
public class Token {


	/**
	 * Token type
	 */
	private final TokenType type;

	/**
	 * Value of token
	 */
	private final Object value;


	/**
	 * Constructor.
	 * 
	 * @param type  Token type
	 * @param value Value of token
	 */
	public Token(TokenType type, Object value) {
		this.type = type;
		this.value = value;

	}

	/**
	 * This method returns type of Token.
	 * 
	 * @return Token type
	 */
	public TokenType getType() {
		return type;
	}

	/**
	 * This method returns value of token.
	 * 
	 * @return Value of token.
	 */
	public Object getValue() {
		return value;
	}

	@Override
	public String toString() {
		return "(" + type + ", " + value + ")";
	}

	@Override
	public int hashCode() {
		return Objects.hash(type, value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Token)) {
			return false;
		}
		Token other = (Token) obj;
		return type == other.type && Objects.equals(value, other.value);
	}

}
