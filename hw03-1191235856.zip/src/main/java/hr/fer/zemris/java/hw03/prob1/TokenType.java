package hr.fer.zemris.java.hw03.prob1;

/**
 * This enumeration represents types of Token.
 * 
 * @author Ivona
 *
 */
public enum TokenType {
	/**
	 * End of file
	 */
	EOF,

	/**
	 * Word type
	 */
	WORD,

	/**
	 * Number type
	 */
	NUMBER,

	/**
	 * Symbol type
	 */
	SYMBOL

}