package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

/**
 * This class represents Element whose value is function.
 * 
 * @author Ivona
 *
 */
public class ElementFunction extends Element {

	/**
	 * Function name
	 */
	private String name;

	/**
	 * Constructor.
	 * 
	 * @param name Name of function
	 */
	public ElementFunction(String name) {
		super();
		this.name = name;
	}

	@Override
	public String asText() {
		return "@" + name;
	}

	/**
	 * This method returns name of ElementFunction
	 * 
	 * @return Name of function
	 */
	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ElementFunction))
			return false;
		ElementFunction other = (ElementFunction) obj;
		return Objects.equals(name, other.name);
	}

}