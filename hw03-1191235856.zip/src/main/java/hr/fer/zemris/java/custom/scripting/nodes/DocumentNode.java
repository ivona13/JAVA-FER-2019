package hr.fer.zemris.java.custom.scripting.nodes;


/**
 * This class represents node with the highest level.
 * Actually, it does nothing, it just keeps his children.
 * 
 * @author Ivona
 *
 */
public class DocumentNode extends Node {

	@Override
	public String toString() {
		StringBuilder children = new StringBuilder();
		for (int i = 0, size = numberOfChildren(); i < size; i++) {
			Node child = getChild(i);
			children.append(child.toString());
		}

		return children.toString();
	}
}
