package hr.fer.zemris.java.hw03.prob1;

/**
 * This enumeration represents states of Lexer.
 * 
 * @author Ivona
 *
 */
public enum LexerState {

	/**
	 * Basic state of Lexer
	 */
	BASIC,

	/**
	 * Extended state of Lexer
	 */
	EXTENDED;
}