package hr.fer.zemris.java.custom.collections;


/**
 * Thrown to indicate that the stack is empty.
 * 
 * @author Ivona
 *
 */
@SuppressWarnings("serial")
public class EmptyStackException extends RuntimeException {

	

	/**
	 * Instantiates EmptyStackException with the provided message
	 * 
	 * @param string Message
	 */
	public EmptyStackException(String string) {
		// zovem superclass constructor
		super(string);
	}


	/**
	 * Constructs a new runtime exception with the specified detail message and
	 * cause.
	 * 
	 * @param string the detail message
	 * @param cause   the cause
	 */
	public EmptyStackException(String string, Throwable cause) {
		super(string, cause);
	}

}
