package hr.fer.zemris.java.custom.scripting.nodes;

import java.util.Arrays;

import hr.fer.zemris.java.custom.collections.Util;
import hr.fer.zemris.java.custom.scripting.elems.Element;

/**
 * This class stores data from echo nodes.
 * 
 * @author Ivona
 *
 */
public class EchoNode extends Node {

	/**
	 * Elements of node
	 */
	private Element[] elements;

	/**
	 * Constructor which makes echo node whose elements are elements of input array.
	 * 
	 * @param elements Elements
	 * @throws NullPointerException if elements are null
	 */
	public EchoNode(Element[] elements) {
		this.elements = Util.validateNotNull(elements, "elements");
	}

	/**
	 * This method returns elements of Node.
	 * 
	 * @return Elements
	 */
	public Element[] getElements() {
		return elements;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder("{$= ");
		for (Element element : elements) {
			builder.append(element.asText()).append(" ");
		}
		builder.append("$}");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Arrays.hashCode(elements);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof EchoNode)) {
			return false;
		}
		EchoNode other = (EchoNode) obj;
		return Arrays.equals(elements, other.elements);
	}

}
