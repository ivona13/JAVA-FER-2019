package hr.fer.zemris.java.hw03.prob1;

/**
 * This method represents Lexer exception.
 * 
 * @author Ivona
 *
 */
public class LexerException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Basic constructor.
	 */
	public LexerException() {
		super();
	}

	/**
	 * Constructor with input message.
	 * 
	 * @param message Message of exception.
	 */
	public LexerException(String message) {
		super(message);
	}

   /**
	 * Constructor with input message and cause.
	 * 
	 * @param message Message of exception.
     * @param cause Cause 
	 */
    public LexerException(String message, Throwable cause) {
		super(message, cause);
	}
}
