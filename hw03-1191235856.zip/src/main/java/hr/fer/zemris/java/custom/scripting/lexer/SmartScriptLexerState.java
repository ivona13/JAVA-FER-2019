package hr.fer.zemris.java.custom.scripting.lexer;

/**
 * This enum represents SmartScriptLexer states.
 * 
 * @author Ivona
 *
 */
public enum SmartScriptLexerState {

	/**
	 * Text state
	 */
	TEXT,

	/**
	 * Tag name state ('=' or variable name).
	 */
	TAG_NAME,

	/**
	 *Different types
	 */
	TAG_BODY

}
