package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

/**
 * This class represents Element whose value is of type double.
 * 
 * @author Ivona
 *
 */
public class ElementConstantDouble extends Element {


	/**
	 * Value of element
	 */
	private final double value;

	/**
	 * Constructor of ElementConstatDouble
	 * 
	 * @param value Value to be set as the value of Element
	 */
	public ElementConstantDouble(double value) {
		this.value = value;
	}

	@Override
	public String asText() {
		return Double.toString(value);
	}

	/**
	 * This method returns value of Element
	 * 
	 * @return Value
	 */
	public double getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ElementConstantDouble))
			return false;
		ElementConstantDouble other = (ElementConstantDouble) obj;
		return Double.doubleToLongBits(value) == Double.doubleToLongBits(other.value);
	}

	

}
