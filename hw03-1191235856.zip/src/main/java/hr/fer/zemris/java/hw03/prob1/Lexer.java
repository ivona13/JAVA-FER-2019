package hr.fer.zemris.java.hw03.prob1;

/**
 * This class takes input text and tokenized it. Every call of NextNode
 * generates new token until the end of text. The last generated token is
 * TokenType.EOF. Lexer has two states: basic and extended. When lexer is in
 * basic state, it separates words, number and symbols. If '\' appears, then the
 * following digit will be interpreted as word. When first '#' is found, lexer
 * goes to extended state, and everything that follows will be interpreted as
 * word until next '#' is found. LexerException will be thrown if there is an
 * error in input and IllegalArgumentException will be thrown when the initial
 * parameters are not supported.
 * 
 * @author Ivona
 *
 */
public class Lexer {

	/**
	 * Input text data
	 */
	private char[] data;

	/**
	 * The latest found token.
	 */
	private Token token;

	/***
	 * Index of last analyzed character
	 */
	private int currentIndex;

	/**
	 * Current state of Lexer
	 */
	private LexerState state;

	private static final char STATE_CHANGER = '#';

	/**
	 * Constructor that takes String string that will be tokenized.
	 * 
	 * @param string Text to be tokenized
	 * @throws NullPointerException when input is null
	 */
	public Lexer(String string) {
		if (string == null) {
			throw new NullPointerException("Argument is not valid.");
		}
		string = string.trim();
		this.data = string.toCharArray();
		this.state = LexerState.BASIC;
	}

	/**
	 * Generates a new token from given text and returns it.
	 * 
	 * @return generated Token
	 * @throws LexerException if there is no more token to be generated
	 */
	public Token nextToken() {

		if (currentIndex > data.length) {
			throw new LexerException("No more tokens to be generated!");
		}

		if (currentIndex == data.length) {
			currentIndex++;
			token = new Token(TokenType.EOF, null);
		}

		if (currentIndex < data.length) {

			// preskoci bjeline
			while (Character.isWhitespace(data[currentIndex]) && currentIndex < data.length - 1) {
				currentIndex++;
			}

			switch (state) {
			case BASIC:
				token = basicState();
				break;
			case EXTENDED:
				token = extendedState();
				break;
			}
		}
		return token;
	}

	/**
	 * This method generates Token when lexer is in extended state.
	 * 
	 * @return generated Token
	 */
	private Token extendedState() {

		TokenType type = null;
		Object value = null;
		String string = "";

		if (data[currentIndex] == STATE_CHANGER) {
			type = TokenType.SYMBOL;
		} else {
			type = TokenType.WORD;
		}

		for (; currentIndex < data.length; currentIndex++) {
			if (data[currentIndex] == ' ') {
				break;
			}
			if (data[currentIndex] == STATE_CHANGER) {
				setState(LexerState.BASIC);
				break;
			}
			string += data[currentIndex];
		}

		if (string.length() > 0) {
			type = TokenType.WORD;
			value = string;
		} else {

			// samo jedan #
			type = TokenType.SYMBOL;
			value = STATE_CHANGER;
			currentIndex++;
		}

		return new Token(type, value);
	}

	/**
	 * This method generates Token when lexer is in basic state.
	 * 
	 * @return generated Token
	 * @throws LexerException if generated number is too big.
	 */
	private Token basicState() {
		TokenType type = null;
		Object value = null;

		if (Character.isLetter(data[currentIndex]) || data[currentIndex] == '\\') {
			type = TokenType.WORD;
			value = processWord();
		} else if (Character.isDigit(data[currentIndex])) {
			type = TokenType.NUMBER;
			try {
				value = processNumber();
			} catch (NumberFormatException ex) {
				throw new LexerException("The number is too big.");
			}
		} else {
			type = TokenType.SYMBOL;
			value = data[currentIndex];
			currentIndex++;
		}
		return new Token(type, value);
	}

	/**
	 * This method processes number in input text.
	 * 
	 * @return Number which has been processed
	 * @throws LexerException if number is too big
	 */
	private Long processNumber() {
		String string = "";
		for (; currentIndex < data.length; currentIndex++) {
			if (data[currentIndex] == ' ' || !Character.isDigit(data[currentIndex])) {
				break;
			}
			string += data[currentIndex];
		}
		try {
			return Long.parseLong(string);
		} catch (NumberFormatException ex) {
			throw new LexerException("The number is too big.");
		}
	}

	/**
	 * This method processes word in input text.
	 * 
	 * @return String which has been processed
	 * @throws LexerException if '\' appears and there is not any character of '\'
	 *                        following it.
	 */
	private String processWord() {
		String string = "";
		for (; currentIndex < data.length; currentIndex++) {
			if (data[currentIndex] == '\\') {
				if (currentIndex >= data.length - 1) {
					throw new LexerException("Character expected after escape sign.");
				}
				if (!Character.isDigit(data[currentIndex + 1]) && data[currentIndex + 1] != '\\') {
					throw new LexerException("Invalid escape sequence.");
				}
				string += data[currentIndex + 1];
				currentIndex++;
				continue;
			}
			if (data[currentIndex] == ' ' || !Character.isLetter(data[currentIndex])) {
				break;
			}
			string += data[currentIndex];
		}
		return string;
	}

	/**
	 * This method returns last generated token.
	 * 
	 * @return Last generated token.
	 */
	public Token getToken() {
		return token;
	}

	/**
	 * Changes the state of lexer.
	 * 
	 * @param state New state to be set
	 */
	public void setState(LexerState state) {
		if (state == null) {
			throw new NullPointerException("State cannot be: " + state);
		}
		this.state = state;
	}
}