package hr.fer.zemris.java.custom.scripting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexer;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexerState;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptToken;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptTokenType;

public class SmartScriptLexerTest {

	@Test
	public void NotNullTest() {
		SmartScriptLexer lexer = new SmartScriptLexer("");

		assertNotNull(lexer.nextToken());
	}

	@Test
	public void emptyTest() {
		SmartScriptLexer lexer = new SmartScriptLexer("");

		assertEquals(SmartScriptTokenType.EOF, lexer.nextToken().getType());
	}

	@Test
	public void getEmptyTest() {
		SmartScriptLexer lexer = new SmartScriptLexer("");

		SmartScriptToken token = lexer.nextToken();
		assertEquals(token, lexer.getToken());
	}

	@Test
	public void getTokenTest() {
		SmartScriptLexer lexer = new SmartScriptLexer("Zadaća iz jave.. {$= \"This is a string\" @sinus $}");

		SmartScriptToken token = lexer.nextToken();
		while (token.getType() != SmartScriptTokenType.EOF) {
			assertEquals(token, lexer.getToken());
			token = lexer.nextToken();
		}
	}

	private void checkTokenStream(SmartScriptLexer lexer, SmartScriptToken[] correctData) {
		int counter = 0;
		for (SmartScriptToken expected : correctData) {
			SmartScriptToken actual = lexer.nextToken();
			String msg = "Checking token " + counter + ":";
			assertEquals(expected, actual, msg);
			counter++;
		}
	}

	@Test
	void testTagBodyVariousInput() {
		String s = "{$= i i * @sin  \"0.000\" @decfmt $}";
		SmartScriptLexer lexer = new SmartScriptLexer(s);

		assertEquals(new SmartScriptToken(SmartScriptTokenType.OPEN_TAG, "{$"), lexer.nextToken());
		lexer.setState(SmartScriptLexerState.TAG_NAME);
		assertEquals(new SmartScriptToken(SmartScriptTokenType.TAG_NAME, "="), lexer.nextToken());
		lexer.setState(SmartScriptLexerState.TAG_BODY);

		SmartScriptToken correctData[] = { new SmartScriptToken(SmartScriptTokenType.VARIABLE, "i"),
				new SmartScriptToken(SmartScriptTokenType.VARIABLE, "i"),
				new SmartScriptToken(SmartScriptTokenType.OPERATOR, "*"),
				new SmartScriptToken(SmartScriptTokenType.FUNCTION, "sin"),
				new SmartScriptToken(SmartScriptTokenType.STRING, "0.000"),
				new SmartScriptToken(SmartScriptTokenType.FUNCTION, "decfmt"),
				new SmartScriptToken(SmartScriptTokenType.CLOSE_TAG, "$}") };

		checkTokenStream(lexer, correctData);
	}

}