package hr.fer.zemris.java.custom.scripting;

import static hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser.createOriginalDocumentBody;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParserException;


public class SmartScriptParsesTest {

	


	private void checkIfGood(int directChildren, String docBody) {
		SmartScriptParser parser = new SmartScriptParser(docBody);
		DocumentNode document = parser.getDocumentNode();
		String originalDocumentBody = createOriginalDocumentBody(document);
		SmartScriptParser parser2 = new SmartScriptParser(originalDocumentBody);
		DocumentNode document2 = parser2.getDocumentNode();

		if (directChildren >= 0) {
			assertEquals(directChildren, document.numberOfChildren());
			assertEquals(directChildren, document2.numberOfChildren());
		}
		assertEquals(document, document2);
	}

	private String loader(String filename) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try (InputStream is = this.getClass().getClassLoader().getResourceAsStream(filename)) {
			byte[] buffer = new byte[1024];
			while (true) {
				int read = is.read(buffer);
				if (read < 1)
					break;
				bos.write(buffer, 0, read);
			}
			return new String(bos.toByteArray(), StandardCharsets.UTF_8);
		} catch (IOException ex) {
			return null;
		}
	}

	@Test
	void testEscapingOutsideTagsSecond() {
		// Example \{$=1$}. Now actually write one {$=1$}
		checkIfGood(2, "Example \\{$=1$}. Now actually write one {$=1$}");
	}
	
	@Test
	void testParsingRegularEqualsTag() {
		// {$= i i * @sin "0.000" @decfmt $}
		checkIfGood(1, "{$= i i * @sin  \"0.000\" @decfmt $}");
	}
	
	
	@Test
	void testParsingForTag() {
		// {$ FOR * \" 1 \" -10 \" 1 \" $}{$END$}
		checkIfGood(1, "{$= i i * @sin  \"0.000\" @decfmt $}");
	}
	
	

}