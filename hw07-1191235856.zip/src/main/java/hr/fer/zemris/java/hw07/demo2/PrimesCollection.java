package hr.fer.zemris.java.hw07.demo2;

import java.util.Iterator;

/**
 * This class is used to represent collection of prime numbers. Number of
 * generated primes is set in input value of constructor.
 *
 * 
 * @author ivona
 *
 */
public class PrimesCollection implements Iterable<Integer> {

	/**
	 * Number of primes to be generated
	 */
	private int numberOfPrimes;

	/**
	 * Basic constructor
	 * 
	 * @param numberOfPrimes number of generated numbers
	 */
	public PrimesCollection(int numberOfPrimes) {
		this.numberOfPrimes = numberOfPrimes;
	}

	/**
	 * This class is used to represent iterator over prime numbers.
	 * 
	 * @author ivona
	 *
	 */
	private class iterator implements Iterator<Integer> {

		/**
		 * Maximum number of primes
		 */
		private int numberOfPrimes;

		/**
		 * Current number of generated primes
		 */
		private int currentNumberOfPrimes;

		/**
		 * Last generated prime number
		 */
		private int lastGenerated;

		/**
		 * Basic constructor
		 * 
		 * @param numberOfPrimes Number of primes to be generated
		 */
		public iterator(int numberOfPrimes) {

			this.numberOfPrimes = numberOfPrimes;
		}

		@Override
		public boolean hasNext() {
			return currentNumberOfPrimes < numberOfPrimes;
		}

		@Override
		public Integer next() {
			for (int i = lastGenerated + 1;; i++) {
				if (i == 1) {
					continue;
				}
				if (prime(i)) {
					currentNumberOfPrimes++;
					lastGenerated = i;
					return lastGenerated;
				}
			}

		}

		/**
		 * This method is used to check if number is generated
		 * 
		 * @param number Number to check if it is prime
		 * @return <code>True</code> if number is prime; otherwise <code>False</code>
		 */
		private boolean prime(int number) {
			for (int i = 2; i <= Math.sqrt(number); i++) {
				if (number % i == 0) {
					return false;
				}
			}
			return true;
		}

	}

	@Override
	public Iterator<Integer> iterator() {
		return new iterator(numberOfPrimes);
	}

}
