package hr.fer.zemris.java.hw07.observer2;

/**
 * This class is used to represent observer which prints current value of
 * subject.
 * 
 * @author ivona
 *
 */
public class SquareValue implements IntegerStorageObserver {

	@Override
	public void valueChanged(IntegerStorage.IntegerStorageChange change) {

		int value = change.getNewValue();
		System.out.println("Provided new value: " + value + ", square is " + value * value);

	}

}
