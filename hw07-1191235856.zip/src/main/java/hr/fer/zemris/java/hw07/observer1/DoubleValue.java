package hr.fer.zemris.java.hw07.observer1;

/**
 * This class is used to represent observer that prints double value of subject;
 * Time of prints is limited by the variable {@code writeTimes}.
 * 
 * @author ivona
 *
 */
public class DoubleValue implements IntegerStorageObserver {

	/**
	 * Maximum number of prints of value in Subject
	 */
	private int maxWriteTimes;

	/**
	 * Number of prints that have already happened
	 */
	private int writeTimes;

	/**
	 * Basic constructor
	 * 
	 * @param maxWriteTimes Maximum number of prints
	 */
	public DoubleValue(int maxWriteTimes) {
		super();
		this.maxWriteTimes = maxWriteTimes;
	}

	@Override
	public void valueChanged(IntegerStorage istorage) {

		if (writeTimes <= maxWriteTimes) {
			System.out.println("Double value: " + istorage.getValue() * 2);

			writeTimes++;

		} else {
			istorage.removeObserver(this);
		}
	}

}
