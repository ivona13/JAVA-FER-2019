package hr.fer.zemris.java.hw07.observer1;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to represent storage of int values; It is used as object
 * in observer pattern;
 * 
 * @author ivona
 *
 */
public class IntegerStorage {

	/**
	 * Current value
	 */
	private int value;

	/**
	 * List of observers
	 */
	private List<IntegerStorageObserver> observers;

	/**
	 * Basic constructor
	 * 
	 * @param initialValue Value
	 */
	public IntegerStorage(int initialValue) {
		observers = new ArrayList<IntegerStorageObserver>();
		this.value = initialValue;

	}

	/**
	 * This method is used for adding observers to the subject.
	 * 
	 * @param observer Observer to be added
	 */
	public void addObserver(IntegerStorageObserver observer) {
		observers.add(observer);
	}

	/**
	 * This method is used to remove observer from subject
	 * 
	 * @param observer Observer to be removed
	 */
	public void removeObserver(IntegerStorageObserver observer) {
		observers.remove(observer);
	}

	/**
	 * This method is used to remove all observers.
	 */
	public void clearObservers() {
		observers.clear();
	}

	/**
	 * Value getter
	 * 
	 * @return Value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Value setter
	 * 
	 * @param value Value
	 */
	public void setValue(int value) {
		if (this.value != value) {
			this.value = value;

			if (observers != null) {
				int originalSize = observers.size();

				for (int i = 0; i < originalSize; i++) {
					observers.get(i).valueChanged(this);
					if (originalSize != observers.size()) {
						originalSize--;
						i--;
					}
				}
			}
		}
	}

}
