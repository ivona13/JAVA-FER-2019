package hr.fer.zemris.java.hw07.demo4;

/**
 * This class is used to represent student record.
 * 
 * @author ivona
 *
 */
public class StudentRecord {

	/**
	 * Student jmbag
	 */
	public String jmbag;

	/**
	 * Student last name
	 */
	public String prezime;

	/**
	 * Student name
	 */
	public String ime;

	/**
	 * Student points on colloquium
	 */
	public double bodoviMeđuispit;

	/**
	 * Student points on final exam
	 */
	public double bodoviZavršni;

	/**
	 * Student points on laboratory exercises
	 */
	public double bodoviLaboratorijske;

	/**
	 * Student grade
	 */
	public int ocjena;

	/**
	 * Basic constuctor
	 * 
	 * @param jmbag                Jmbag
	 * @param prezime              Prezime
	 * @param ime                  Ime
	 * @param bodoviMeđuispit      Bodovi na međusipitu
	 * @param bodoviZavršni        Bodovi na završnom
	 * @param bodoviLaboratorijske bodovi iz laboratorijskih vjezbi
	 * @param ocjena               Ocjena
	 */
	public StudentRecord(String jmbag, String prezime, String ime, double bodoviMeđuispit, double bodoviZavršni,
			double bodoviLaboratorijske, int ocjena) {
		this.jmbag = jmbag;
		this.prezime = prezime;
		this.ime = ime;
		this.bodoviMeđuispit = bodoviMeđuispit;
		this.bodoviZavršni = bodoviZavršni;
		this.bodoviLaboratorijske = bodoviLaboratorijske;
		this.ocjena = ocjena;
	}

	/**
	 * Jmbag getter
	 * 
	 * @return jmbag
	 */
	public String getJmbag() {
		return jmbag;
	}

	/**
	 * Last name getter
	 * 
	 * @return prezime
	 */
	public String getPrezime() {
		return prezime;
	}

	/**
	 * Name getter
	 * 
	 * @return ime
	 */
	public String getIme() {
		return ime;
	}

	/**
	 * Points on colloquium getter
	 * 
	 * @return bodoviMeđuispit
	 */
	public double getBodoviMeđuispit() {
		return bodoviMeđuispit;
	}

	/**
	 * Points on final exam getter
	 * 
	 * @return bodoviZavršni
	 */
	public double getBodoviZavršni() {
		return bodoviZavršni;
	}

	/**
	 * Points on Laboratory exercises getter
	 * 
	 * @return bodoviLaboratorijske
	 */
	public double getBodoviLaboratorijske() {
		return bodoviLaboratorijske;
	}

	/**
	 * Grade getter
	 * 
	 * @return ocjena
	 */
	public int getOcjena() {
		return ocjena;
	}

	@Override
	public String toString() {
		return "StudentRecord [jmbag=" + jmbag + ", prezime=" + prezime + ", ime=" + ime + ", bodoviMeđuispit="
				+ bodoviMeđuispit + ", bodoviZavršni=" + bodoviZavršni + ", bodoviLaboratorijske="
				+ bodoviLaboratorijske + ", ocjena=" + ocjena + "]";
	}

}
