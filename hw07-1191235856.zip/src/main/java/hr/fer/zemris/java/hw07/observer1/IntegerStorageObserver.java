package hr.fer.zemris.java.hw07.observer1;

/**
 * This interface represents IntegerStorageObserver. It is used as abstract
 * observer in Observer pattern.
 * 
 * @author ivona
 *
 */
public interface IntegerStorageObserver {

	/**
	 * This method is used to note that some change happened in observer.
	 * 
	 * @param istorage IntegerStorage
	 */
	public void valueChanged(IntegerStorage istorage);
}
