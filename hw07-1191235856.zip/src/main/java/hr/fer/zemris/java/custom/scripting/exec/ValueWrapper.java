package hr.fer.zemris.java.custom.scripting.exec;

import java.util.function.BiFunction;

/**
 * This class is used for representing ValueWrapper.Possible types of vaalues to
 * be wrapped are : Integer, Double, String and null. Arithmetic operations are
 * allowed to be done on wrapping values.
 * 
 * @author ivona
 *
 */
public class ValueWrapper {

	/**
	 * Value of wrapper
	 */
	Object value;

	/**
	 * This method is used for checking if Object value possible to be wrapped If
	 * value is not null, Integer, Double, String, {@link RuntimeException} is
	 * thrown.
	 * 
	 * @param value Value to be checked
	 */
	public void checkType(Object value) {
		if (!(value == null || value instanceof Integer || value instanceof Double || value instanceof String)) {
			throw new RuntimeException("Type of value is not valid.");
		}

	}

	/**
	 * Basic constuctor
	 * 
	 * @param value Value of wrapper
	 */
	public ValueWrapper(Object value) {

		checkType(value);
		this.value = value;
	}

	/**
	 * Value getter
	 * 
	 * @return value
	 */
	public Object getValue() {
		return value;
	}

	/**
	 * Value setter
	 * 
	 * @param value Value
	 */
	public void setValue(Object value) {
		checkType(value);
		this.value = value;
	}

	/**
	 * This method is used for adding incValue to the value of Wrapper
	 * 
	 * @param incValue Value to be added
	 */
	public void add(Object incValue) {
		operation(incValue, (value1, value2) -> value1 + value2);

	}

	/**
	 * This method is used for subtraction decValue from the value of Wrapper
	 * 
	 * @param decValue Value to be subtracted from value of Wrapper
	 */
	public void subtract(Object decValue) {
		operation(decValue, (value1, value2) -> value1 - value2);
	}

	/**
	 * This method is used for multiplying value of Wrapper by mulValue
	 * 
	 * @param mulValue Value to be multiplied by
	 */
	public void multiply(Object mulValue) {
		operation(mulValue, (value1, value2) -> value1 * value2);
	}

	/**
	 * This method is used for dividing value of Wrapper by divValue
	 * 
	 * @param divValue Value to be divided by
	 */
	public void divide(Object divValue) {
		operation(divValue, (value1, value2) -> value1 / value2);
	}

	/**
	 * This method is used for comparing value of Wrapper with withValue
	 * 
	 * @param withValue value to be compared with value of wrapper
	 * @return 1 if value of Wrapper is bigger than withValue, 0 if they are equal;
	 *         otherwise -1
	 */
	public int numCompare(Object withValue) {
		return Double.compare(getValue(value), getValue(withValue));
	}

	/**
	 * This method is used for performing operation on two values : value of Wrapper
	 * and operationValue
	 * 
	 * @param operationValue value
	 * @param operation      Operation
	 */
	private void operation(Object operationValue, BiFunction<Double, Double, Double> operation) {
		double first = getValue(value);
		NumberType firstType = getType(value);

		double second = getValue(operationValue);
		NumberType secondType = getType(operationValue);

		double result = operation.apply(first, second);

		if ((firstType == NumberType.INTEGER) && (secondType == NumberType.INTEGER)) {
			this.value = (int) result;
		} else {
			this.value = result;
		}

	}

	/**
	 * This method is used for getting double value from object
	 * 
	 * @param value Value to be returned as double
	 * @return Double value of value
	 * @throws RuntimeException if it is not possible to convert value to double
	 */
	private double getValue(Object value) {
		if (value == null) {
			return 0;
		} else if (value instanceof Double) {
			return (double) value;
		} else if (value instanceof Integer) {
			return (int) value;
		} else if (value instanceof String) {
			try {
				String string = (String) value;
				if (string.contains(".") || string.contains("E")) {
					return Double.parseDouble(string);
				} else {
					return Integer.parseInt(string);
				}
			} catch (NumberFormatException ex) {
				throw new RuntimeException("String cannot be converted to double.");
			}
		} else {
			throw new RuntimeException("Unknown type of value.");
		}

	}

	/**
	 * This method is used for getting type of Object
	 * 
	 * @param value value
	 * @return NumberType of given value
	 * @throws RuntimeException if type of value is not valid
	 */
	private NumberType getType(Object value) {
		if (value == null) {
			return NumberType.INTEGER;
		} else if (value instanceof Double) {
			return NumberType.DOUBLE;
		} else if (value instanceof Integer) {
			return NumberType.INTEGER;
		} else if (value instanceof String) {
			String string = (String) value;
			if (string.contains(".") || string.contains("E")) {
				return NumberType.DOUBLE;
			} else {
				return NumberType.INTEGER;
			}
		} else {
			throw new RuntimeException("The type of value is not valid.");
		}
	}

	/**
	 * This class is used for enumerating type of value
	 * 
	 * @author ivona
	 *
	 */
	private enum NumberType {
		/**
		 * Integer type
		 */
		INTEGER,

		/**
		 * Double type
		 */
		DOUBLE
	}

}
