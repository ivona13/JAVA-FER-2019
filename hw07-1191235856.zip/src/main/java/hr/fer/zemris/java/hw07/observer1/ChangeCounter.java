package hr.fer.zemris.java.hw07.observer1;

/**
 * This class is used to represent observer that prints number of changes of
 * subject.
 * 
 * @author ivona
 *
 */
public class ChangeCounter implements IntegerStorageObserver {

	/**
	 * Counter of changes
	 */
	int counterOfModification;

	@Override
	public void valueChanged(IntegerStorage istorage) {

		System.out.println("Number of value changes since tracking: " + ++counterOfModification);

	}

}
