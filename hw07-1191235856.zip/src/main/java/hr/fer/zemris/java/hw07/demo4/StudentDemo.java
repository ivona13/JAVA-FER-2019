package hr.fer.zemris.java.hw07.demo4;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * This class is used to demonstrate StudentRecord
 * 
 * @author ivona
 *
 */
public class StudentDemo {

	/**
	 * Main method
	 * 
	 * @param args Command line arguments
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		List<String> lines = Files.readAllLines(Paths.get("studenti.txt"));

		List<StudentRecord> records = convert(lines);

		long broj = vratiBodovaViseOd25(records);
		System.out.println("ZADATAK 1");
		System.out.println(broj);
		System.out.println();

		long broj5 = vratiBrojOdlikasa(records);
		System.out.println("ZADATAK 2");
		System.out.println(broj5);
		System.out.println();

		List<StudentRecord> odlikasi = vratiListuOdlikasa(records);
		System.out.println("ZADATAK 3");
		odlikasi.forEach(System.out::println);
		System.out.println();

		List<StudentRecord> odlikasiSortirano = vratiSortiranuListuOdlikasa(records);
		System.out.println("ZADATAK 4");
		odlikasiSortirano.forEach(System.out::println);
		System.out.println();

		List<String> nepolozeniJMBAGovi = vratiPopisNepolozenih(records);
		System.out.println("ZADATAK 5");
		nepolozeniJMBAGovi.forEach(System.out::println);
		System.out.println();

		Map<Integer, List<StudentRecord>> mapaPoOcjenama = razvrstajStudentePoOcjenama(records);
		System.out.println("ZADATAK 6");
		for (Integer key : mapaPoOcjenama.keySet()) {
			System.out.println(key + " " + mapaPoOcjenama.get(key));
		}
		System.out.println();

		Map<Integer, Integer> mapaPoOcjenama2 = vratiBrojStudenataPoOcjenama(records);
		System.out.println("ZADATAK 7");
		for (Integer key : mapaPoOcjenama2.keySet()) {
			System.out.println(key + " " + mapaPoOcjenama2.get(key));
		}
		System.out.println();

		Map<Boolean, List<StudentRecord>> prolazNeprolaz = razvrstajProlazPad(records);
		System.out.println("ZADATAK 8");
		System.out.println("true " + prolazNeprolaz.get(true).size());
		System.out.println("false " + prolazNeprolaz.get(false).size());
	}

	/**
	 * This method is used for converting list of strings to list of StudentRecords.
	 *
	 * @param lines list of string that will be converted
	 * @return list of StudentRecords
	 */
	private static List<StudentRecord> convert(List<String> lines) {
		List<StudentRecord> records = new ArrayList<>();

		for (String line : lines) {
			String[] parts = line.split("\\s+");
			records.add(new StudentRecord(parts[0], parts[1], parts[2], Double.parseDouble(parts[3]),
					Double.parseDouble(parts[4]), Double.parseDouble(parts[5]), Integer.parseInt(parts[6])));
		}

		return records;
	}

	/**
	 * This method is used for getting number of students that have more than 25
	 * points in total.
	 *
	 * @param records List of students
	 * @return Number of students with the property
	 */
	public static long vratiBodovaViseOd25(List<StudentRecord> records) {
		return records.stream().filter(studentRecord -> (studentRecord.getBodoviMeđuispit()
				+ studentRecord.getBodoviZavršni() + studentRecord.bodoviLaboratorijske) > 25).count();
	}

	/**
	 * This method is used for getting list of students that have the grade equals
	 * five
	 *
	 * @param records List of students
	 * @return List of students with the property
	 */
	public static long vratiBrojOdlikasa(List<StudentRecord> records) {
		return records.stream().filter(studentRecord -> studentRecord.getOcjena() == 5).count();
	}

	/**
	 * This method is used for getting list of students that have grade equals 5.
	 *
	 * @param records List of students
	 * @return List of students that have grade equals 5
	 */
	public static List<StudentRecord> vratiListuOdlikasa(List<StudentRecord> records) {
		return records.stream().filter(studentRecord -> studentRecord.getOcjena() == 5).collect(Collectors.toList());
	}

	/**
	 * This method is used for getting sorted list of students that have grade
	 * equals 5.
	 *
	 * @param records List of StudentRecord
	 * @return List of students that have grade 5 sorted by total number of points
	 */
	public static List<StudentRecord> vratiSortiranuListuOdlikasa(List<StudentRecord> records) {
		return records.stream().filter(studentRecord -> studentRecord.getOcjena() == 5)
				.sorted((o2, o1) -> Double.compare(
						o1.getBodoviMeđuispit() + o1.getBodoviZavršni() + o1.getBodoviLaboratorijske(),
						o2.getBodoviMeđuispit() + o2.getBodoviZavršni() + o2.getBodoviLaboratorijske()))
				.collect(Collectors.toList());
	}

	/**
	 * This method is used for getting list of student's jmbag that did not pass
	 * class
	 *
	 * @param records List of StudentRecord
	 * @return List of jmbag of students that did not pass class
	 */
	public static List<String> vratiPopisNepolozenih(List<StudentRecord> records) {
		return records.stream().filter(studentRecord -> studentRecord.getOcjena() == 1).map(StudentRecord::getJmbag)
				.sorted(String::compareTo).collect(Collectors.toList());
	}

	/**
	 * This method is used for getting map whose keys are grades and values are
	 * lists of students with that grade-
	 *
	 * @param records List of studentRecord
	 * @return Map
	 */
	public static Map<Integer, List<StudentRecord>> razvrstajStudentePoOcjenama(List<StudentRecord> records) {
		return records.stream().collect(Collectors.groupingBy(StudentRecord::getOcjena));
	}

	/**
	 * This method is used for getting map whose keys are grades and values are
	 * number of students with that grade.
	 * 
	 * @param records List of StudentRecords
	 * @return Map
	 */
	public static Map<Integer, Integer> vratiBrojStudenataPoOcjenama(List<StudentRecord> records) {
		return records.stream().collect(Collectors.toMap(StudentRecord::getOcjena, a -> 1, (o1, o2) -> o1 + o2));
	}

	/**
	 * This method is used for getting map whose keys are boolean values true and
	 * false; values of the map are list of students that passed the class(key
	 * true), and list of students who did not pass the class(key false)
	 *
	 * @param records List of StudentRecord
	 * @return Map
	 */
	public static Map<Boolean, List<StudentRecord>> razvrstajProlazPad(List<StudentRecord> records) {
		return records.stream().collect(Collectors.partitioningBy(o -> o.getOcjena() > 1));
	}

}
