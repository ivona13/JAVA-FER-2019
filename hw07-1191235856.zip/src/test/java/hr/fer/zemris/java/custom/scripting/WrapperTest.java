package hr.fer.zemris.java.custom.scripting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.scripting.exec.ValueWrapper;

public class WrapperTest {

	@Test
	public void getValueTest() {
		ValueWrapper v1 = new ValueWrapper(null);
		assertEquals(v1.getValue(), null);
		
		ValueWrapper v2 = new ValueWrapper(2);
		assertEquals(v2.getValue(), 2);
	}
	
	@Test
	public void setValueTest() {
		ValueWrapper v1 = new ValueWrapper(2);
		v1.setValue(4);
		assertEquals(v1.getValue(), 4);
		
		
		ValueWrapper v2 = new ValueWrapper(4);
		v2.setValue(null);
		assertEquals(v2.getValue(), null);
	}
	
	@Test
	public void addTest() {
		ValueWrapper v1 = new ValueWrapper(13);
		v1.add(4);
		assertEquals(17, v1.getValue());
		
		ValueWrapper v2 = new ValueWrapper(7.0);
		v2.add(3.5);
		assertEquals(10.5, v2.getValue());
	}
	
	@Test
	public void addTestNull() {
		ValueWrapper v = new ValueWrapper(null);
		v.add(4);
		assertEquals(4, v.getValue());
	}
	
	@Test
	public void addStringDoubleTest() {
		ValueWrapper v = new ValueWrapper("3.14");
		v.add(5);
		assertEquals(8.14, v.getValue());
	}
	
	@Test
	public void addStringIntTest() {
		ValueWrapper v = new ValueWrapper("1");
		v.add(5);
		assertEquals(6, v.getValue());
	}
	
	@Test
	public void addFailStringTest() {
		ValueWrapper v = new ValueWrapper("Ivona13");
		boolean fail = false;
		try {
			v.add(5);
		} catch(RuntimeException e) {
			fail = true;
		}
		
		assertTrue(fail);
	}
	
	@Test
	public void addETest() {
		ValueWrapper v = new ValueWrapper("13.0E1");
		v.add(4);
		assertEquals(134.0, v.getValue());
	}
	
	@Test
	public void subtractTest() {
		ValueWrapper v1 = new ValueWrapper(13);
		v1.subtract(4);
		assertEquals(9, v1.getValue());
		
		ValueWrapper v2 = new ValueWrapper(7.0);
		v2.subtract(3.5);
		assertEquals(3.5, v2.getValue());
	}
	
	@Test
	public void subtractTestNull() {
		ValueWrapper v = new ValueWrapper(null);
		v.subtract(4);
		assertEquals(-4, v.getValue());
	}
	
	@Test
	public void subtractStringDoubleTest() {
		ValueWrapper v = new ValueWrapper("15.5");
		v.subtract(5);
		assertEquals(10.5, v.getValue());
		
	}
	
	@Test
	public void subtractStringIntTest() {
		ValueWrapper v = new ValueWrapper("1");
		v.subtract(5);
		assertEquals(-4, v.getValue());
	}
	
	@Test
	public void subtractFailStringTest() {
		ValueWrapper v = new ValueWrapper("Ivona13");
		boolean fail = false;
		try {
			v.subtract(5);
		} catch(RuntimeException e) {
			fail = true;
		}
		
		assertTrue(fail);
	}
	
	@Test
	public void multiplyTest() {
		ValueWrapper v1 = new ValueWrapper(13);
		v1.multiply(2);
		assertEquals(26, v1.getValue());
		
		ValueWrapper v2 = new ValueWrapper(2.0);
		v2.multiply(3.5);
		assertEquals(7.0, v2.getValue());
	}
	
	@Test
	public void multiplyTestNull() {
		ValueWrapper v = new ValueWrapper(null);
		v.multiply(4);
		assertEquals(0, v.getValue());
	}
	
	@Test
	public void multiplyStringDoubleTest() {
		ValueWrapper v = new ValueWrapper("1.2");
		v.multiply(5);
		assertEquals(6.0, v.getValue());
		
	}
	
	@Test
	public void multiplyStringIntTest() {
		ValueWrapper v = new ValueWrapper("1");
		v.multiply(5);
		assertEquals(5, v.getValue());
	}
	
	@Test
	public void multiplyFailStringTest() {
		ValueWrapper v = new ValueWrapper("Ivona13");
		boolean fail = false;
		try {
			v.multiply(5);
		} catch(RuntimeException e) {
			fail = true;
		}
		
		assertTrue(fail);
	}
	
	@Test
	public void divideETest() {
		 ValueWrapper v = new ValueWrapper("1.2E1");
		 v.divide(2);
		 assertEquals(6.0, v.getValue());
	}
	
	@Test
	public void divideTest() {
		ValueWrapper v1 = new ValueWrapper(14);
		v1.divide(2);
		assertEquals(7, v1.getValue());
		
		ValueWrapper v2 = new ValueWrapper(2.0);
		v2.divide(2);
		assertEquals(1.0, v2.getValue());
	}
	
	@Test
	public void divideTestNull() {
		ValueWrapper v = new ValueWrapper(null);
		v.divide(4);
		assertEquals(0, v.getValue());
	}
	
	@Test
	public void divideStringDoubleTest() {
		ValueWrapper v = new ValueWrapper("1.2");
		v.divide(2);
		assertEquals(0.6, v.getValue());
		
	}
	
	@Test
	public void divideStringIntTest() {
		ValueWrapper v = new ValueWrapper("8");
		v.divide(2);
		assertEquals(4, v.getValue());
	}
	
	@Test
	public void divideFailStringTest() {
		ValueWrapper v = new ValueWrapper("Ivona13");
		boolean fail = false;
		try {
			v.divide(5);
		} catch(RuntimeException e) {
			fail = true;
		}
		
		assertTrue(fail);
	}
	
	@Test
	public void multiplyETest() {
		 ValueWrapper v = new ValueWrapper("1.1E1");
		 v.multiply(4);
		 assertEquals(44.0, v.getValue());
	}
	
	@Test
	public void numCompareTest1() {
		ValueWrapper v = new ValueWrapper(1);
		ValueWrapper w = new ValueWrapper(4);
		
		 assertTrue(v.numCompare(w.getValue()) < 0);
	}
	
	@Test
	public void numCompareTest2() {
		ValueWrapper v = new ValueWrapper("13.0");
		ValueWrapper w = new ValueWrapper("4.0");
		
		 assertTrue(v.numCompare(w.getValue()) > 0);
	}
	
	
	@Test
	public void numCompareTest3() {
		ValueWrapper v = new ValueWrapper("13");
		ValueWrapper w = new ValueWrapper("13");
		
		 assertTrue(v.numCompare(w.getValue()) ==  0);
	}
	
}
