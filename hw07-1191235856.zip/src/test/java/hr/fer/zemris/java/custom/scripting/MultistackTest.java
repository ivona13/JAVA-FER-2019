package hr.fer.zemris.java.custom.scripting;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.EmptyStackException;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.custom.scripting.exec.ObjectMultistack;
import hr.fer.zemris.java.custom.scripting.exec.ValueWrapper;

public class MultistackTest {

	@Test
	public void pushTest() {
		ObjectMultistack multiStack = new ObjectMultistack();

		multiStack.push("Ivona", new ValueWrapper(13));
		multiStack.push("Ivona", new ValueWrapper(15));
		multiStack.push("Marko", new ValueWrapper(120));
		multiStack.push("Hana", new ValueWrapper(21));

		assertEquals(15, multiStack.peek("Ivona").getValue());
		assertEquals(15, multiStack.peek("Ivona").getValue());
		assertEquals(120, multiStack.peek("Marko").getValue());
		assertEquals(21, multiStack.peek("Hana").getValue());

	}

	@Test
	public void popTest() {
		ObjectMultistack multiStack = new ObjectMultistack();

		multiStack.push("Ivona", new ValueWrapper(13));
		multiStack.push("Ivona", new ValueWrapper(15));
		multiStack.push("Ivona", new ValueWrapper(1));

		assertEquals(1, multiStack.pop("Ivona").getValue());
		assertEquals(15, multiStack.pop("Ivona").getValue());
		assertEquals(13, multiStack.pop("Ivona").getValue());

	}

	@Test
	public void popEmptyTest() {
		ObjectMultistack multiStack = new ObjectMultistack();

		multiStack.push("Ivona", new ValueWrapper(13));

		assertEquals(13, multiStack.pop("Ivona").getValue());

		boolean fail = false;

		try {
			multiStack.pop("Ivona");
		} catch (EmptyStackException ex) {
			fail = true;
		}
		assertTrue(fail);
		
	}

	@Test
	public void peek() {
		ObjectMultistack multiStack = new ObjectMultistack();

		multiStack.push("Ivona", new ValueWrapper(13));
		multiStack.push("Ivona", new ValueWrapper(15));
		multiStack.push("Marko", new ValueWrapper(1));
	
		assertEquals(15, multiStack.peek("Ivona").getValue());
		assertEquals(1, multiStack.peek("Marko").getValue());
	}
	
	@Test
	public void isEmptyTest() {
		ObjectMultistack multiStack = new ObjectMultistack();

		multiStack.push("Ivona", new ValueWrapper(13));
		multiStack.push("Ivona", new ValueWrapper(15));
		multiStack.push("Marko", new ValueWrapper(1));
		multiStack.push("Marko", new ValueWrapper(8));
		multiStack.push("Hana", new ValueWrapper(1));
		multiStack.push("Hana", new ValueWrapper(9));
	
		assertTrue(multiStack.isEmpty("Lea"));
		assertFalse(multiStack.isEmpty("Ivona"));
		assertFalse(multiStack.isEmpty("Hana"));
	}
}
