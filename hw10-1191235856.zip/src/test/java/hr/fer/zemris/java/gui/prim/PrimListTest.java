package hr.fer.zemris.java.gui.prim;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PrimListTest {

	@Test
	public void getSizeTest() {
		PrimListModel model = new PrimListModel();
		assertEquals(1, model.getSize());

	}

	@Test
	public void getSizeTest2() {
		PrimListModel model = new PrimListModel();
		model.next();
		model.next();
		model.next();
		model.next();
		assertEquals(5, model.getSize());
	}

	@Test
	public void getElementAtTest() {
		PrimListModel model = new PrimListModel();
		assertEquals(1L, model.getElementAt(0));

		model.next();
		model.next();
		assertEquals(3L, model.getElementAt(2));

	}
	
	@Test
	public void nextTest() {
		PrimListModel model = new PrimListModel();
		model.next();
		model.next();
		model.next();
		model.next();
		assertEquals(5, model.getSize());
		assertEquals(7L, model.getElementAt(4));
	}
}
