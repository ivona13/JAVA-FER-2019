package hr.fer.zemris.java.gui.calc;

import java.awt.Checkbox;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Stack;
import java.util.function.DoubleBinaryOperator;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;

import hr.fer.zemris.java.gui.layouts.CalcLayout;

/**
 * This class is used to represent calculator whose logic is implemented in
 * {@link CalcModelImpl}.
 * 
 * @author ivona
 *
 */
public class Calculator extends JFrame {

	/**
	 * Default serialVersion
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Calculator model
	 */
	CalcModelImpl calcModel = new CalcModelImpl();

	/**
	 * Stack used for some operations in calculator
	 */
	private Stack<Double> calcStack = new Stack<Double>();

	/**
	 * Basic constructor
	 */
	public Calculator() {
		super();
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setTitle("Calculator");
		setLocation(20, 20);
		setSize(700, 300);
		initGUI();
	}

	/**
	 * This variable is used for giving information if some unary operation has
	 * allready applied. Calculator unary operation is implemented in following way:
	 * We press buttons with the digits, then unary operator button, and
	 * immidiately, result is displayed on calculator display. Then, for entering
	 * next number, display will be cleared.
	 */
	static boolean unary = false;

	/**
	 * This variable is used to give information about pressing Inv button
	 */
	static boolean inverse = false;

	/**
	 * Initializing gui Here are added buttons we will need in displaying
	 * components.
	 */
	private void initGUI() {
		Container cp = getContentPane();

		JPanel p = new JPanel(new CalcLayout(3));
		p.setBackground(Color.WHITE);

		JLabel ekran = new JLabel(calcModel.toString());
		ekran.setBackground(Color.YELLOW);
		ekran.setHorizontalAlignment(SwingConstants.RIGHT);
		ekran.setOpaque(true);

		calcModel.addCalcValueListener(calcModel -> ekran.setText(calcModel.toString()));
		p.add(ekran, "1,1");

		OperatorButton nula = new OperatorButton(calcModel, "0");
		addListenerToDigit(calcModel, nula);
		p.add(nula, "5,3");

		OperatorButton jedan = new OperatorButton(calcModel, "1");
		addListenerToDigit(calcModel, jedan);
		p.add(jedan, "4,3");

		OperatorButton dva = new OperatorButton(calcModel, "2");
		addListenerToDigit(calcModel, dva);
		p.add(dva, "4,4");

		OperatorButton tri = new OperatorButton(calcModel, "3");
		addListenerToDigit(calcModel, tri);
		p.add(tri, "4,5");

		OperatorButton četiri = new OperatorButton(calcModel, "4");
		addListenerToDigit(calcModel, četiri);
		p.add(četiri, "3,3");

		OperatorButton pet = new OperatorButton(calcModel, "5");
		addListenerToDigit(calcModel, pet);
		p.add(pet, "3,4");

		OperatorButton šest = new OperatorButton(calcModel, "6");
		addListenerToDigit(calcModel, šest);
		p.add(šest, "3,5");

		OperatorButton sedam = new OperatorButton(calcModel, "7");
		addListenerToDigit(calcModel, sedam);
		p.add(sedam, "2,3");

		OperatorButton osam = new OperatorButton(calcModel, "8");
		addListenerToDigit(calcModel, osam);
		p.add(osam, "2,4");

		OperatorButton devet = new OperatorButton(calcModel, "9");
		addListenerToDigit(calcModel, devet);
		p.add(devet, "2,5");

		OperatorButton plus = new OperatorButton(calcModel, "+");
		addListenerToOperation(calcModel, plus);
		p.add(plus, "5,6");

		OperatorButton minus = new OperatorButton(calcModel, "-");
		addListenerToOperation(calcModel, minus);
		p.add(minus, "4,6");

		OperatorButton puta = new OperatorButton(calcModel, "*");
		addListenerToOperation(calcModel, puta);
		p.add(puta, "3,6");

		OperatorButton dijeljeno = new OperatorButton(calcModel, "/");
		addListenerToOperation(calcModel, dijeljeno);
		p.add(dijeljeno, "2,6");

		OperatorButton sin = new OperatorButton(calcModel, "sin");
		addListenerToUnaryOperation(calcModel, sin);
		p.add(sin, "2,2");

		OperatorButton arcsin = new OperatorButton(calcModel, "arcsin");
		addListenerToUnaryOperation(calcModel, arcsin);

		OperatorButton cos = new OperatorButton(calcModel, "cos");
		addListenerToUnaryOperation(calcModel, cos);
		p.add(cos, "3,2");

		OperatorButton arccos = new OperatorButton(calcModel, "arccos");
		addListenerToUnaryOperation(calcModel, arccos);

		OperatorButton tan = new OperatorButton(calcModel, "tan");
		addListenerToUnaryOperation(calcModel, tan);
		p.add(tan, "4,2");

		OperatorButton arctan = new OperatorButton(calcModel, "arctan");
		addListenerToUnaryOperation(calcModel, arctan);

		OperatorButton ctg = new OperatorButton(calcModel, "ctg");
		addListenerToUnaryOperation(calcModel, ctg);
		p.add(ctg, "5,2");

		OperatorButton arcctg = new OperatorButton(calcModel, "arcctg");
		addListenerToUnaryOperation(calcModel, arcctg);

		OperatorButton rec = new OperatorButton(calcModel, "1/x");
		addListenerToUnaryOperation(calcModel, rec);
		p.add(rec, "2,1");

		OperatorButton log = new OperatorButton(calcModel, "log");
		addListenerToUnaryOperation(calcModel, log);
		p.add(log, "3,1");

		OperatorButton pot10 = new OperatorButton(calcModel, "10^x");
		addListenerToUnaryOperation(calcModel, pot10);

		OperatorButton ln = new OperatorButton(calcModel, "ln");
		addListenerToUnaryOperation(calcModel, ln);
		p.add(ln, "4,1");

		OperatorButton e = new OperatorButton(calcModel, "e^x");
		addListenerToUnaryOperation(calcModel, e);

		OperatorButton pot = new OperatorButton(calcModel, "x^n");
		addListenerToOperation(calcModel, pot);
		p.add(pot, "5,1");

		OperatorButton invPot = new OperatorButton(calcModel, "x^(1/n)");
		addListenerToOperation(calcModel, invPot);

		OperatorButton predznak = new OperatorButton(calcModel, "+/-");
		addListenerToUnaryOperation(calcModel, predznak);
		p.add(predznak, "5,4");

		OperatorButton tocka = new OperatorButton(calcModel, ".");
		addListenerToUnaryOperation(calcModel, tocka);
		p.add(tocka, "5,5");

		OperatorButton clr = new OperatorButton(calcModel, "clr");
		addListenerToUnaryOperation(calcModel, clr);
		p.add(clr, "1,7");

		OperatorButton reset = new OperatorButton(calcModel, "reset");
		addListenerToUnaryOperation(calcModel, reset);
		p.add(reset, "2,7");

		OperatorButton push = new OperatorButton(calcModel, "push");
		addListenerToStackOperation(calcModel, push, calcStack);
		p.add(push, "3,7");

		OperatorButton pop = new OperatorButton(calcModel, "pop");
		addListenerToStackOperation(calcModel, pop, calcStack);
		p.add(pop, "4,7");

		// if inv is pressed, functions are replaced by its inverse
		Checkbox inv = new Checkbox("inv");
		inv.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent event) {
				if (inverse == false) {
					p.remove(sin);
					p.add(arcsin, "2,2");
					p.remove(cos);
					p.add(arccos, "3,2");
					p.remove(tan);
					p.add(arctan, "4,2");
					p.remove(ctg);
					p.add(arcctg, "5,2");
					p.remove(log);
					p.add(pot10, "3,1");
					p.remove(ln);
					p.add(e, "4,1");
					p.remove(pot);
					p.add(invPot, "5,1");

					inverse = true;
					p.revalidate();
				} else {
					p.remove(arcsin);
					p.add(sin, "2,2");
					p.remove(arccos);
					p.add(cos, "3,2");
					p.remove(arctan);
					p.add(tan, "4,2");
					p.remove(arcctg);
					p.add(ctg, "5,2");
					p.remove(pot10);
					p.add(log, "3,1");
					p.remove(e);
					p.add(ln, "4,1");
					p.remove(invPot);
					p.add(pot, "5,1");

					inverse = false;
					p.revalidate();

				}

			}
		});

		p.add(inv, "5,7");

		OperatorButton equals = new OperatorButton(calcModel, "=");
		addEqualsListener(calcModel, equals);
		p.add(equals, "1,6");

		cp.add(p);
		cp.setPreferredSize(p.getPreferredSize());
	}

	/**
	 * This method is used to add Listener to button with the label "="
	 * 
	 * @param calcModel calcModel
	 * @param equals    button of the operation =
	 */
	private void addEqualsListener(CalcModelImpl calcModel, OperatorButton equals) {
		equals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (calcModel.isActiveOperandSet() && calcModel.getPendingBinaryOperation() != null) {
					calcModel.setValue(calcModel.getPendingBinaryOperation().applyAsDouble(calcModel.getActiveOperand(),
							calcModel.getValue()));

					calcModel.clearActiveOperand();
				}

			}
		});
	}

	/**
	 * This method is used for checking state of calculator when binary operator
	 * happened.
	 */
	private void BinaryOperatorChecker() {
		if (calcModel.isActiveOperandSet() && calcModel.getPendingBinaryOperation() != null) {
			calcModel.setValue(calcModel.getPendingBinaryOperation().applyAsDouble(calcModel.getActiveOperand(),
					calcModel.getValue()));
			System.out.println(calcModel.isEditable());
			calcModel.clearActiveOperand();
			System.out.println(calcModel.getValue());

		}
	}

	/**
	 * Main method.
	 *
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			Calculator prozor = new Calculator();
			prozor.setVisible(true);
		});
	}

	/**
	 * This method is used to determine if new value will be set in calculator
	 * 
	 * @param calcModel
	 */
	private void checkIfNew(CalcModelImpl calcModel) {
		if (calcModel.isActiveOperandSet() == false && calcModel.getPendingBinaryOperation() != null) {
			calcModel.clear();
			calcModel.setPendingBinaryOperation(null);

		}

	}

	/**
	 * This method is used to enable entering numbers in calculator after applying
	 * some unary operation
	 * 
	 * @param calcModel
	 * @param unary
	 */
	private void checkIfUnary(CalcModelImpl calcModel, boolean unary) {
		if (unary) {
			calcModel.isEditable = true;
			calcModel.clear();
			unary = false;
		}
	}

	/**
	 * This method is used to add listeners to buttons with digit labels
	 * 
	 * @param calcModel calcModel
	 * @param button    button with digit label
	 */
	private void addListenerToDigit(CalcModelImpl calcModel, OperatorButton button) {
		String digitString = button.getButtonText();
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				checkIfNew(calcModel);
				checkIfUnary(calcModel, unary);
				unary = false;
				try {
					calcModel.insertDigit(Integer.parseInt(digitString));
				} catch (IllegalArgumentException ex) {

				}
			}
		});
	}

	/**
	 * This class is used to add listener to buttons with binary operation labels
	 * 
	 * @param calcModel calcModel
	 * @param button    button with binary operation label
	 */
	private void addListenerToOperation(CalcModelImpl calcModel, OperatorButton button) {

		String operationString = button.getButtonText();

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				BinaryOperatorChecker();
				calcModel.setActiveOperand(calcModel.getValue());
				calcModel.clear();
				calcModel.setPendingBinaryOperation(new DoubleBinaryOperator() {

					@Override
					public double applyAsDouble(double left, double right) {
						switch (operationString) {
						case "-":
							return left - right;

						case "*":
							return left * right;

						case "/":
							return left / right;

						case "x^n":
							return Math.pow(left, right);

						case "x^(1/n)":
							return Math.pow(left, 1 / right);

						default:
							return left + right;
						}
					}
				});

			}
		});
	}

	/**
	 * This method is used to add listeners to buttons with unary operations.
	 * 
	 * @param calcModel calcModel
	 * @param button    button with unary operation label
	 */
	private void addListenerToUnaryOperation(CalcModelImpl calcModel, OperatorButton button) {
		String operationString = button.getButtonText();

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				double number = calcModel.getValue();
				double result = 0;
				switch (operationString) {
				case "sin":
					result = Math.sin(number);
					break;

				case "cos":
					result = Math.cos(number);
					break;

				case "tan":
					result = Math.tan(number);
					break;

				case "ctg":
					result = 1 / Math.tan(number);
					break;

				case "1/x":
					result = 1 / number;
					break;

				case "log":
					result = Math.log10(number);
					break;

				case "ln":
					result = Math.log(number);
					break;

				case "e^x":
					result = Math.pow(Math.E, number);
					break;

				case "+/-":
					calcModel.swapSign();
					return;

				case ".":
					calcModel.insertDecimalPoint();
					return;

				case "clr":
					calcModel.clear();
					return;

				case "reset":
					calcModel.clearAll();
					return;

				case "inv":
					return;

				case "arcsin":
					result = Math.asin(number);
					break;

				case "arccos":
					result = Math.acos(number);
					break;

				case "arctan":
					result = Math.atan(number);
					break;

				case "arcctg":
					result = Math.PI / 2 - Math.atan(number);
					break;

				case "10^x":
					result = Math.pow(10, number);
					break;

				case "e":
					result = Math.pow(Math.E, number);
					break;

				}

				calcModel.setValue(result);
				unary = true;
			}

		});
	}

	/**
	 * This method is used to add listeners to buttons with stack operations - push,
	 * pop.
	 * 
	 * @param calcImpl calcImpl
	 * @param button   buttons with stack operation labels
	 * @param stack    stack to do operations on
	 */
	private void addListenerToStackOperation(CalcModelImpl calcImpl, OperatorButton button, Stack<Double> stack) {

		String operationString = button.getButtonText();

		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				switch (operationString) {

				case "push":
					stack.push(calcImpl.getValue());
					unary = true;
					return;

				case "pop":
					if (stack.isEmpty()) {
						System.out.println("Stack is empty.");
						return;
					}
					calcImpl.setValue(stack.pop());
					unary = true;
					return;

				}
			}
		});

	}

}
