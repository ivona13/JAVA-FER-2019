package hr.fer.zemris.java.gui.layouts;

/**
 * This class is used to represent CalcLayoutException.
 * 
 * @author ivona
 *
 */
public class CalcLayoutException extends RuntimeException {

	/**
	 * Default serialVersion
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Basic constructor
	 */
	public CalcLayoutException() {
	}

	/**
	 * Basic constructor
	 * 
	 * @param message Message of error
	 */
	public CalcLayoutException(String message) {
		super(message);
	}

	/**
	 * Basic constructor
	 * 
	 * @param message Message of error
	 * @param cause   Cause of error
	 */
	public CalcLayoutException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Basic constructor
	 * 
	 * @param cause Cause of error
	 */
	public CalcLayoutException(Throwable cause) {
		super(cause);
	}

}
