package hr.fer.zemris.java.gui.charts;

import java.util.List;

/**
 * This class is used to represent BarChart.
 * 
 * @author ivona
 *
 */
public class BarChart {

	/**
	 * List of XYValue
	 */
	private List<XYValue> values;

	/**
	 * Description of x axis
	 */
	private String xDescription;

	/**
	 * Description of y axis
	 */
	private String yDescription;

	/**
	 * Minimum y
	 */
	private int yMin;

	/**
	 * Maximum y
	 */
	private int yMax;

	/**
	 * Space between y values
	 */
	private int ySpace;

	public BarChart(List<XYValue> values, String xDescription, String yDescription, int yMin, int yMax, int ySpace) {
		this.values = values;
		this.xDescription = xDescription;
		this.yDescription = yDescription;
		this.yMin = yMin;
		this.yMax = yMax;
		this.ySpace = ySpace;
	}

	/**
	 * XYValue getter
	 * 
	 * @return list of XYValue
	 */
	public List<XYValue> getValues() {
		return values;
	}

	/**
	 * XDescription getter
	 * 
	 * @return yDescription
	 */
	public String getxDescription() {
		return xDescription;
	}

	/**
	 * YDescription getter
	 * 
	 * @return yDescription
	 */
	public String getyDescription() {
		return yDescription;
	}

	/**
	 * Minimum y getter
	 * 
	 * @return yMin
	 */
	public int getyMin() {
		return yMin;
	}

	/**
	 * Maximum y getter
	 * 
	 * @return yMax
	 */
	public int getyMax() {
		return yMax;
	}

	/**
	 * Y difference getter
	 * 
	 * @return ySpace
	 */
	public int getySpace() {
		return ySpace;
	}

}
