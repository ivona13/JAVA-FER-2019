package hr.fer.zemris.java.gui.charts;

/**
 * This class is used to represent xy values.
 * 
 * @author ivona
 *
 */
public class XYValue {

	/**
	 * X value
	 */
	private int x;

	/**
	 * Y value
	 */
	private int y;

	/**
	 * Constructor
	 * 
	 * @param x X value
	 * @param y Y Value
	 */
	public XYValue(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * X getter
	 * 
	 * @return X
	 */
	public int getX() {
		return x;
	}

	/**
	 * Y getter
	 * 
	 * @return Y
	 */
	public int getY() {
		return y;
	}

}
