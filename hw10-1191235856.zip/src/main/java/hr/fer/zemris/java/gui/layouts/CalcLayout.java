package hr.fer.zemris.java.gui.layouts;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * This class is used to represent calc layout. It has 7 columns and 5 rows. One
 * special thing : there is special cell on the position (1, 1) - it has width 5
 * 
 * @author ivona
 *
 */
public class CalcLayout implements LayoutManager2 {

	/**
	 * Space between cells
	 */
	private int space;

	/**
	 * Map used to store components - cells
	 */
	Map<Component, RCPosition> components = new HashMap<>();

	/**
	 * fixed number of rowd
	 */
	private static final int ROWS = 5;

	/**
	 * fixed number of colums
	 */
	private static final int COLUMNS = 7;

	/**
	 * Basic constructor
	 */
	public CalcLayout() {
		space = 0;
	}

	/**
	 * Basic constructor
	 * 
	 * @param space space
	 */
	public CalcLayout(int space) {
		this.space = space;
	}

	@Override
	public void addLayoutComponent(String name, Component comp) {
		throw new UnsupportedOperationException();
	}

	@Override
	public void removeLayoutComponent(Component comp) {
		components.remove(comp);
	}

	@Override
	public Dimension preferredLayoutSize(Container parent) {
		return calculateDimension(parent, Component::getPreferredSize);
	}

	@Override
	public Dimension minimumLayoutSize(Container parent) {
		return calculateDimension(parent, Component::getMinimumSize);
	}

	@Override
	public Dimension maximumLayoutSize(Container parent) {
		return calculateDimension(parent, Component::getMaximumSize);
	}

	/**
	 * This method is used to calculate layout size.
	 * 
	 * @param parent Parent
	 * @param size   Strategy used for determing sort of size (min, max or
	 *               preferred)
	 * @return layout size
	 */
	private Dimension calculateDimension(Container parent, Function<Component, Dimension> size) {
		Insets insets = parent.getInsets();

		int maxHeight = 0;
		int maxWidth = 0;

		for (Map.Entry<Component, RCPosition> entry : components.entrySet()) {
			Dimension dim = size.apply(entry.getKey());
			RCPosition position = entry.getValue();

			maxHeight = Math.max(maxHeight, dim.height);

			if (position.getRow() == 1 && position.getColumn() == 1) {
				maxWidth = Math.max(maxWidth, (dim.width - 4 * space) / 5);

			} else {

				maxWidth = Math.max(maxWidth, dim.width);

			}

		}

		int widthFinal = insets.left + insets.right + COLUMNS * maxWidth + (COLUMNS - 1) * space;
		int heightFinal = insets.bottom + insets.top + ROWS * maxHeight + (ROWS - 1) * space;
		// lets find width and height
		return new Dimension(widthFinal, heightFinal);
	}

	@Override
	public void layoutContainer(Container parent) {
		Insets insets = parent.getInsets();

		int elementWidth = (parent.getWidth() - insets.left - insets.right - (COLUMNS - 1) * space) / COLUMNS;

		int elementHeight = (parent.getHeight() - insets.top - insets.bottom - (ROWS - 1) * space) / ROWS;

		for (Map.Entry<Component, RCPosition> entry : components.entrySet()) {
			Component component = entry.getKey();
			RCPosition position = entry.getValue();

			int w = insets.left + (position.getColumn() - 1) * elementWidth + (position.getColumn() - 1) * space;

			int h = insets.top + (position.getRow() - 1) * elementHeight + (position.getRow() - 1) * space;

			int findWidth = elementWidth;

			if (position.getRow() == 1 && position.getColumn() == 1) {
				findWidth = elementWidth * 5 + space * 4;
			}

			component.setBounds(w, h, findWidth, elementHeight);

		}
	}

	@Override
	public void addLayoutComponent(Component comp, Object constraints) {

		RCPosition position;

		if (constraints instanceof RCPosition) {
			position = (RCPosition) constraints;
			checkValidPosition(position.getRow(), position.getColumn());

		} else if (constraints instanceof String) {
			String stringPosition = (String) constraints;
			if (stringPosition.length() != 3) {
				throw new CalcLayoutException("Invalid position!");
			}
			try {
				position = new RCPosition(Integer.parseInt(String.valueOf(stringPosition.charAt(0))),
						Integer.parseInt(String.valueOf(stringPosition.charAt(2))));

				checkValidPosition(position.getRow(), position.getColumn());

			} catch (NumberFormatException ex) {
				throw new CalcLayoutException("Invalid position!");
			}
		} else {
			throw new CalcLayoutException("Invalid constraint.");
		}

		RCPosition existing = components.get(comp);
		if (existing != null) {
			throw new CalcLayoutException("Component already exists.");
		}
		if (components.containsValue(position)) {
			throw new CalcLayoutException("Component at that position already exists.");
		}
		components.put(comp, position);
	}

	@Override
	public float getLayoutAlignmentX(Container target) {
		return (float) 0;
	}

	@Override
	public float getLayoutAlignmentY(Container target) {
		return (float) 0;
	}

	@Override
	public void invalidateLayout(Container target) {

	}

	/**
	 * This private method is used to determine if the position is valid.
	 * 
	 * @param row    Row
	 * @param column Column
	 */
	private void checkValidPosition(int row, int column) {
		if (row < 1 || row > 5 || column < 1 || column > 7) {
			throw new CalcLayoutException("Out of layout!");
		} else if (row == 1 && column > 1 && column < 6) {
			throw new CalcLayoutException("It's first component! It should have position (1,1).");
		}
	}
}
