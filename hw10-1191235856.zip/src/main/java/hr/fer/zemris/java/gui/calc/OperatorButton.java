package hr.fer.zemris.java.gui.calc;

import java.awt.Button;
import java.awt.Color;

/**
 * This class is used to represent OperatorButton on calculator.
 * 
 * @author ivona
 *
 */
public class OperatorButton extends Button {

	/**
	 * Default serialVersion
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Model of calculator
	 */
	CalcModelImpl model;

	/**
	 * Text on button
	 */
	private String buttonText;

	/**
	 * Constructor
	 * 
	 * @param model      Model
	 * @param buttonText ButtonText
	 */
	public OperatorButton(CalcModelImpl model, String buttonText) {

		this.model = model;
		this.setButtonText(buttonText);

		setBackground(Color.BLUE);
		setForeground(Color.WHITE);
		setLabel(buttonText);
	}

	/**
	 * ButtonText getter
	 * 
	 * @return buttonText
	 */
	public String getButtonText() {
		return buttonText;
	}

	/**
	 * ButtonText setter
	 * 
	 * @param buttonText buttonText
	 */
	public void setButtonText(String buttonText) {
		this.buttonText = buttonText;
	}

}
