package hr.fer.zemris.java.gui.layouts;

import java.util.Objects;

/**
 * This class is used for representing position of cell in {@link CalcLayout}
 * 
 * @author ivona
 *
 */
public class RCPosition {

	/**
	 * Number of row
	 */
	private int row;

	/**
	 * Number of column
	 */
	private int column;

	/**
	 * Constructor
	 * 
	 * @param row    Row
	 * @param colomn Column
	 */
	public RCPosition(int row, int colomn) {
		this.row = row;
		this.column = colomn;
	}

	/**
	 * Row getter
	 * 
	 * @return row
	 */
	public int getRow() {
		return row;
	}

	/**
	 * Column getter
	 * 
	 * @return column
	 */
	public int getColumn() {
		return column;
	}

	@Override
	public int hashCode() {
		return Objects.hash(column, row);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof RCPosition))
			return false;
		RCPosition other = (RCPosition) obj;
		return column == other.column && row == other.row;
	}

}
