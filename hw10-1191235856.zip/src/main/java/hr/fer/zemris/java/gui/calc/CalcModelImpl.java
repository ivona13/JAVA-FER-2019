package hr.fer.zemris.java.gui.calc;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleBinaryOperator;

import hr.fer.zemris.java.gui.calc.model.CalcModel;
import hr.fer.zemris.java.gui.calc.model.CalcValueListener;
import hr.fer.zemris.java.gui.calc.model.CalculatorInputException;

/**
 * This class is used to implement {@link CalcModel}. It is used as logic for
 * calculator.
 * 
 * @author ivona
 *
 */
public class CalcModelImpl implements CalcModel {

	/**
	 * Variable which is true if the value in calculator is editable
	 */
	boolean isEditable = true;

	/**
	 * Variable which is true if the value is positive; false otherwise
	 */
	boolean positive = true;

	/**
	 * String that represents string of number which will be displayed in calculator
	 */
	String numberString = "";

	/**
	 * Number
	 */
	double number = 0;

	/**
	 * Active operand
	 */
	double activeOperand;

	/**
	 * Variable which is true if operand is set
	 */
	boolean activeOperandSet = false;

	/**
	 * Operator that will be applied on active operand and value
	 */
	DoubleBinaryOperator pendingOperation;

	/**
	 * List of calculator listeners.
	 */
	private List<CalcValueListener> listeners = new ArrayList<CalcValueListener>();

	@Override
	public void addCalcValueListener(CalcValueListener l) {
		listeners.add(l);
	}

	@Override
	public void removeCalcValueListener(CalcValueListener l) {
		listeners.remove(l);
	}

	@Override
	public double getValue() {
		if (numberString == "") {
			return 0.0;
		}

		return (positive == true ? Double.parseDouble(numberString) : -Double.parseDouble(numberString));
	}

	/**
	 * This method is used to notify all listeners that change has happened
	 */
	private void notifyListeners() {
		for (CalcValueListener listener : listeners) {
			listener.valueChanged(this);

		}
	}

	@Override
	public void setValue(double value) {
		number = value;
		numberString = Double.toString(value);
		isEditable = false;

		notifyListeners();
	}

	@Override
	public boolean isEditable() {
		return isEditable;
	}

	@Override
	public void clear() {
		number = 0.0;
		numberString = "";
		positive = true;
		notifyListeners();

	}

	@Override
	public void clearAll() {
		numberString = "";
		number = 0;
		activeOperand = 0;
		activeOperandSet = false;
		pendingOperation = null;
		positive = true;
		notifyListeners();
	}

	@Override
	public void swapSign() throws CalculatorInputException {

		if (isEditable == false) {
			throw new CalculatorInputException();
		}
		if (positive == true) {
			positive = false;

		} else {
			positive = true;
		}
		notifyListeners();

	}

	@Override
	public void insertDecimalPoint() throws CalculatorInputException {

		if (numberString == "") {
			throw new CalculatorInputException();
		}

		if (!isEditable) {
			throw new CalculatorInputException();
		}
		if (numberString != "") {
			if (!numberString.contains(".")) {
				numberString += ".";
			} else {
				throw new CalculatorInputException();
			}
			notifyListeners();

		} else {
			if (!numberString.contains(".")) {
				numberString += "0.";
			}
		}
	}

	@Override
	public void insertDigit(int digit) throws CalculatorInputException, IllegalArgumentException {
		if (isEditable == false) {
			throw new CalculatorInputException();
		}

		if (digit == 0 && number == (double) 0) {
			if (numberString == "") {
				numberString = "0";
			} else {
				if (numberString.contains(".")) {
					numberString += "0";
				}
			}

			notifyListeners();
			return;
		}

		if (digit != 0 && number == (double) 0 && numberString == "0") {
			numberString += Integer.toString(digit);
			numberString = numberString.substring(1);
			number = Double.parseDouble(numberString);
			notifyListeners();
			return;
		}

		try {

			numberString += Integer.toString(digit);
			number = Double.parseDouble(numberString);

		} catch (CalculatorInputException ex) {
			throw new CalculatorInputException();
		}

		if (number == Double.POSITIVE_INFINITY) {
			throw new CalculatorInputException();
		}
		notifyListeners();

	}

	@Override
	public String toString() {
		String string = "";

		if (numberString == "") {
			if (positive) {
				return "0";
			}
			return "-0";
		}

		if (number == Double.POSITIVE_INFINITY) {
			return "Infinity";
		}

		if (number == Double.NEGATIVE_INFINITY) {
			return "-Infinity";
		}

		if (number == (double) 0) {
			string = numberString;
			if (positive) {
				return string;
			}
		} else {
			string = numberString;
		}
		if (positive == false) {
			string = "-" + string;
			number = -number;

		}
		return string;
	}

	@Override
	public boolean isActiveOperandSet() {
		return activeOperandSet;
	}

	@Override
	public double getActiveOperand() throws IllegalStateException {
		if (!activeOperandSet) {
			throw new IllegalStateException();
		}
		return activeOperand;
	}

	@Override
	public void setActiveOperand(double activeOperand) {
		this.activeOperand = activeOperand;
		this.activeOperandSet = true;
		this.numberString = "";
	}

	@Override
	public void clearActiveOperand() {
		positive = true;
		activeOperand = (double) 0;
		activeOperandSet = false;
		isEditable = true;
	}

	@Override
	public DoubleBinaryOperator getPendingBinaryOperation() {
		return pendingOperation;
	}

	@Override
	public void setPendingBinaryOperation(DoubleBinaryOperator op) {
		pendingOperation = op;
	}
}
