package hr.fer.zemris.java.gui.charts;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.geom.AffineTransform;
import java.util.List;

import javax.swing.JComponent;

/**
 * This class is used to represent BarChart component.
 * 
 * @author ivona
 *
 */
public class BarChartComponent extends JComponent {

	/**
	 * Default serialVersion
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Bar chart to be displayed
	 */
	private BarChart chart;

	/**
	 * Basic constructor
	 * 
	 * @param barChart barChart
	 */
	public BarChartComponent(BarChart chart) {
		this.chart = chart;
	}

	@Override
	public void paintComponent(Graphics g) {
		// Cast to graphics2D

		// Get dimension
		Dimension dim = getSize();
		Insets ins = getInsets();
		FontMetrics fm = g.getFontMetrics();
		int yNumberLength = fm.stringWidth(Integer.toString(chart.getyMax()));
		List<XYValue> values = chart.getValues();

		int space = 20;

		int dashLength = 6;

		// Calculate origin, and end of x axis and end of y axis
		int startX = ins.left + space + fm.getHeight() + space + yNumberLength + space / 2 + dashLength;
		int startY = dim.height - ins.bottom - space - fm.getHeight() - space - fm.getHeight() - space / 2 - dashLength;
		int endOfXAxis = dim.width - ins.right - space;
		int endOfYAxis = ins.top + space;

		// Calculate column and row width and number of values
		int columnWidth = (endOfXAxis - startX) / values.size();
		int countOfValues = (chart.getyMax() - chart.getyMin()) / chart.getySpace();
		if ((chart.getyMax() - chart.getyMin()) % chart.getySpace() != 0) {
			countOfValues++;
		}
		int rowWidth = (startY - endOfYAxis) / countOfValues;

		// Draw dashes on y axis, values on y axis and grid on y axis
		for (int i = chart.getyMin(); i <= chart.getyMin() + countOfValues; i++) {
			// Dashes
			((Graphics2D) g).setStroke(new BasicStroke(3));
			g.setColor(Color.GRAY);
			g.drawLine(startX - dashLength, startY - (i - chart.getyMin()) * rowWidth, startX,
					startY - (i - chart.getyMin()) * rowWidth);

			String yValue = Integer.toString(i * chart.getySpace() - chart.getyMin());
			g.setColor(Color.BLACK);
			g.drawString(yValue, startX - space / 2 - dashLength - fm.stringWidth(yValue),
					startY - (i - chart.getyMin()) * rowWidth + fm.getHeight() / 3);

			// Grid
			if (i != chart.getyMin()) {
				((Graphics2D) g).setStroke(new BasicStroke(1));
				g.setColor(Color.RED.brighter());
				g.drawLine(startX, startY - (i - chart.getyMin()) * rowWidth, endOfXAxis,
						startY - (i - chart.getyMin()) * rowWidth);
			}
		}

		// Draw dashes on x axis, values on x axis, grid on x axis, rectangles
		// representing values and their shadows
		for (int i = 0; i <= values.size(); i++) {

			// Dashes
			((Graphics2D) g).setStroke(new BasicStroke(3));
			g.setColor(Color.GRAY);
			g.drawLine(startX + i * columnWidth, startY + dashLength, startX + i * columnWidth, startY);

			// Grid
			if (i != 0) {
				((Graphics2D) g).setStroke(new BasicStroke(1));
				g.setColor(Color.RED);
				g.drawLine(startX + i * columnWidth, startY, startX + i * columnWidth, endOfYAxis);
			}

			if (i < values.size()) {
				// Values
				g.setColor(Color.BLACK);
				g.drawString(Integer.toString(values.get(i).getX()), startX + i * columnWidth + columnWidth / 2,
						startY + space / 2 + fm.getHeight() + dashLength);

				// Rectangle
				g.setColor(Color.RED);
				int yValue = values.get(i).getY() > chart.getyMax() ? chart.getyMax() : values.get(i).getY();
				g.fillRect(startX + i * columnWidth, startY - (yValue - chart.getyMin()) * rowWidth / chart.getySpace(),
						columnWidth, (yValue - chart.getyMin()) * rowWidth / chart.getySpace() - 1);

				// Separation between rectangles
				if (i > 0) {
					((Graphics2D) g).setStroke(new BasicStroke(1));
					g.setColor(Color.WHITE);
					g.drawLine(startX + i * columnWidth + 1, startY, startX + i * columnWidth + 1,
							startY - values.get(i - 1).getY() * rowWidth / chart.getySpace());
				}

				// Shadow
				g.setColor(Color.GRAY);

				g.fillRect(startX + (i + 1) * columnWidth,
						startY - (yValue - chart.getyMin()) * rowWidth / chart.getySpace(), 5,
						(yValue - chart.getyMin()) * rowWidth / chart.getySpace() - 1);

			}

		}

		// axes
		((Graphics2D) g).setStroke(new BasicStroke(3));
		g.setColor(Color.GRAY);
		g.drawLine(startX - dashLength, startY, endOfXAxis, startY);
		g.drawLine(startX, startY + dashLength, startX, endOfYAxis);

		// arrows at end of axes
		for (int i = -dashLength / 2; i <= dashLength / 2; i++) {
			g.drawLine(endOfXAxis, startY + i, endOfXAxis + dashLength + 1, startY);
			g.drawLine(startX + i, endOfYAxis, startX, endOfYAxis - dashLength - 1);
		}

		// Draw x axis description
		g.setFont(g.getFont());
		g.setColor(Color.BLACK);

		g.drawString(chart.getxDescription(), (endOfXAxis + startX) / 2 - fm.stringWidth(chart.getxDescription()) / 2,
				startY + dashLength + space / 2 + fm.getHeight() + space);

		// Draw y axis description
		AffineTransform at = AffineTransform.getQuadrantRotateInstance(3);
		((Graphics2D) g).setTransform(at);
		g.drawString(chart.getyDescription(), (endOfYAxis - startY) / 2 - fm.stringWidth(chart.getyDescription()) / 2,
				startX - dashLength - space / 2 - yNumberLength - space);

		// Reset graphics to initial state
		at = AffineTransform.getQuadrantRotateInstance(0);
		((Graphics2D) g).setTransform(at);

	}

}
