package hr.fer.zemris.java.gui.prim;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class PrimListModel implements ListModel<Long> {

	private List<Long> primes = new ArrayList<Long>();

	private List<ListDataListener> listeners = new ArrayList<ListDataListener>();

	private long current = 1;

	public PrimListModel() {
		primes.add((long) 1);
	}

	@Override
	public int getSize() {
		return primes.size();
	}

	@Override
	public Long getElementAt(int index) {
		return primes.get(index);
	}

	@Override
	public void addListDataListener(ListDataListener l) {
		listeners.add(l);
	}

	@Override
	public void removeListDataListener(ListDataListener l) {
		listeners.remove(l);
	}

	public void next() {
		for (long prime = current + 1;; prime++) {
			if (isPrime(prime)) {
				current = prime;
				primes.add(prime);
				ListDataEvent event = new ListDataEvent(this, ListDataEvent.INTERVAL_ADDED, this.getSize(),
						this.getSize());
				for (ListDataListener listener : listeners) {
					listener.intervalAdded(event);
				}

				break;
			}
		}
	}

	private boolean isPrime(long element) {
		for (int i = 2; i <= Math.sqrt(element); i++) {
			if (element % i == 0) {
				return false;
			}
		}
		return true;
	}

}
