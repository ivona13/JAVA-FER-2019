package hr.fer.zemris.java.custom.scripting.exec;

import java.util.EmptyStackException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * This class is used to represent MultiStack collection. Map allows storing
 * only one value for each key, but this collectio allows storing multiple
 * values for the same key. Keys are instances of String, and values instances
 * of ValueWrapper.
 * 
 * @author ivona
 *
 */
public class ObjectMultistack {

	/**
	 * This class is used for representing map entry for this class.
	 * 
	 * @author ivona
	 *
	 */
	private static class MultistackEntry {

		/**
		 * Value of entry
		 */
		private ValueWrapper wrapper;

		/**
		 * Next entry
		 */
		private MultistackEntry next;

		/**
		 * Basic constructor
		 * 
		 * @param wrapper Wrapper
		 * @param next    Next
		 */
		public MultistackEntry(ValueWrapper wrapper, MultistackEntry next) {
			this.wrapper = wrapper;
			this.next = next;
		}
	}

	/**
	 * This map is used for storing stack entries.
	 */
	private Map<String, MultistackEntry> multiStack = new LinkedHashMap<>();

	/**
	 * This method is used for pushing wrapper on stack with the name keyName
	 * 
	 * @param keyName      Name of stack
	 * @param valueWrapper valueWrapper
	 */
	public void push(String keyName, ValueWrapper valueWrapper) {
		Objects.requireNonNull(keyName, "Key could not be null!");
		Objects.requireNonNull(valueWrapper, "Wrapper could not be null!");

		MultistackEntry entry = multiStack.get(keyName);

		if (entry == null) {
			multiStack.put(keyName, new MultistackEntry(valueWrapper, null));
		} else {
			multiStack.remove(keyName);
			multiStack.put(keyName, new MultistackEntry(valueWrapper, entry));
		}
	}

	/**
	 * This method is used for poping entry from stack with the name keyName
	 * 
	 * @param keyName Name of stack
	 * @return ValueWrapper
	 * @throws EmptyStackException is stack is empty and there is nothing to be
	 *                             popped
	 */
	public ValueWrapper pop(String keyName) {
		MultistackEntry entry = multiStack.get(keyName);

		if (entry == null) {
			throw new EmptyStackException();
		}
		multiStack.remove(keyName);
		multiStack.put(keyName, entry.next);
		return entry.wrapper;

	}

	/**
	 * This method is used for peeking entry from the stack with the name keyName
	 * 
	 * @param keyName Name of stack
	 * @return ValueWrapper
	 * @throws EmptyStackException is stack is empty
	 */
	public ValueWrapper peek(String keyName) {
		MultistackEntry entry = multiStack.get(keyName);

		if (entry == null) {
			throw new EmptyStackException();

		}
		return entry.wrapper;

	}

	/**
	 * This method is used for determine if stack is empty
	 * 
	 * @param keyName Name of stack
	 * @return <code>true</code> if stack is empty; otherwise <code>false</code>
	 */
	public boolean isEmpty(String keyName) {
		return multiStack.get(keyName) == null;

	}

}