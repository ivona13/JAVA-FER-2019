package hr.fer.zemris.java.webserver;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.charset.UnsupportedCharsetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * This class is used to represent RequestContext. It is used for storing
 * parameters, writing stuff.
 * 
 * @author ivona
 *
 */
public class RequestContext {

	/**
	 * Output stream for writing
	 */
	private OutputStream outputStream;

	/**
	 * Encoding for converting bytes to characters.
	 */
	public String encoding = "UTF-8";

	/**
	 * Charset for converting bytes to characters.
	 */
	private Charset charset = Charset.forName(encoding);

	/**
	 * Status code of http header
	 */
	public int statusCode = 200;

	/**
	 * Status text of http header
	 */
	public String statusText = "OK";

	/**
	 * Mime type of http
	 */
	public String mimeType = "text/html";

	/**
	 * Content length
	 */
	public Long contentLength = 0L;

	/**
	 * Map used for storing parameters
	 */
	private Map<String, String> parameters = new HashMap<String, String>();

	/**
	 * Map used for storing temporary parameters
	 */
	private Map<String, String> temporaryParameters = new HashMap<String, String>();

	/**
	 * Map used for storing persistent parameters
	 */
	private Map<String, String> persistentParameters = new HashMap<String, String>();

	/**
	 * Output cookies
	 */
	private List<RCCookie> outputCookies = new ArrayList<RequestContext.RCCookie>();

	/**
	 * Flag to determine if header is generated
	 */
	private boolean headerGenerated = false;

	/**
	 * Dispatcher for dispatching request
	 */
	private IDispatcher dispatcher;

	/**
	 * Parameter getter
	 * 
	 * @param name name of the parameter
	 * @return value with the key name
	 */
	public String getParameter(String name) {
		return parameters.get(name);
	}

	/**
	 * Parameter names getter
	 * 
	 * @return set of parameter names
	 */
	public Set<String> getParameterNames() {
		return new HashSet<String>(parameters.keySet());
	}

	/**
	 * Persistent parameter getter
	 * 
	 * @param name name
	 * @return value with the key name in persistent map
	 */
	public String getPersistentParameter(String name) {
		return persistentParameters.get(name);
	}

	/**
	 * Persistent parameter names getter
	 * 
	 * @return set of persistent parameter names
	 */
	public Set<String> getPersistentParameterNames() {
		return new HashSet<String>(persistentParameters.keySet());
	}

	/**
	 * Persistent parameter setter
	 * 
	 * @param name  name
	 * @param value with the key name
	 */
	public void setPersistentParameter(String name, String value) {
		persistentParameters.put(name, value);
	}

	/**
	 * This method is used to remove persistent parameter with the given input key
	 * 
	 * @param name name
	 */
	public void removePersistentParameter(String name) {
		persistentParameters.remove(name);
	}

	/**
	 * Temporary parameter getter
	 * 
	 * @param name name
	 * @return value with the key name
	 */
	public String getTemporatyParameter(String name) {
		return temporaryParameters.get(name);
	}

	/**
	 * Temporary parameter names setter
	 * 
	 * @return set of temporary parameter names
	 */
	public Set<String> getTemporaryParameterNames() {
		return new HashSet<String>(temporaryParameters.keySet());
	}

	/**
	 * Dispatcher getter
	 * 
	 * @return dispatcher
	 */
	public IDispatcher getDispatcher() {
		return this.dispatcher;
	}

	/**
	 * Temporary parameter setter
	 * 
	 * @param name  name
	 * @param value value with the key name in temporary parameter map
	 */
	public void setTemporaryParameter(String name, String value) {
		temporaryParameters.put(name, value);
	}

	/**
	 * This method is used to remove temporary parameter with the input key
	 * 
	 * @param name name
	 */
	public void removeTemporaryParameter(String name) {
		temporaryParameters.remove(name);
	}

	/**
	 * This method is used to write data to the output stream.
	 * 
	 * @param data bytes of data
	 * @return this request context
	 * @throws IOException if writing was unsuccessful
	 */
	public RequestContext write(byte[] data) throws IOException {
		if (!headerGenerated) {
			createHeader();
		}
		outputStream.write(data);
		return this;
	}

	/**
	 * This method is used to write data to the output stream.
	 * 
	 * @param data   bytes of data
	 * @param offset offset
	 * @param len    length
	 * @return this Request context
	 * @throws IOException if writing was unsuccessful
	 */
	public RequestContext write(byte[] data, int offset, int len) throws IOException {
		if (!headerGenerated) {
			createHeader();
		}
		outputStream.write(data, offset, len);
		return this;
	}

	/**
	 * This method is used to write text to the output stream.
	 * 
	 * @param text text to be written
	 * @return this request context
	 * @throws IOException if writing was unsuccessful
	 */
	public RequestContext write(String text) throws IOException {
		byte[] data = text.getBytes(charset);

		if (!headerGenerated) {
			createHeader();
		}

		outputStream.write(data);
		return this;
	}

	/**
	 * This private method is used for creating headers if it hasn't been created
	 * yet.
	 * 
	 * @throws IOException if somethig went wrong
	 */
	private void createHeader() throws IOException {
		try {
			charset = Charset.forName(encoding);
		} catch (UnsupportedCharsetException ex) {
			throw new IOException(ex);
		}
		StringBuilder sb = new StringBuilder();
		sb.append("HTTP/1.1 ");
		sb.append(statusCode);
		sb.append(" ");
		sb.append(statusText);
		sb.append("\r\n");
		sb.append("Content-Type: ");
		sb.append(mimeType);
		if (mimeType.startsWith("text/")) {
			sb.append("; charset=");
			sb.append(encoding);
		}
		if (contentLength != 0) {
			sb.append("\r\n");
			sb.append("Content-Length: ");
			sb.append(contentLength);
		}
		sb.append("\r\n");
		for (RCCookie cookie : outputCookies) {
			sb.append("Set-Cookie: ");
			sb.append(cookie.getName());
			sb.append("=\"");
			sb.append(cookie.getValue());
			sb.append("\"");
			if (cookie.getDomain() != null) {
				sb.append("; Domain=");
				sb.append(cookie.getDomain());
			}
			if (cookie.getPath() != null) {
				sb.append("; Path=");
				sb.append(cookie.getPath());
			}
			if (cookie.getMaxAge() != null) {
				sb.append("; Max-Age=");
				sb.append(cookie.getMaxAge());
			}
			sb.append("\r\n");
		}
		sb.append("\r\n");

		outputStream.write(sb.toString().getBytes(StandardCharsets.ISO_8859_1));
		headerGenerated = true;
	}

	/**
	 * Constructor
	 * 
	 * @param outputStream         output stream
	 * @param parameters           parameters
	 * @param persistentParameters persistentParametrs
	 * @param outputCookies        outputCookies
	 */
	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies) {

		if (outputStream != null) {
			this.outputStream = outputStream;
		} else {
			throw new RuntimeException("Stream could not be null");
		}

		if (parameters != null) {
			this.parameters = parameters;
		}

		if (persistentParameters != null) {
			this.persistentParameters = persistentParameters;
		}

		if (outputCookies != null) {
			this.outputCookies = outputCookies;
		}

	}

	/**
	 * Constructor
	 * 
	 * @param outputStream         output stream
	 * @param parameters           parameters
	 * @param persistentParameters persistent parameters
	 * @param outputCookies        output cookies
	 * @param temporaryParameters  temporary parameters
	 * @param dispatcher           dispatcher
	 */
	public RequestContext(OutputStream outputStream, Map<String, String> parameters,
			Map<String, String> persistentParameters, List<RCCookie> outputCookies,
			Map<String, String> temporaryParameters, IDispatcher dispatcher) {
		if (outputStream != null) {
			this.outputStream = outputStream;
		} else {
			throw new RuntimeException("Stream could not be null");
		}

		if (parameters != null) {
			this.parameters = parameters;
		}

		if (persistentParameters != null) {
			this.persistentParameters = persistentParameters;
		}

		if (outputCookies != null) {
			this.outputCookies = outputCookies;
		}

		if (temporaryParameters != null) {
			this.temporaryParameters = temporaryParameters;
		}
		this.dispatcher = dispatcher;

	}

	/**
	 * Encoding setter
	 * 
	 * @param encoding encoding
	 */
	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	/**
	 * Statuc code setter
	 * 
	 * @param statusCode status code
	 */
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * Status text setter
	 * 
	 * @param statusText status text
	 */
	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	/**
	 * Mime type setter
	 * 
	 * @param mimeType mime type
	 */
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	/**
	 * Content length setter
	 * 
	 * @param contentLength content length
	 */
	public void setContentLength(Long contentLength) {
		if (headerGenerated) {
			throw new RuntimeException("Invalid change.");
		}
		this.contentLength = contentLength;
	}

	/**
	 * This method is used to add RCCookie to the list output cookie
	 * 
	 * @param rc rc cookie
	 */
	public void addRCCookie(RCCookie rc) {
		outputCookies.add(rc);
	}

	/**
	 * This class is used to represent RCCookie. It represents cookie for context.
	 * 
	 * @author ivona
	 *
	 */
	public static class RCCookie {

		/**
		 * Name
		 */
		private String name;

		/**
		 * Value
		 */
		private String value;

		/**
		 * Domain
		 */
		private String domain;

		/**
		 * Path
		 */
		private String path;

		/**
		 * Max age of cookie
		 */
		private Integer maxAge;

		/**
		 * Constructor
		 * 
		 * @param name   name
		 * @param value  value
		 * @param domain domain
		 * @param path   path
		 * @param maxAge maxAge
		 */
		public RCCookie(String name, String value, String domain, String path, Integer maxAge) {
			super();
			this.name = name;
			this.value = value;
			this.domain = domain;
			this.path = path;
			this.maxAge = maxAge;
		}

		/**
		 * Name getter
		 * 
		 * @return name
		 */
		public String getName() {
			return name;
		}

		/**
		 * Value getter
		 * 
		 * @return value
		 */
		public String getValue() {
			return value;
		}

		/**
		 * Domain getter
		 * 
		 * @return domain
		 */
		public String getDomain() {
			return domain;
		}

		/**
		 * Path getter
		 * 
		 * @return path
		 */
		public String getPath() {
			return path;
		}

		/**
		 * Max age getter
		 * 
		 * @return maxAge
		 */
		public Integer getMaxAge() {
			return maxAge;
		}

	}

}
