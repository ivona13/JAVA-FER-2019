package hr.fer.zemris.java.custom.scripting.nodes;

import java.util.Objects;

import hr.fer.zemris.java.custom.collections.Util;

/**
 * This class represents TextNode. It has value of type String. TextNode can't
 * have children.
 * 
 * @author Ivona
 */
public class TextNode extends Node {

	/**
	 * Text of node
	 */
	private String text;

	/**
	 * Constructor
	 * 
	 * @param text Text of node
	 * @throws NullPointerException if text is null
	 */
	public TextNode(String text) {
		this.text = Util.validateNotNull(text, "text");
	}

	/**
	 * This method returns text of node
	 * 
	 * @return text
	 */
	public String getText() {
		return text;
	}

	/**
	 * Escapes any backslashes and open curly braces located directly before a $
	 * sign.
	 */
	@Override
	public String toString() {
		return text.replaceAll("\\\\", "\\\\\\\\").replaceAll("\\{\\$", "\\\\{\\$");
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(text);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof TextNode)) {
			return false;
		}
		TextNode other = (TextNode) obj;
		return Objects.equals(text, other.text);
	}

	/**
	 * This method is used to demonstrate acceptance of {@link INodeVisitor} visitor
	 * 
	 * @param visitor {@link INodeVisitor} visitor to be accepted
	 */
	public void accept(INodeVisitor visitor) {
		visitor.visitTextNode(this);
	}
}
