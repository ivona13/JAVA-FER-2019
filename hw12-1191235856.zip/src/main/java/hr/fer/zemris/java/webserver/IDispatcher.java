package hr.fer.zemris.java.webserver;

/**
 * This interface is used to represent dispatcher. It dispatches request for
 * given path.
 * 
 * @author ivona
 *
 */
public interface IDispatcher {

	/**
	 * This method is used for dispatching request for given path.
	 * 
	 * @param path Path
	 * @throws Exception Exception if error happened
	 */
	void dispatchRequest(String path) throws Exception;
}
