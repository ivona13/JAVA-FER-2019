package hr.fer.zemris.java.custom.scripting.exec;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Stack;

import hr.fer.zemris.java.custom.scripting.elems.Element;
import hr.fer.zemris.java.custom.scripting.elems.ElementConstantDouble;
import hr.fer.zemris.java.custom.scripting.elems.ElementConstantInteger;
import hr.fer.zemris.java.custom.scripting.elems.ElementFunction;
import hr.fer.zemris.java.custom.scripting.elems.ElementOperator;
import hr.fer.zemris.java.custom.scripting.elems.ElementString;
import hr.fer.zemris.java.custom.scripting.elems.ElementVariable;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * This class is used to present the job which is to actually execute the
 * document whose parsed tree in obtains.
 * 
 * @author ivona
 *
 */
public class SmartScriptEngine {

	/**
	 * This enumeration is used to store types of parameters
	 *
	 */
	private enum ParamType {

		/**
		 * Ordinary parameter
		 */
		NORMAL,

		/**
		 * Persistent parameter
		 */
		PERSISTENT,

		/**
		 * Temporary parameter
		 */
		TEMPORARY;
	}

	/**
	 * Document node
	 */
	private DocumentNode documentNode;

	/**
	 * Request content
	 */
	private RequestContext requestContext;

	/**
	 * Multistack for storing valuewrapper
	 */
	private ObjectMultistack multistack = new ObjectMultistack();

	/**
	 * Node visitor
	 */
	private INodeVisitor visitor = new INodeVisitor() {

		@Override
		public void visitTextNode(TextNode node) {
			try {
				requestContext.write(node.getText());
			} catch (IOException e) {
			}
		}

		@Override
		public void visitDocumentNode(DocumentNode node) {
			for (int i = 0; i < node.numberOfChildren(); i++) {
				node.getChild(i).accept(this);
			}
		}

		@Override
		public void visitForLoopNode(ForLoopNode node) {
			ValueWrapper start = new ValueWrapper(node.getStartExpression().asText());
			Object end = node.getEndExpression().asText();
			Object step = node.getStepExpression().asText();
			String variable = node.getVariable().getName();

			multistack.push(variable, start);

			while (start.numCompare(end) <= 0) {
				for (int i = 0, n = node.numberOfChildren(); i < n; i++) {
					node.getChild(i).accept(this);
				}
				multistack.peek(variable).add(step);
			}
			multistack.pop(variable);
		}

		@Override
		public void visitEchoNode(EchoNode node) {
			Stack<Object> stack = new Stack<>();
			for (Element elelement : node.getElements()) {
				if (elelement instanceof ElementConstantDouble) {
					stack.push(((ElementConstantDouble) elelement).getValue());
				} else if (elelement instanceof ElementConstantInteger) {
					stack.push(((ElementConstantInteger) elelement).getValue());
				} else if (elelement instanceof ElementString) {
					stack.push(((ElementString) elelement).getValue());
				} else if (elelement instanceof ElementVariable) {
					String name = ((ElementVariable) elelement).getName();
					stack.push(multistack.peek(name).getValue());
				} else if (elelement instanceof ElementOperator) {
					evaluateOperation(stack, (ElementOperator) elelement);
				} else if (elelement instanceof ElementFunction) {
					evaluateFunction(stack, (ElementFunction) elelement);
				}
			}

			// reverse values in stack
			Stack<String> reverseStack = new Stack<>();
			while (!stack.isEmpty()) {
				reverseStack.push(stack.pop().toString());
			}

			while (!reverseStack.isEmpty()) {
				try {
					requestContext.write(reverseStack.pop());
				} catch (IOException e) {
				}
			}
		}

		/**
		 * This method is used to evaluate function stored in token.
		 * 
		 * @param stack Temporary stack of object
		 * @param el    function to evaluate
		 */
		private void evaluateFunction(Stack<Object> stack, ElementFunction el) {
			String name = el.getName();

			switch (name.toLowerCase()) {
			case "sin":
				ValueWrapper val = new ValueWrapper(stack.pop());
				Double x = Double.parseDouble(val.getValue().toString());
				stack.push(Math.sin((x * Math.PI / 180)));
				break;
			case "decfmt":
				DecimalFormat df = new DecimalFormat(stack.pop().toString());
				Object value = new ValueWrapper(stack.pop()).getValue();
				stack.push(df.format(value));
				break;
			case "dup":
				stack.push(stack.peek());
				break;
			case "swap":
				Object a = stack.pop();
				Object b = stack.pop();
				stack.push(a);
				stack.push(b);
				break;
			case "setmimetype":
				requestContext.setMimeType(stack.pop().toString());
				break;
			case "paramget":
				getParameter(ParamType.NORMAL, stack);
				break;
			case "pparamget":
				getParameter(ParamType.PERSISTENT, stack);
				break;
			case "pparamset":
				setParameter(ParamType.PERSISTENT, stack);
				break;
			case "pparamdel":
				requestContext.removePersistentParameter(stack.pop().toString());
				break;
			case "tparamget":
				getParameter(ParamType.TEMPORARY, stack);
				break;
			case "tparamset":
				setParameter(ParamType.TEMPORARY, stack);
				break;
			case "tparamdel":
				requestContext.removeTemporaryParameter(stack.pop().toString());
				break;
			default:
				break;
			}
		}

		/**
		 * This private method is used to set parameter to requestContext.
		 * 
		 * @param type  Type of parameter to be set (there are three types of them)
		 * @param stack Stack which stores values
		 */
		private void setParameter(ParamType type, Stack<Object> stack) {
			String name = stack.pop().toString();
			String value = stack.pop().toString();
			switch (type) {
			case PERSISTENT:
				requestContext.setPersistentParameter(name, value);
				break;
			case TEMPORARY:
				requestContext.setTemporaryParameter(name, value);
				break;
			default:
				break;
			}
		}

		/*
		 * This private method is used to get parameter from requestContext and push it
		 * to stack.
		 * 
		 * @param type Type of parameter to be get (there are three types of them)
		 * 
		 * @param stack Stack which stores values
		 */
		private void getParameter(ParamType type, Stack<Object> stack) {
			String defaultValue = stack.pop().toString();
			String name = stack.pop().toString();
			String value = null;
			switch (type) {
			case NORMAL:
				value = requestContext.getParameter(name);
				break;
			case PERSISTENT:
				value = requestContext.getPersistentParameter(name);
				break;
			case TEMPORARY:
				value = requestContext.getTemporatyParameter(name);
				break;
			}
			stack.push(value == null ? defaultValue : value);
		}

		/**
		 * This private method is used to evalute operation on the two last parameters
		 * of the stack.
		 * 
		 * @param stack Stack which stores values
		 * @param el    Operation
		 */
		private void evaluateOperation(Stack<Object> stack, ElementOperator el) {
			String symbol = el.getSymbol();
			Object value2 = new ValueWrapper(stack.pop()).getValue();
			ValueWrapper value1 = new ValueWrapper(stack.pop());
			switch (symbol) {
			case "+":
				value1.add(value2);
				break;
			case "-":
				value1.subtract(value2);
				break;
			case "/":
				value1.divide(value2);
				break;
			case "*":
				value1.multiply(value2);
				break;
			}
			stack.push(value1.getValue());
		}

	};

	/**
	 * Constructor of {@link SmartScriptEngine}
	 * 
	 * @param documentNode   Document to be read
	 * @param requestContext requestContext
	 */
	public SmartScriptEngine(DocumentNode documentNode, RequestContext requestContext) {
		this.documentNode = documentNode;
		this.requestContext = requestContext;

	}

	/**
	 * This method is used to execute engine.
	 */
	public void execute() {
		documentNode.accept(visitor);
	}
}