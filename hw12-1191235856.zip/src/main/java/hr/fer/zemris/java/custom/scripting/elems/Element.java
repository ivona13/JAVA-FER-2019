package hr.fer.zemris.java.custom.scripting.elems;

/**
 * This class represents Element. It is basic unit of Node.
 * 
 * @author Ivona
 *
 */
public interface Element {

	/**
	 * This method returns String representation of element.
	 * 
	 * @return String which represents element.
	 */
	public String asText();
}
