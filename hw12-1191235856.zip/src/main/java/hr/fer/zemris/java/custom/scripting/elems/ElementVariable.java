package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

/**
 * This class represents Element whose value is variable.
 * 
 * @author Ivona
 *
 */
public class ElementVariable implements Element {

	/**
	 * Name of variable
	 */
	private String name;

	/**
	 * Constructor
	 * 
	 * @param name Name of variable
	 */
	public ElementVariable(String name) {
		this.name = name;
	}

	@Override
	public String asText() {
		return name;
	}

	/**
	 * This method returns name of ElementVariable
	 * 
	 * @return name of Variable
	 */
	public String getName() {
		return name;
	}

	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ElementVariable))
			return false;
		ElementVariable other = (ElementVariable) obj;
		return Objects.equals(name, other.name);
	}
	
	
}