package hr.fer.zemris.java.custom.scripting.lexer;

import java.util.Objects;


/**
 * This class is used to represent token. Token is basic unit of parsed data in
 * {@SmartScriptLexer}. Each token has {@SmartScriptTokenType} and value;
 *
 * @author Ivona
 *
 */
public class SmartScriptToken {

	/**
	 * Type of token
	 */
	private final SmartScriptTokenType type;

	/**
	 * Value of token.
	 */
	private Object value;

	/**
	 * Basic constructor.
	 * 
	 * @param type  Type of token
	 * @param value Value of token
	 */
	public SmartScriptToken(SmartScriptTokenType type, Object value) {
		if (type == null) {
			throw new NullPointerException("Token type can't be null");
		}

		this.type = type;
		this.value = value;
	}

	/**
	 * Getter for type.
	 * 
	 * @return Type of token.
	 */
	public SmartScriptTokenType getType() {
		return type;
	}

	/**
	 * Getter for value.
	 * 
	 * @return Token value
	 */
	public Object getValue() {
		return value;
	}


	@Override
	public int hashCode() {
		return Objects.hash(type, value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof SmartScriptToken)) {
			return false;
		}
		SmartScriptToken other = (SmartScriptToken) obj;
		return type == other.type && Objects.equals(value, other.value);
	}

}
