package hr.fer.zemris.java.custom.collections;

import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * This class represents array indexed collection used for storing Objects. This
 * collection uses array for its storing.
 * 
 * @author Ivona
 *
 */
public class ArrayIndexedCollection implements List {

	/**
	 * Determines how many changes on Collection has already happened.
	 */
	private static long modificationCount;
	/**
	 * Default capacity of collection.
	 */
	public final static int DEFAULT_CAPACITY = 16;

	/**
	 * Size of collection.
	 */
	private int size;

	/**
	 * Capacity of collection.
	 */
	public int capacity;

	/**
	 * Object which stores elements of the collection.
	 */
	private Object[] elements;


	/**
	 * Default constructor which initializes collection of default capacity.
	 */
	public ArrayIndexedCollection() {
		this(DEFAULT_CAPACITY);
	}

	/**
	 * Constructor which initializes collection of given capacity.
	 * 
	 * @param initialCapacity Initial capacity
	 */
	public ArrayIndexedCollection(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException("Initial capacity has to be greater than zero.");
		}

		capacity = initialCapacity;
		elements = new Object[initialCapacity];
	}

	/**
	 * Constructor which initializes collection of default capacity and adds all
	 * elements of input collection to this collection.
	 * 
	 * @param other Collection whose elements will be added to this collection
	 */
	public ArrayIndexedCollection(Collection other) {
		this(other, other.size());
	}

	/**
	 * Constructor which initializes collection of given input capacity and adds all
	 * elements of input collection to this collection.
	 * 
	 * @param other           Collection whose elements will be added to this
	 *                        collection
	 * @param initialCapacity Initial capacity of the new collection
	 */
	public ArrayIndexedCollection(Collection other, int initialCapacity) {
		this(initialCapacity);
		this.addAll(other);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isEmpty() {
		return (size == 0);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * {@inheritDoc} Adding <code>null</code> is forbidden.
	 * <p>
	 * Adds an element in constant time (might need to reallocate).
	 * </p>
	 * 
	 * @throws NullPointerException if <code>value</code> is <code>null</code>
	 */
	@Override
	public void add(Object value) {
		if (value.equals(null)) {
			throw new NullPointerException("Null could not be added.");
		}

		if (size == capacity) {
			reallocate();
		}

		elements[size++] = value;
		modificationCount++;
	}

	/**
	 * This method reallocates the array. It doubles the capacity.
	 */
	private void reallocate() {
		elements = Arrays.copyOf(elements, capacity * 2);
		capacity *= 2;
	}

	/**
	 * This method inserts Object at given position in array. Elements on places
	 * which are >= position will be shifted one place toward the end, so an empty
	 * place will be created at position. Valid positions are 0 to size. If position
	 * is invalid, it throws {@link IllegalArgumentException}.
	 * 
	 * @param value    Object which needs to be inserted to collection
	 * @param position Position in array where Object will be inserted
	 */
	public void insert(Object value, int position) {
		if (value.equals(null)) {
			throw new IllegalArgumentException("Null is not allowed to be inserted.");
		}

		if (position < 0 || position > size) {
			throw new IndexOutOfBoundsException("Position should be between 0 and " + (size - 1));
		}

		if (size == capacity) {
			reallocate();
		}

		for (int i = size; i > position; i--) {
			elements[i] = elements[i - 1];
		}

		// ako dodajem na poziciju size, odmah skačem ovdje
		elements[position] = value;
		size++;
		modificationCount++;
	}

	/**
	 * This method returns the Object which is stored at the position index of the
	 * array. Valid indexes are 0 to size-1. If index is invalid, method throws the
	 * {@link IndexOutOfBoundsException}. Complexity: O(1).
	 * 
	 * @param index Index
	 * @return Object at given index
	 */
	public Object get(int index) {
		if (index < 0 || index >= size) {
			throw new IndexOutOfBoundsException("Indexi su izvan dopustivog raspona");
		}

		return elements[index];
	}

	/**
	 * This method goes through the array and finds index of the first appearance of
	 * the given value or -1 if the value does not exist in Collection.
	 * 
	 * 
	 * @param value Object whose index will be found
	 * @return Index of element if element exists, -1 otherwise
	 */
	public int indexOf(Object value) {
		// value moze biti null, ali kako nije nađen, izlaz -1

		if (!value.equals(null)) {
			for (int i = 0; i < size; i++) {
				if (elements[i].equals(value)) {
					return i;
				}
			}
		}

		return -1;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean contains(Object value) {
		if(value == null) {
			return false;
		}
		return indexOf(value) != -1;
	}

	/**
	 * This method is used for removing element at given index. Valid index is 0 to
	 * size-1. If index is not valid, it throws {@link IndexOutOfBoundsException}.
	 *
	 * @param index Index of element which will be removed
	 */
	public void remove(int index) {
		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index should be between 0 and " + (size - 1) + ".");
		}

		for (int i = index; i < size - 1; i++) {
			elements[i] = elements[i + 1];
		}

		elements[size - 1] = null;
		size--;
		modificationCount = 1;
	}

	/**
	 * Removes exactly one object equal to <code>value</code> from this collection,
	 * if such exists (determined by {@link Object#equals(Object)}). If there are
	 * multiple candidates for removal, the first one will be removed.
	 */
	@Override
	public boolean remove(Object value) {
		if(value == null) {
			return false;
		}
		
		int index = indexOf(value);

		if (index < 0) {
			return false;
		}

		remove(index);
		return true;
	}

	@Override
	public Object[] toArray() {
		return Arrays.copyOfRange(elements, 0, size);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clear() {
		for (int i = 0; i < elements.length; i++) {
			elements[i] = null;
		}
		size = 0;
		modificationCount++;
	}

	/**
	 * This class represents some sort of Object whose task is to enable user to get
	 * element by element of the Collection.
	 * 
	 * @author Ivona
	 *
	 */
	private static class ArrayElementsGetter implements ElementsGetter {

		/**
		 * Collection to iterate over.
		 */
		private final ArrayIndexedCollection data;

		/**
		 * Index of element to return next.
		 */
		private int currentPosition = 0;

		/**
		 * This variable stores modificationCount of the Collection at the moment of
		 * creation this ElementsGetter.
		 */
		private final long savedModificationCount;

		/**
		 * Cnstructor.
		 * 
		 * @param Collection to iterate over
		 * 
		 * @throws NullPointerException if <code>data</code> is <code>null</code>
		 */
		@SuppressWarnings("static-access")
		public ArrayElementsGetter(ArrayIndexedCollection data) {
			Util.validateNotNull(data, "data");
			this.data = data;
			this.savedModificationCount = data.modificationCount;
		}

		/**
		 * {@inheritDoc}
		 * 
		 * @throws ConcurrentModificationException {@inheritDoc}
		 */
		@SuppressWarnings("static-access")
		@Override
		public boolean hasNextElement() {
			if (savedModificationCount != data.modificationCount) {
				throw new ConcurrentModificationException("Collection was changed since this iterator was created.");
			}
			return currentPosition < data.size;
		}

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Object getNextElement() {
			if (modificationCount != savedModificationCount) {
				throw new ConcurrentModificationException("Collection has changed.");
			}
			if (!hasNextElement()) {
				throw new NoSuchElementException("All elements of this collection have been used.");
			}
			return data.elements[currentPosition++];
		}

	}

	@Override
	public String toString() {
		return "ArrayIndexedCollection [size=" + size + ", elements=" + Arrays.toString(elements) + ", size()=" + size()
				+ ", toArray()=" + Arrays.toString(toArray()) + ", isEmpty()=" + isEmpty() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.deepHashCode(toArray());
		result = prime * result + Objects.hash(size);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ArrayIndexedCollection)) {
			return false;
		}
		ArrayIndexedCollection other = (ArrayIndexedCollection) obj;
		return (size == other.size) && Arrays.deepEquals(this.toArray(), other.toArray());
	}

	/**
	 * This method creates ElementsGetter whose task is to reach elements of
	 * Collection.
	 * 
	 * @return ElementsGetter through which user will access elements of Collection
	 */
	@Override
	public ElementsGetter createElementsGetter() {
		return new ArrayElementsGetter(this);
	}

}
