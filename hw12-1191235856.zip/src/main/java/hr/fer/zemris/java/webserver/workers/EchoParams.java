package hr.fer.zemris.java.webserver.workers;

import java.io.IOException;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * This class is used to represent {@link IWebWorker} that is used for
 * displaying parameters given in request.
 * 
 * @author ivona
 *
 */
public class EchoParams implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {
		StringBuilder string = new StringBuilder();
		string.append("<!DOCTYPE html>");
		string.append("<html>");
		string.append("<head>");
		string.append("    <title>Echo Params</title>");
		string.append("</head>");
		string.append("<body>");
		string.append("<table>");
		string.append("<tr>");
		string.append("<th>Naziv parametara</th>");
		string.append("<th>Vrijednost parametara</th>");
		string.append("</tr>");
		for (String s : context.getParameterNames()) {
			string.append("<tr>");
			string.append("<td>");
			string.append(s);
			string.append("</td>");
			string.append("<td>");
			string.append(context.getParameter(s));
			string.append("</td>");
		}
		string.append("</tr>");
		string.append("</table>");

		string.append("</body>\n");
		string.append("</html>");

		try {
			context.write(string.toString());
		} catch (IOException e) {
			throw new RuntimeException("Error while writing to the page.");
		}

	}

}
