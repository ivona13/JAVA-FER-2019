package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * Thiss class is used to represent {@link IWebWorker} that is used for changing
 * backgroud color.
 * 
 * @author ivona
 *
 */
public class BgColorWorker implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {
		String bgcolor = context.getParameter("bgcolor");
		context.setMimeType("text/html");

		if (bgcolor == null) {
			context.setTemporaryParameter("message", "Color is not updated.");
			try {
				context.getDispatcher().dispatchRequest("/private/pages/color.smscr");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			context.setPersistentParameter("bgcolor", bgcolor);
			context.setTemporaryParameter("message", "Color is updated.");
			try {
				context.getDispatcher().dispatchRequest("/private/pages/color.smscr");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
