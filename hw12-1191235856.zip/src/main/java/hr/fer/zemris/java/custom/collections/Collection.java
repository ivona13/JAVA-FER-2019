package hr.fer.zemris.java.custom.collections;

/**
 * This class represents some general collection of objects.
 * 
 * @author Ivona
 *
 */

public interface Collection {

	/**
	 * This method checks if collection is empty.
	 * 
	 * @return <code>true</code> if collection is empty, otherwise
	 *         <code>false</code>
	 */
	default boolean isEmpty() {
		return (size() == 0);

	}

	/**
	 * This method returns size of collection.
	 * 
	 * @return size of collection
	 */
	int size();

	/**
	 * This method adds object to collection.
	 * 
	 * @param value Object which needs to be added to collection
	 */
	void add(Object value);

	/**
	 * This method determines if given object is in collection.
	 * 
	 * @param value Object which needs to be checked if it is in the collection
	 * @return <code>true</code> if collection contains object, <code>false</code>
	 *         otherwise
	 */
	boolean contains(Object value);

	/**
	 * This method removes given object from collection.
	 * 
	 * @param value Object to be removed
	 * @return <code>true</code> if object is removed, <code>false</code> otherwise
	 */
	boolean remove(Object value);

	/**
	 * This method converts collection to Object array.
	 * 
	 * @return Object array which represents collection
	 */
	public Object[] toArray();

	/**
	 * This method calls {@link Processor#process(Object)} for each element of
	 * collection.
	 * 
	 * @param processor {@link Processor} that will be called.
	 */

	public default void addAll(Collection other) {

		/**
		 * Local processor class with method process.
		 *
		 */
		class addProcessor implements Processor {

			/**
			 * This method adds each item into current collection by calling method add, and
			 * then call forEach on other collection with this processor as argument.
			 */
			public void process(Object value) {
				add(value);
			}
		}

		other.forEach(new addProcessor());
	}

	/**
	 * This method removes all elements from this collection.
	 */
	public void clear();

	/**
	 * This method is used to create ElementsGetter to access Collection's elements.
	 * 
	 * @return Created ElementsGetter
	 */
	ElementsGetter createElementsGetter();

	/**
	 * This method accesses all elements of input Collection col and add to this
	 * current Collection all elements that are accepted by Tester tester.
	 * 
	 * @param col    Collection whose elements are tested and added to current
	 *               Collection if they satisfy conditions determined by Tester
	 *               tester.
	 * @param tester Tester which determines if elements of Collection col are
	 *               accepted to be added to current Collection or not.
	 */
	default void addAllSatisfying(Collection col, Tester tester) {
		ElementsGetter getter = col.createElementsGetter();
		while (getter.hasNextElement()) {
			Object element = getter.getNextElement();
			if (tester.test(element)) {
				this.add(element);
			}
		}

	}

	/**
	 * This method adds all elements of input collection to this collection.
	 * 
	 * @param other Collection whose elements will be added to this collection
	 */
	default void forEach(Processor processor) {
		ElementsGetter getter = createElementsGetter();
		while (getter.hasNextElement()) {
			processor.process(getter.getNextElement());
		}
	}

}