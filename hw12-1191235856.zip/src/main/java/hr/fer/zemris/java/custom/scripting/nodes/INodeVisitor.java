package hr.fer.zemris.java.custom.scripting.nodes;

/**
 * This class is used to represent node visitor. It shows use of Visitor design
 * pattern.
 * 
 * @author ivona
 *
 */
public interface INodeVisitor {

	/**
	 * This method is used to visit Text Node
	 * 
	 * @param node node to be visited
	 */
	public void visitTextNode(TextNode node);

	/**
	 * This method is used to visit For Loop Node
	 * 
	 * @param node node to be visited
	 */
	public void visitForLoopNode(ForLoopNode node);

	/**
	 * This method is used to visit Echo node
	 * 
	 * @param node node to be visited
	 */
	public void visitEchoNode(EchoNode node);

	/**
	 * This method is used to visit Document Node
	 * 
	 * @param node node to be visited
	 */
	public void visitDocumentNode(DocumentNode node);
}
