package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

/**
 * This class represents Element whose value is operator.
 * 
 * @author Ivona
 *
 */
public class ElementOperator implements Element {

	/**
	 * Symbol of operator
	 */
	private String symbol;

	/**
	 * Constructor of ElementOperator
	 * 
	 * @param symbol Symbol of operator
	 * @throws NullPointerException if symbol is null-
	 */
	public ElementOperator(String symbol) {
		if (symbol == null) {
			throw new NullPointerException("Operator cannot be null.");
		}
		this.symbol = symbol;
	}

	@Override
	public String asText() {
		return symbol;
	}

	/**
	 * This method returns symbol as string.
	 * 
	 * @return String which represents symbol
	 */
	public String getSymbol() {
		return symbol;
	}

	@Override
	public int hashCode() {
		return Objects.hash(symbol);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof ElementOperator))
			return false;
		ElementOperator other = (ElementOperator) obj;
		return Objects.equals(symbol, other.symbol);
	}
	
	
}
