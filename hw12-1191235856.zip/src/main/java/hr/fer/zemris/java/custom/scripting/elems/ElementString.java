package hr.fer.zemris.java.custom.scripting.elems;

import java.util.Objects;

import hr.fer.zemris.java.custom.collections.Util;

/**
 * This class represents Element whose value is of type String.
 * 
 * @author Ivona
 *
 */
public class ElementString implements Element {

	/**
	 * Value of element
	 */
	String value;

	/**
	 * Constructor
	 * 
	 * @param value value of this element
	 * 
	 * @throws NullPointerException if value is <code>null</code>
	 */
	public ElementString(String value) {
		this.value = Util.validateNotNull(value, "value");
	}


	@Override
	public String asText() {
		// "\\\\" in plain text is "\\" which regex treats as if it were "\"
		// "\\\\\\\\" in plain text is "\\\\" which regex treats as if it were "\\"
		String replaced = value.replaceAll("\\\\", "\\\\\\\\").replaceAll("\"", "\\\\\"");
		return "\"" + replaced + "\"";
	}

	/**
	 * This method returns value of ElementString
	 * 
	 * @return value of ElementString
	 */
	public String getValue() {
		return value;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof ElementString)) {
			return false;
		}
		ElementString other = (ElementString) obj;
		return Objects.equals(value, other.value);
	}

}
