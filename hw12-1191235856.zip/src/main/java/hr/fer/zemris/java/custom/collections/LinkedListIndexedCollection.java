package hr.fer.zemris.java.custom.collections;

import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * This class represents linked list indexed collection. It useS linked list for
 * storing Objects.
 * 
 * @author Ivona
 */
public class LinkedListIndexedCollection implements List {

	/**
	 * Variable which determines if there was any modification of List
	 */
	private static long modificationCount;

	/**
	 * Current size of collection.
	 */
	private int size;

	/**
	 * First node of collection.
	 */
	private ListNode first;

	/**
	 * Last node of collection.
	 */
	private ListNode last;

	/**
	 * This class represents list node. It is basic element of this collection.
	 */
	public static class ListNode {

		/**
		 * Previous list node
		 */
		public ListNode previous;

		/**
		 * Next list node
		 */
		public ListNode next;

		/**
		 * Value of node
		 */
		public Object value;
	}

	/**
	 * Basic constructor.
	 */
	public LinkedListIndexedCollection() {

	}

	/**
	 * Constructor which initializes collection and adds all elements of given
	 * collection to the new collection.
	 *
	 * @param other Collection whose elements will be added
	 */
	public LinkedListIndexedCollection(Collection other) {
		this();
		addAll(other);
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public int size() {
		return size;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void add(Object value) {
		if (value == null) {
			throw new IllegalArgumentException("You cannot add " + value + " to this collection.");
		}

		ListNode novi = new ListNode();
		novi.value = value;
		if (first == null) {
			first = last = novi;
		} else {
			novi.previous = last;
			last.next = novi;
			last = last.next;
		}
		size++;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean contains(Object value) {
		return indexOf(value) != -1;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public boolean remove(Object value) {
		if (indexOf(value) == -1) {
			return false;
		}
		remove(indexOf(value));
		return true;
	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public Object[] toArray() {
		ArrayIndexedCollection array = new ArrayIndexedCollection(this);
		return array.toArray();
	}

	/**
	 * {@inheritDoc}}
	 */
	/*
	 * @Override public void forEach(Processor processor) { for (ListNode node =
	 * first; node != null; node = node.next) { processor.process(node.value); } }
	 */

	/**
	 * This method is used for getting element at given index. Valid index is 0 to
	 * size-1. If index is not valid, it throws {@link IndexOutOfBoundsException}.
	 * 
	 * @param index Index of element which needs to be got
	 * @return Element at given index
	 */
	public Object get(int index) {
		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index should be between 0 and" + (size - 1) + ".");
		}

		ListNode node = first;
		if (index < size / 2) {
			for (int i = 0; i < index; i++) {
				node = node.next;
			}
		} else {
			node = last;
			for (int i = size - 1; i > index; i--) {
				node = node.previous;
			}
		}
		return node.value;

	}

	/**
	 * {@inheritDoc}}
	 */
	@Override
	public void clear() {
		ListNode node = first;
		while (node != null) {
			ListNode next = node.next;
			node.next = node.previous = null;
			node.value = null;
			node = next;
		}
		first = first.previous = first.next = null;
		size = 0;
		modificationCount++;
	}

	/**
	 * This method inserts Object at given position in list. Elements on places
	 * which are >= position will be shifted one place toward the end, so an empty
	 * place will be created at position. Valid positions are 0 to size. If position
	 * is invalid, it throws {@link IllegalArgumentException}.
	 * 
	 * @param value    Object which needs to be inserted to collection
	 * @param position Position in list where Object will be inserted
	 */
	public void insert(Object value, int position) {

		if (position < 0 || position > size) {
			throw new IllegalArgumentException("Objekt dodajemo na mjestu u rasponu od 0 do " + size + ".");
		}

		if (position == size) {
			add(value);
			return;
		}

		ListNode newNode = new ListNode();
		newNode.value = value;
		// pozicija 0, a lista nije prazna
		if (position == 0) {
			newNode.next = first;
			first.previous = newNode;
			first = newNode;

		} else {
			ListNode node = first;
			for (int i = 0; i < position; i++) {
				node = node.next;
			}
			// u node mi se nalazi čvor na poziciji p, umetni novi ispred njega

			node.previous.next = newNode;
			newNode.previous = node.previous;
			newNode.next = node;
			node.previous = newNode;
		}
		size++;
		modificationCount++;

	}

	/**
	 * This method goes through the list and finds index of the first appearance of
	 * the given value or -1 if the value does not exist in Collection.
	 * 
	 * 
	 * @param value Object whose index will be found
	 * @return Index of element if element exists, -1 otherwise
	 */
	public int indexOf(Object value) {

		if (value.equals(null)) {
			return -1;
		}
		ListNode node = first;
		for (int i = 0; i < size; i++) {
			if (node.value.equals(value)) {
				return i;
			}
			node = node.next;

		}
		return -1;
	}

	/**
	 * This method is used for removing element at given index in list. Valid index
	 * is 0 to size-1. If index is not valid, it throws
	 * {@link IndexOutOfBoundsException}.
	 *
	 * @param index Index of element which will be removed
	 */
	public void remove(int index) {

		if (index < 0 || index > size - 1) {
			throw new IndexOutOfBoundsException("Index mora biti u rasponu od 0 do " + size + ".");
		}

		if (first == null) {
			return;
		}

		ListNode node = first;

		// brišemo početni čvor liste
		if (index == 0) {
			first = node.next;
		}

		// tražimo prethodni čvor onog kojeg želimo obrisati
		for (int i = 0; node != null && i < index - 1; i++) {
			node = node.next;
		}

		// zelimo izbrisati node.next (na node smo stali, prethodnik ovog kojeg brisemo)
		ListNode next = node.next.next;
		node.next = next;
		modificationCount++;

	}

	/**
	 * This class represents some sort of Object whose task is to enable user to get
	 * element by element of the Collection.
	 * 
	 * @author Ivona
	 *
	 */
	private static class LinkedListElementsGetter implements ElementsGetter {

		/**
		 * Collection to iterate over.
		 */
		private final LinkedListIndexedCollection data;

		/**
		 * Node whose value will be returned next.
		 */
		private ListNode currentNode;

		/**
		 * Collection's modification count at the time of creating this
		 * <code>ElementsGetter</code>.
		 */
		private final long savedModificationCount;

		/**
		 * Default constructor.
		 * 
		 * @param data collection to iterate over
		 * 
		 * @throws NullPointerException if <code>data</code> is <code>null</code>
		 */
		@SuppressWarnings("static-access")
		public LinkedListElementsGetter(LinkedListIndexedCollection data) {
			if (data == null) {
			}
			this.data = data;
			this.currentNode = data.first;
			this.savedModificationCount = data.modificationCount;
		}

		/**
		 * {@inheritDoc}
		 * 
		 * @throws ConcurrentModificationException {@inheritDoc}
		 */
		@SuppressWarnings("static-access")
		@Override
		public boolean hasNextElement() {
			if (savedModificationCount != data.modificationCount) {
				throw new ConcurrentModificationException("Collection was changed since this iterator was created.");
			}
			return currentNode != null;
		}

		/**
		 * {@inheritDoc}
		 * 
		 * @throws NoSuchElementException          {@inheritDoc}
		 * @throws ConcurrentModificationException {@inheritDoc}
		 */
		@Override
		public Object getNextElement() {
			if (!hasNextElement()) {
				throw new NoSuchElementException("All elements of this collection have been used.");
			}
			Object value = currentNode.value;
			currentNode = currentNode.next;
			return value;
		}

	}

	@Override
	public ElementsGetter createElementsGetter() {
		return new LinkedListElementsGetter(this);
	}

	@Override
	public String toString() {
		return "LinkedListIndexedCollection [size=" + size + ", first=" + first + ", last=" + last + ", size()="
				+ size() + ", toArray()=" + Arrays.toString(toArray()) + ", isEmpty()=" + isEmpty() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;

		ListNode current = first;
		while (current != null) {
			result = prime * result + Objects.hash(current.value);
			current = current.next;
		}
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof LinkedListIndexedCollection)) {
			return false;
		}
		LinkedListIndexedCollection other = (LinkedListIndexedCollection) obj;
		return (size == other.size) && Arrays.deepEquals(this.toArray(), other.toArray());
	}

}
