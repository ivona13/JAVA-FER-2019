package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * This class is used to represent {@link IWebWorker} that displays home page.
 * 
 * @author ivona
 *
 */
public class Home implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {
		String background = context.getPersistentParameter("bgcolor");
		if (background == null) {
			background = "7F7F7F";
		}

		context.setTemporaryParameter("background", background);
		try {
			context.getDispatcher().dispatchRequest("/private/pages/home.smscr");
		} catch (Exception e) {

		}

	}

}
