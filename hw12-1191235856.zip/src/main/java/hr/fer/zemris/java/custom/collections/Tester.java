package hr.fer.zemris.java.custom.collections;

/**
 * This interface models Objects which receive other Object and determine if
 * that Object is accepted or not.
 * 
 * @author Ivona
 *
 */
public interface Tester {

	/**
	 * This method determines if Object obj is accepted or not.
	 * 
	 * @param obj Object being test
	 * @return <code>true</code> if Object is accepted; otherwise <code>false</code>
	 */
	boolean test(Object obj);

}