package hr.fer.zemris.java.custom.scripting.demo;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

import hr.fer.zemris.java.custom.scripting.elems.Element;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexerException;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.INodeVisitor;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;
import hr.fer.zemris.java.custom.scripting.parser.SmartScriptParser;

public class TreeWriter {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.out.println("Invalid number of arguments.");
			return;
		}

		String documentBody = null;

		try {
			documentBody = new String(Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8);
		} catch (IOException e) {
			System.out.println("Invalid path.");
			return;
		}

		SmartScriptParser parser = null;
		try {
			parser = new SmartScriptParser(documentBody);
		} catch (SmartScriptLexerException e) {
			System.out.println("Invalid parsing of document.");
			return;
		}

		DocumentNode document = parser.getDocumentNode();
		WriteVisitor writeVisitor = new WriteVisitor();
		document.accept(writeVisitor);

	}

	private static class WriteVisitor implements INodeVisitor {

		 /**
         * StringBuilder for constructing .smscr file.
         */
        StringBuilder sb = new StringBuilder();

        @Override
        public void visitTextNode(TextNode node) {
            sb.append(node.getText());
        }

        @Override
        public void visitForLoopNode(ForLoopNode node) {
            sb.append("{$ FOR ");
            sb.append(node.getVariable().asText());
            sb.append(" ");
            sb.append(node.getStartExpression().asText());
            sb.append(" ");
            sb.append(node.getEndExpression().asText());
            sb.append(" ");
            if (node.getStepExpression() != null) {
                sb.append(node.getStepExpression().asText());
                sb.append(" ");
            }
            sb.append("$}");

            for (int i = 0; i < node.numberOfChildren(); i++) {
                node.getChild(i).accept(this);
            }

            sb.append("{$ END $}");

        }

        @Override
        public void visitEchoNode(EchoNode node) {

            sb.append("{$= ");

            Element[] echoNodeElements = node.getElements();

            for (Element echoNodeElement : echoNodeElements) {
                sb.append(echoNodeElement.asText());
                sb.append(" ");
            }

            sb.append("$}");
        }

        @Override
        public void visitDocumentNode(DocumentNode node) {
            for (int i = 0; i < node.numberOfChildren(); i++) {
                node.getChild(i).accept(this);
            }
            System.out.println(sb.toString());
        }
    }

}
