package hr.fer.zemris.java.custom.scripting.parser;

import java.util.Arrays;

import hr.fer.zemris.java.custom.collections.LinkedListIndexedCollection;
import hr.fer.zemris.java.custom.collections.List;
import hr.fer.zemris.java.custom.collections.ObjectStack;
import hr.fer.zemris.java.custom.collections.Util;
import hr.fer.zemris.java.custom.scripting.elems.Element;
import hr.fer.zemris.java.custom.scripting.elems.ElementConstantDouble;
import hr.fer.zemris.java.custom.scripting.elems.ElementConstantInteger;
import hr.fer.zemris.java.custom.scripting.elems.ElementFunction;
import hr.fer.zemris.java.custom.scripting.elems.ElementOperator;
import hr.fer.zemris.java.custom.scripting.elems.ElementString;
import hr.fer.zemris.java.custom.scripting.elems.ElementVariable;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexer;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexerException;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptLexerState;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptToken;
import hr.fer.zemris.java.custom.scripting.lexer.SmartScriptTokenType;
import hr.fer.zemris.java.custom.scripting.nodes.DocumentNode;
import hr.fer.zemris.java.custom.scripting.nodes.EchoNode;
import hr.fer.zemris.java.custom.scripting.nodes.ForLoopNode;
import hr.fer.zemris.java.custom.scripting.nodes.Node;
import hr.fer.zemris.java.custom.scripting.nodes.TextNode;

/**
 * This class represents SmartScriptParser. It is used for parsing SmartScript
 * texts.
 * 
 * @author Ivona
 *
 */
public class SmartScriptParser {

	/**
	 * A top level document to add children to
	 */
	private DocumentNode documentNode = null;

	/**
	 * A lexer to tokenize the data
	 */
	private SmartScriptLexer lexer;

	/**
	 * Helper Stack
	 */
	private ObjectStack stack;

	/**
	 *
	 * A constructor that will take in the data string and start parsing it.
	 * 
	 * @param string String to parse
	 * @throws NullPointerException if string is null
	 * 
	 */
	public SmartScriptParser(String string) {
		Util.validateNotNull(string, "string");
		lexer = new SmartScriptLexer(string);

		documentNode = parseDocumentClean();
	}

	/**
	 * A getter to get top level tree node of a parsed input
	 * 
	 * @return DocumentNode
	 */
	public DocumentNode getDocumentNode() {
		return documentNode;
	}

	/**
	 * Recreates source code from which document was parsed.
	 * 
	 * @param document root tree
	 * @return source code corresponding to document
	 * 
	 * @throws NullPointerException if <code>document</code> is <code>null</code>
	 */
	public static String createOriginalDocumentBody(DocumentNode document) {
		Util.validateNotNull(document, "document");
		return document.toString();
	}

	/**
	 * Parses entire document and creates a document tree. Guaranteed to throw only
	 * <code>SmartScriptLexerException</code> if document cannot be parsed.
	 * 
	 * @return document node of parsed document tree
	 * 
	 * @throws SmartScriptParserException if input cannot be correctly parsed for
	 *                                    any reason
	 */
	private DocumentNode parseDocumentClean() {
		try {
			return parseDocument();
		} catch (SmartScriptLexerException lexerEx) {
			throw new SmartScriptParserException(lexerEx.getMessage(), lexerEx);
		}
	}

	/**
	 * Starting parsing document
	 * 
	 * @return document node of parsed document tree
	 * 
	 * @throws SmartScriptParserException if input cannot be correctly parsed
	 */
	private DocumentNode parseDocument() {
		stack = new ObjectStack();
		stack.push(new DocumentNode());

		parseText();

		if (stack.size() != 1) {
			throw new SmartScriptParserException("Missing {$END$} tags.");
		}
		return (DocumentNode) stack.pop();
	}

	/**
	 * Parses text outside of tags.
	 * 
	 * @throws SmartScriptParserException if input cannot be parsed
	 */
	private void parseText() {
		SmartScriptToken token = lexer.nextToken();
		switch (token.getType()) {
		case EOF:
			return;
		case PLAIN_TEXT:
			TextNode textNode = new TextNode((String) token.getValue());
			addNodeToChildrenOfLast(textNode);
			parseText();
			return;
		case OPEN_TAG:
			lexer.setState(SmartScriptLexerState.TAG_NAME);
			parseEntireTag();
			return;
		default:
			throw new SmartScriptParserException("Invalid TokenType");
		}
	}

	/**
	 * Parses entire tag. Adds created node to children of last node on stack.
	 * 
	 * @throws SmartScriptParserException if tag name is incorrect, or tag body is
	 *                                    not correctly formatted matching non-empty
	 *                                    tag
	 */
	private void parseEntireTag() {
		SmartScriptToken token = lexer.nextToken();

		if (token.getType() == SmartScriptTokenType.EOF) {
			throw new SmartScriptParserException("Tag name not given.");
		} else if (token.getType() != SmartScriptTokenType.TAG_NAME) {
			throw new SmartScriptParserException("Invalid token type");
		}

		lexer.setState(SmartScriptLexerState.TAG_BODY);

		String tagName = (String) token.getValue();
		switch (tagName.toUpperCase()) {
		case "=":
			EchoNode echoNode = completeEqualsTagBody();
			addNodeToChildrenOfLast(echoNode);
			break;
		case "FOR":
			ForLoopNode forLoopNode = completeForTagBody();
			addNodeToChildrenOfLast(forLoopNode);
			stack.push(forLoopNode);
			break;
		case "END":
			SmartScriptToken closeTag = lexer.nextToken();
			if (closeTag.getType() != SmartScriptTokenType.CLOSE_TAG) {
				throw new SmartScriptParserException("END tag not valid");
			}
			stack.pop();
			if (stack.size() == 0) {
				throw new SmartScriptParserException("Much more {$END$} tags.");
			}
			break;
		default:
			throw new SmartScriptParserException("Invalid tag name.");
		}

		lexer.setState(SmartScriptLexerState.TEXT);
		parseText();
	}

	/**
	 * Helper method for adding a node to children of the node that is currently on
	 * top of stack.
	 * 
	 * @param node node to add to children
	 * 
	 * @throws NullPointerException node equals null
	 */
	private void addNodeToChildrenOfLast(Node node) {
		Util.validateNotNull(node, "node");
		Node nodeOnStack = (Node) stack.peek();
		nodeOnStack.addChildNode(node);
	}

	/**
	 * Checks if operator is valid. ( + / * - ^)
	 * 
	 * @param operatorToken token of type {@link SmartScriptTokenType#OPERATOR}
	 * @return constructed <code>ElementOperator</code>
	 * 
	 * @throws NullPointerException     operator is null
	 * @throws IllegalArgumentException if the operator token is not of valid typ
	 */
	private ElementOperator validateOperator(SmartScriptToken operatorToken) {
		Util.validateNotNull(operatorToken, "operatorToken");
		if (operatorToken.getType() != SmartScriptTokenType.OPERATOR) {
			throw new IllegalArgumentException("Token type must be 'OPERATOR'.");
		}
		String operator = (String) operatorToken.getValue();

		if (operator.length() == 1 && "+-*/^".contains(operator)) {
			return new ElementOperator(operator);
		} else {
			throw new SmartScriptParserException("Invalid operator: " + operator);
		}
	}

	/**
	 * This method constructs Echo NOde
	 * 
	 * @return created EchoNode
	 * 
	 * @throws SmartScriptParserException if tag body is not correctly formatted
	 */
	private EchoNode completeEqualsTagBody() {

		List elementsList = new LinkedListIndexedCollection();

		loop: while (true) {
			SmartScriptToken token = lexer.nextToken();
			switch (token.getType()) {
			case EOF:
				throw new SmartScriptParserException("=-tag is not closefd.");
			case VARIABLE:
				elementsList.add(new ElementVariable((String) token.getValue()));
				break;
			case FUNCTION:
				elementsList.add(new ElementFunction((String) token.getValue()));
				break;
			case STRING:
				elementsList.add(new ElementString((String) token.getValue()));
				break;
			case DOUBLE:
				elementsList.add(new ElementConstantDouble((double) token.getValue()));
				break;
			case INTEGER:
				elementsList.add(new ElementConstantInteger((int) token.getValue()));
				break;
			case OPERATOR:
				elementsList.add(validateOperator(token));
				break;
			case CLOSE_TAG:
				break loop;
			default:
				throw new SmartScriptParserException("Illegal token type: " + token.getType());
			}
		}

		int size = elementsList.size();
		if (size == 0) {
			throw new SmartScriptParserException("=-tag has empty body.");
		}

		Element[] elements = Arrays.copyOf(elementsList.toArray(), size, Element[].class);
		return new EchoNode(elements);
	}

	/**
	 * This method constructs For Loop Node from For tag.
	 * 
	 * @return ForLoopNode
	 * 
	 * @throws SmartScriptParserException if tag body is not correctly formatted
	 * 
	 */
	private ForLoopNode completeForTagBody() {
		ElementVariable firstElement = constructForTagBodyVariable(lexer.nextToken());
		Element secondElement = constructForTagBodyExpression(lexer.nextToken(), "Second");
		Element thirdElement = constructForTagBodyExpression(lexer.nextToken(), "Third");

		SmartScriptToken fourthToken = lexer.nextToken();
		if (fourthToken.getType() == SmartScriptTokenType.CLOSE_TAG) {
			return new ForLoopNode(firstElement, secondElement, thirdElement);
		}

		Element fourthElement = constructForTagBodyExpression(fourthToken, "Fourth");

		SmartScriptToken closeTag = lexer.nextToken();
		if (closeTag.getType() != SmartScriptTokenType.CLOSE_TAG) {
			throw new SmartScriptParserException("For tag must be closed.");
		}
		return new ForLoopNode(firstElement, secondElement, thirdElement, fourthElement);
	}

	/**
	 * Constructs ElementVariable from input token.
	 * 
	 * @param token token from which return value is created
	 * @return ElementVariable
	 * 
	 * @throws NullPointerException       if token equals null
	 * @throws SmartScriptParserException if token is not of appropriate type
	 */
	private ElementVariable constructForTagBodyVariable(SmartScriptToken token) {
		Util.validateNotNull(token, "token");

		switch (token.getType()) {
		case EOF:
			throw new SmartScriptParserException("FOR-tag was never closed.");
		case VARIABLE:
			return new ElementVariable((String) token.getValue());
		default:
			throw new SmartScriptParserException("First argument of FOR-tag must be a variable.");
		}
	}

	/**
	 * Constructs an Element from given token
	 * 
	 * @param token   token from which return value is created
	 * @param ordinal ordinal number of FOR-tag argument, used in custom exception
	 *                message
	 * @return created element
	 * 
	 * @throws NullPointerException       if any of arguments equals null
	 * @throws SmartScriptParserException if token was not of appropriate type
	 */
	private Element constructForTagBodyExpression(SmartScriptToken token, String ordinal) {
		Util.validateNotNull(token, "token");
		Util.validateNotNull(ordinal, "ordinal");

		switch (token.getType()) {
		case EOF:
			throw new SmartScriptParserException("FOR-tag was never closed.");
		case VARIABLE:
			return new ElementVariable((String) token.getValue());
		case STRING:
			return new ElementString((String) token.getValue());
		case INTEGER:
			return new ElementConstantInteger((int) token.getValue());
		case DOUBLE:
			return new ElementConstantDouble((double) token.getValue());
		default:
			throw new SmartScriptParserException(
					ordinal + " argument of FOR-tag must be a variable, string, integer or double.");
		}
	}

}
