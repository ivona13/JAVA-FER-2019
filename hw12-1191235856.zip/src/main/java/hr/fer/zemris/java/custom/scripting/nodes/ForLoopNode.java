package hr.fer.zemris.java.custom.scripting.nodes;

import java.util.Objects;

import hr.fer.zemris.java.custom.collections.Util;
import hr.fer.zemris.java.custom.scripting.elems.Element;
import hr.fer.zemris.java.custom.scripting.elems.ElementVariable;

/**
 * This class is used to store elements of for loops.
 * 
 * @author Ivona
 *
 */
public class ForLoopNode extends Node {

	/**
	 * Used for keeping variable of the loop.
	 */
	private ElementVariable variable;

	/**
	 * Used for keeping start expression of the for loop.
	 */
	private Element startExpression;

	/**
	 * Used for keeping end expression of the for loop.
	 */
	private Element endExpression;

	/**
	 * Used for keeping step expressiopn of the for loop.
	 */
	private Element stepExpression;

	/**
	 * Constructor of ForLoopNode
	 * 
	 * @param variable        Variable
	 * @param startExpression Start expression
	 * @param endExpression   End expression
	 * @param stepExpression  Step expression
	 * 
	 * @throws NullPointerException if any expression is null.
	 */
	public ForLoopNode(ElementVariable variable, Element startExpression, Element endExpression,
			Element stepExpression) {
		this.variable = Util.validateNotNull(variable, "variable");
		this.startExpression = Util.validateNotNull(startExpression, "startExpression");
		this.endExpression = Util.validateNotNull(endExpression, "endExpression");
		this.stepExpression = stepExpression;
	}

	/**
	 * Constructor of ForLoopNode
	 * 
	 * @param variable        Variable
	 * @param startExpression Start expression
	 * @param endExpression   End expression
	 * 
	 * @throws NullPointerException if any expression is null.
	 */
	public ForLoopNode(ElementVariable variable, Element startExpression, Element endExpression) {
		this(variable, startExpression, endExpression, null);
	}

	/**
	 * This method returns variable of node.
	 * 
	 * @return variable ElementVariable
	 */
	public ElementVariable getVariable() {
		return variable;
	}

	/**
	 * This method returns start expression of node.
	 * 
	 * @return startExpression Element
	 */
	public Element getStartExpression() {
		return startExpression;
	}

	/**
	 * This method returns end expression of node.
	 * 
	 * @return endExpression Element
	 */
	public Element getEndExpression() {
		return endExpression;
	}

	/**
	 * This method returns step expression of node.
	 * 
	 * @return stepExpression Element
	 */
	public Element getStepExpression() {
		return stepExpression;
	}

	@Override
	public String toString() {
		String forTag = String.format("{$ FOR %s %s %s %s$}", variable.asText(), startExpression.asText(),
				endExpression.asText(), stepExpression != null ? stepExpression.asText() + " " : "");
		String endTag = "{$END$}";

		StringBuilder children = new StringBuilder();
		for (int i = 0, size = numberOfChildren(); i < size; i++) {
			Node child = getChild(i);
			children.append(child.toString());
		}

		return forTag + children.toString() + endTag;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(endExpression, startExpression, stepExpression, variable);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!super.equals(obj)) {
			return false;
		}
		if (!(obj instanceof ForLoopNode)) {
			return false;
		}
		ForLoopNode other = (ForLoopNode) obj;
		return Objects.equals(endExpression, other.endExpression)
				&& Objects.equals(startExpression, other.startExpression)
				&& Objects.equals(stepExpression, other.stepExpression) && Objects.equals(variable, other.variable);
	}

	/**
	 * This method is used to demonstrate acceptance of {@link INodeVisitor} visitor
	 * 
	 * @param visitor {@link INodeVisitor} visitor
	 */
	public void accept(INodeVisitor visitor) {
		visitor.visitForLoopNode(this);
	}

}
