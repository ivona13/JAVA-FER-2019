package hr.fer.zemris.java.custom.scripting.lexer;

/**
 * This class represents enum for different types of Token.
 * 
 * @author Ivona
 * 
 */
public enum SmartScriptTokenType {

	/**
	 * No more tokens
	 */
	EOF,

	/**
	 * Text token
	 */
	PLAIN_TEXT,

	/**
	 * Open tag token
	 */
	OPEN_TAG,

	/**
	 * Closing type token
	 */
	CLOSE_TAG,

	/**
	 * Name of tag
	 */
	TAG_NAME,

	/**
	 * Variable tag token
	 */
	VARIABLE,

	/**
	 * Function tag token
	 */
	FUNCTION,

	/**
	 * String type token.
	 */
	STRING,

	/**
	 * Number type token - integer
	 */
	INTEGER,

	/**
	 * Number type token - double
	 */
	DOUBLE,

	/**
	 * Operator type of token
	 */
	OPERATOR

}
