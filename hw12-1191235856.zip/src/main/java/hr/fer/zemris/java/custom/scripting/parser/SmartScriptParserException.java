package hr.fer.zemris.java.custom.scripting.parser;

/**
 * This class represents Lexer exception
 * 
 * @author Ivona
 *
 */
public class SmartScriptParserException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Basic constructor
	 */
	public SmartScriptParserException() {
		super();
	}


	/**
	 * Constructor with  message
	 * 
	 * @param message Message
	 */
	public SmartScriptParserException(String message) {
		super(message);
	}

	
	/**
	 * A constructor that takes in a message and a throwable to forward
	 * 
	 * @param message   A message
	 * @param throwable A throwable
	 */
	public SmartScriptParserException(String message, Throwable throwable) {
		super(message, throwable);
	}

}