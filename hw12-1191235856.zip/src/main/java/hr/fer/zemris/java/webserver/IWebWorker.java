package hr.fer.zemris.java.webserver;

/**
 * This class is used to represent {@link IWebWorker}. It is used for processing
 * request with given context.
 * 
 * @author ivona
 *
 */
public interface IWebWorker {

	/**
	 * This method processes request with given context.
	 * 
	 * @param context Request context
	 */
	void processRequest(RequestContext context);

}
