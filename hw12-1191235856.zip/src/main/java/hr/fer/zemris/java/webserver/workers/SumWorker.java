package hr.fer.zemris.java.webserver.workers;

import hr.fer.zemris.java.webserver.IWebWorker;
import hr.fer.zemris.java.webserver.RequestContext;

/**
 * This class is used to represent {@link IWebWorker} that calculates the sum of
 * two given numbers. Default values of numbers are: a = 1 and b = 2 (if they
 * are not given in request).
 * 
 * @author ivona
 *
 */
public class SumWorker implements IWebWorker {

	@Override
	public void processRequest(RequestContext context) {
		int a = 1;
		int b = 2;

		try {

			a = Integer.parseInt(context.getParameter("a"));

		} catch (NumberFormatException e) {

		}

		try {

			b = Integer.parseInt(context.getParameter("b"));

		} catch (NumberFormatException e) {
		}

		int sum = a + b;
		String sumString = String.valueOf(sum);
		context.setMimeType("text/html");
		context.setTemporaryParameter("zbroj", sumString);

		if (sum % 2 == 0) {
			context.setTemporaryParameter("imgName", "/images/math.jpg");
		} else if (sum % 2 == 1) {
			context.setTemporaryParameter("imgName", "/images/math2.jpg");

		}

		try {
			context.getDispatcher().dispatchRequest("/private/pages/calc.smscr");
		} catch (Exception e) {

		}
	}

}
