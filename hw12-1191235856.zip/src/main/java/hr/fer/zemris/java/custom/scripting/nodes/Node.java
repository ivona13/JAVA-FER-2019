package hr.fer.zemris.java.custom.scripting.nodes;

import java.util.Objects;

import hr.fer.zemris.java.custom.collections.ArrayIndexedCollection;

/**
 * This class represents node which is basic unit of syntax three. That three is
 * generated when text is parsed by Parser.
 * 
 * @author Ivona
 */
public class Node {

	/**
	 * Used for keeping children of Node.
	 */
	private ArrayIndexedCollection children = null;

	/**
	 * This method is used for adding child to current Node.
	 * 
	 * @param child Node that has to be added as child to Node
	 * @throws NullPointerException if child is null
	 */
	public void addChildNode(Node child) {
		if (child == null) {
			throw new NullPointerException("Input cannot be null.");
		}

		if (children == null) {
			children = new ArrayIndexedCollection();
		}

		children.add(child);
	}

	/**
	 * This method returns number of children of current node
	 * 
	 * @return number of children
	 */
	public int numberOfChildren() {
		if (children == null) {
			return 0;
		}

		return children.size();
	}

	/**
	 * This method returns child of node at position index.
	 * 
	 * @param index Position in array
	 * @return node on position index
	 * @throws IndexOutOfBoundsException if there is no children or if index is out
	 *                                   of bounds.
	 */
	public Node getChild(int index) {
		if (children == null) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		if (index < 0 || index >= this.numberOfChildren()) {
			throw new IndexOutOfBoundsException("Invalid index.");
		}

		return (Node) children.get(index);
	}

	@Override
	public int hashCode() {
		return Objects.hash(children);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (!(obj instanceof Node)) {
			return false;
		}
		Node other = (Node) obj;
		return Objects.equals(children, other.children);
	}

	/**
	 * This method is used to demonstrate acceptance of {@link INodeVisitor} visitor
	 * 
	 * @param visitor {@link INodeVisitor} visitor to be accepted
	 */
	public void accept(INodeVisitor visitor) {

	}
}
