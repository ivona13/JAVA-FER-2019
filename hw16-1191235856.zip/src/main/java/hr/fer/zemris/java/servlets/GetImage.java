package hr.fer.zemris.java.servlets;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This servlet is used to get image whose name is given through parameter in
 * url.
 * 
 * @author ivona
 *
 */
@WebServlet(name = "GetImage", urlPatterns = { "/getImage" })
public class GetImage extends HttpServlet {

	/**
	 * serial Version UIDF
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String picture = req.getParameter("picture");
		resp.setContentType("image/jpg");

		ServletContext sc = getServletContext();
		InputStream is = sc.getResourceAsStream("/WEB-INF/slike/" + picture);

		BufferedImage bi = ImageIO.read(is);
		OutputStream os = resp.getOutputStream();
		ImageIO.write(bi, "jpg", os);
	}
}