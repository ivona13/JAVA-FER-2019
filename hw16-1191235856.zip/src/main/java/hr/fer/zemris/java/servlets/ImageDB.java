package hr.fer.zemris.java.servlets;

import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * This class is used to represent all queries we are interested in while
 * impelementig gallery. This methods are used through servlets related to usage
 * of ajax. It is something like Image database
 * 
 * @author ivona
 *
 */
public class ImageDB {

	/**
	 * This method is used to list all images of gallery
	 * 
	 * @return list of images of gallery.
	 * @throws IOException IOException
	 */
	public static List<Image> listAllImages() throws IOException {

		List<Image> images = new ArrayList<Image>();

		try {
			
			List<String> lines = Files.readAllLines(Paths.get("src/main/webapp/WEB-INF/opisnik.txt"),
					StandardCharsets.UTF_8);

			for (int i = 0; i < lines.size(); i += 3) {
				String name = lines.get(i);
				String description = lines.get(i + 1);
				String tagsString = lines.get(i + 2);

				String[] tags = tagsString.split(",");
				List<String> tagList = new ArrayList<String>();
				for (int j = 0; j < tags.length; j++)
					tagList.add(tags[j].trim());

				images.add(new Image(name, description, tagList));

			}
			return images;

		} catch (IOException e) {
			throw new IOException("File not found.");
		}

	}

	/**
	 * This method is used to list all images related to some specific tag. All this
	 * images have some tag in common.
	 * 
	 * @param tag tag
	 * @return list of images with input tag
	 * @throws IOException Ioexception
	 */
	public static List<Image> listImagesWithTag(String tag) throws IOException {

		List<Image> imagesWithTag = new ArrayList<Image>();

		List<Image> allImages = listAllImages();

		for (Image img : allImages) {
			List<String> tags = img.getTags();
			if (tags.contains(tag)) {
				imagesWithTag.add(img);
			}
		}

		return imagesWithTag;

	}

	/**
	 * This method is used to return tags written in text file "opisnik.txt".
	 * 
	 * @return set of tags
	 * @throws IOException IOException if error occures
	 */
	public static Set<String> setOfTags() throws IOException {

		Set<String> tagSet = new HashSet<String>();

		List<Image> images = listAllImages();

		for (Image img : images) {
			tagSet.addAll(img.getTags());
		}

		return tagSet;
	}

	/**
	 * This method is used to return number of tags.
	 * 
	 * @return number of tags
	 * @throws IOException IOException if error occures
	 */
	public static int numberOfTags() throws IOException {
		return setOfTags().size();
	}

	/**
	 * This method is used to get image by its name - it is considered that all
	 * images have unique name.
	 * 
	 * @param name name of image
	 * @return Image with specific name
	 * @throws IOException IOException if error occures
	 */
	public static Image getImageByName(String name) throws IOException {
		List<Image> allImages = listAllImages();

		for (Image img : allImages) {
			if (img.getName().equals(name)) {
				return img;
			}
		}

		return null;

	}

}
