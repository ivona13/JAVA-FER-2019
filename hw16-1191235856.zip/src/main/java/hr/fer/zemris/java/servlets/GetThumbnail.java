package hr.fer.zemris.java.servlets;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.imageio.ImageIO;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.coobird.thumbnailator.Thumbnails;

/**
 * This servlet is used to get thumbnail of some picture. Thumbnail is generated
 * only if it does not exist in folder WEB-INF/thumbnails. If it already exist,
 * it is only returned.
 * 
 * @author ivona
 *
 */
@WebServlet("/getThumbnail")
public class GetThumbnail extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String picture = req.getParameter("picture");
		resp.setContentType("image/jpg");

		InputStream is;
		BufferedImage bi;

		ServletContext sc = getServletContext();

		OutputStream os = resp.getOutputStream();

		String thumbnailsFile = sc.getRealPath("/WEB-INF/thumbnails");

		Path path = Paths.get(thumbnailsFile + "/" + picture);

		// if file does not exist - lets generate thumbnail
		if (!Files.exists(path)) {

			is = sc.getResourceAsStream("/WEB-INF/slike/" + picture);
			bi = ImageIO.read(is);

			File pathOut = new File(thumbnailsFile + "/" + picture);

			BufferedImage thumbnail = Thumbnails.of(bi).size(150, 150).outputFormat("jpg").asBufferedImage();

			ImageIO.write(thumbnail, "jpg", pathOut);

		}

		// otherwise, it is already in appropriate folder - lets return it
		is = sc.getResourceAsStream("/WEB-INF/thumbnails/" + picture);
		bi = ImageIO.read(is);
		ImageIO.write(bi, "jpg", os);

	}

}
