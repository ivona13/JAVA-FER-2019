package hr.fer.zemris.java.servlets;

/**
 * This servlet is used to give information about pressed picture.
 * When some picture has click on itself, this servlet returns name, description and list of tags related to this image.
 * Name of image is given as parameter in url.F
 */
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

@WebServlet(urlPatterns = { "/info" })
public class InfoServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String imgName = req.getParameter("img");
		Image image = ImageDB.getImageByName(imgName);

		resp.setContentType("application/json;charset=UTF-8");

		Gson gson = new Gson();
		String jsonText = gson.toJson(image);

		resp.getWriter().write(jsonText);

		resp.getWriter().flush();

	}
}
