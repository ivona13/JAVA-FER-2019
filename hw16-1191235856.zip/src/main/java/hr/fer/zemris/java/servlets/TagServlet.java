package hr.fer.zemris.java.servlets;

import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * This servlet is used to return all tags from the file 'opisnik.txt'. They are
 * displayed as buttons on html page. User can click on any of it and see
 * pictures related to it.
 * 
 * @author ivona
 *
 */
@WebServlet(urlPatterns = { "/servlets" })
public class TagServlet extends HttpServlet {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		Set<String> tags = ImageDB.setOfTags();
		String[] array = new String[tags.size()];

		tags.toArray(array);

		resp.setContentType("application/json;charset=UTF-8");

		Gson gson = new Gson();
		String jsonText = gson.toJson(array);

		resp.getWriter().write(jsonText);

		resp.getWriter().flush();

	}

}
