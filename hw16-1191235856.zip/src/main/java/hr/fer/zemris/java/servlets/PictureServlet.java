package hr.fer.zemris.java.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

/**
 * This servlet is used to give list of all images related to some specific tag
 * - that one given through url.
 * 
 * @author ivona
 *
 */
@WebServlet(urlPatterns = { "/servlets/picture" })
public class PictureServlet extends HttpServlet {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String tag = req.getParameter("tag");

		List<String> imagesNames = new ArrayList<String>();

		List<Image> images = ImageDB.listAllImages();

		for (Image img : images) {
			if (img.getTags().contains(tag)) {
				imagesNames.add(img.getName());
			}
		}

		String[] array = new String[imagesNames.size()];

		imagesNames.toArray(array);

		resp.setContentType("application/json;charset=UTF-8");

		Gson gson = new Gson();
		String jsonText = gson.toJson(array);

		resp.getWriter().write(jsonText);

		resp.getWriter().flush();

	}
}
