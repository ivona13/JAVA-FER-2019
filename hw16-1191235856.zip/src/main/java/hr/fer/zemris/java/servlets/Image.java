package hr.fer.zemris.java.servlets;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to represent Image - it is considered as basic unit in out
 * gallery. We want to display images related to some tags.
 * 
 * @author ivona
 *
 */
public class Image {

	/**
	 * Image name
	 */
	private String name;

	/**
	 * Image description
	 */
	private String description;

	/**
	 * List of tags related to image
	 */
	private List<String> tags = new ArrayList<String>();

	/**
	 * Constructor
	 */
	public Image() {
	}

	/**
	 * Basic constructor
	 * 
	 * @param name        name
	 * @param desctiption description
	 * @param tags        tags
	 */
	public Image(String name, String desctiption, List<String> tags) {
		this.name = name;
		this.description = desctiption;
		this.tags = tags;
	}

	/**
	 * Name getter
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Description getter
	 * 
	 * @return description
	 */
	public String getDesctiption() {
		return description;
	}

	/**
	 * Tags getter
	 * 
	 * @return list of tags
	 */
	public List<String> getTags() {
		return tags;
	}

	/**
	 * Name setter
	 * 
	 * @param name name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Description setter
	 * 
	 * @param desctiption description
	 */
	public void setDesctiption(String desctiption) {
		this.description = desctiption;
	}

	/**
	 * Tags setter
	 * 
	 * @param tags tags
	 */
	public void setTags(List<String> tags) {
		this.tags = tags;
	}

	@Override
	public String toString() {
		return "Image [name=" + name + ", description=" + description + ", tags=" + tags + "]";
	}

}
