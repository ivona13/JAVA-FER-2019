package hr.fer.zemris.java.hw01;

import java.util.Scanner;

/**
 * Ovaj razred se koristi za sortiranje brojeva (uzlazno i silazno) pomoću
 * binarnog stabla. U stablu se svaki broj može naći najviše jednom. Brojevi
 * koji se sortiraju unose se preko console.
 * 
 * @author Ivona
 *
 */
public class UniqueNumbers {

	/**
	 * Ovaj razred predstavlja jedan čvor stabla.
	 * 
	 * @author Ivona
	 *
	 */
	public static class TreeNode {

		/**
		 * Lijevo dijete čvora
		 */
		TreeNode left;

		/**
		 * Desno dijete čvora
		 */
		TreeNode right;

		/**
		 * Vrijednost čvora (što je upisano u njemu)
		 */
		int value;
	}

	/**
	 * Ova metoda omogućava dodavanje novog čvora stablu.
	 * 
	 * @param glava   Čvor koji označava korijen stabla.
	 * @param element Vrijednost novog čvora
	 * @return novi korijenski čvor
	 */
	public static TreeNode addNode(TreeNode glava, int element) {
		if (glava == null) {
			glava = new TreeNode();
			glava.value = element;
			return glava;
		}

		if (element < glava.value) {
			glava.left = addNode(glava.left, element);

		} else if (element > glava.value) {
			glava.right = addNode(glava.right, element);

		}
		// čvor s vrijednošću element već postoji
		return glava;
	}

	/**
	 * Ova metoda koja računa veličinu stabla.
	 * 
	 * @param glava Čvor koji označava korijen stabla
	 * @return veličinu stabla
	 */
	public static int treeSize(TreeNode glava) {
		if (glava == null) {
			return 0;
		}
		return treeSize(glava.left) + treeSize(glava.right) + 1;
	}

	/**
	 * Ova metoda govori je li čvor koji ima zadanu vrijednost u stablu ili ne.
	 *
	 * @param glava   Čvor koji označava korijen stabla
	 * @param element Vrijednost čvora čiju prisutnost u stablu utvrđujemo
	 * @return <code>true</code> ako je čvor u stablu, inače <code>false</code>
	 */
	public static boolean containsValue(TreeNode glava, int element) {
		if (glava == null) {
			return false;
		}

		if (glava.value == element || containsValue(glava.left, element) || containsValue(glava.right, element)) {
			return true;
		}

		return false;
	}

	/**
	 * Metoda koja ispisuje čvorove stabla sortirano u poretku ovisno o ulaznom
	 * stringu. Ako metoda primi string "silazno", metoda sortira čvorove stabla
	 * silazno; ako metoda primi string "uzlazno", čvorovi se sortiraju uzlazno.
	 * 
	 * @param glava Korijen stabla
	 * @param s     String koji određuje poredak sortiranosti čvorova stabla -
	 *              silazno ili uzlazno
	 */
	public static void sort(TreeNode glava, String s) {
		if (glava == null) {
			return;
		}
		if (s.equals("uzlazno")) {
			if (glava.left != null) {
				sort(glava.left, s);
			}
			System.out.printf(glava.value + " ");
			if (glava.right != null) {
				sort(glava.right, s);
			}
		}
		if (s.equals("silazno")) {
			if (glava.right != null) {
				sort(glava.right, s);
			}
			System.out.printf(glava.value + " ");
			if (glava.left != null) {
				sort(glava.left, s);
			}
		}
	}

	/**
	 *  Metoda pokrece izvodenje programa.
	 *
	 */
	public static void main(String... args) {
		TreeNode glava = null;

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.printf("Unesite broj > ");
			if (sc.hasNext("kraj")) {
				System.out.printf("Ispis od najmanjeg: ");
				sort(glava, "uzlazno");
				System.out.println("");
				System.out.printf("Ispis od najvećeg: ");
				sort(glava, "silazno");
				sc.close();
				break;
			}
			String current = sc.next();
			try {
				int value = Integer.parseInt(current);
				if (containsValue(glava, value)) {
					System.out.println("Broj već postoji. Preskačem.");
				} else {
					glava = addNode(glava, value);
					System.out.println("Dodano.");
				}
			} catch (IllegalArgumentException ex) {
				System.out.println("'" + current + "' nije cijeli broj.");
			}

		}
		sc.close();

	}

}
