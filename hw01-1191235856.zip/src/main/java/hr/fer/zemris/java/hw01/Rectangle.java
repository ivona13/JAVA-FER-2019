package hr.fer.zemris.java.hw01;

import java.util.*;

/**
 * Ovaj razred za dane dvije veličine širinu i visinu računa površinu i opseg.
 * Te veličine mogu biti zadane preko komandne linije, a mogu se i unijeti preko
 * console.
 * 
 * @author Ivona
 *
 */
public class Rectangle {

	/**
	 * Metoda koja omogućava unos jedne od veličina potrebnih za računanje površine
	 * i opsega. Radi li se širini ili visini određuje parametar s kojeg metoda
	 * prima.
	 * 
	 * @param s  String koji predstavlja veličinu (širinu ili visinu) za koju
	 *           unosimo vrijednost
	 * @param sc Razred Scanner kojeg koristimo za čitanje s tipkovnice
	 * @return vrijednost tipa double koja je upravo vrijednost širine, odnosno
	 *         visine (u ovisnosti o stringu s)
	 */
	public static double unesi(String s, Scanner sc) {
		while (true) {
			System.out.printf("Unesite " + s + " > ");
			String current = sc.next();
			try {

				double vrijednost = Double.parseDouble(current);
				if (vrijednost <= 0) {
					System.out.println("Unijeli ste vrijednost koja nije pozitivna.");
				} else {
					return vrijednost;
				}
			} catch (IllegalArgumentException ex) {
				System.out.printf("'%s' se ne može protumačiti kao broj.%n", current);
			}

		}

	}

	/**
	 * Metoda koja se koristi za računanje opsega pravokutnika zadanih veličina.
	 * 
	 * @param širina Širina pravokutnika čiji opseg računamo
	 * @param visina Visina pravokutnika čiji opseg računamo
	 * @return opseg pravokutnika
	 */
	public static double opseg(double širina, double visina) {
		return 2 * (širina + visina);
	}

	/**
	 * Metoda koja se koristi za računanje površine pravokutnika zadanih veličina.
	 * 
	 * @param širina Širina pravokutnika čiju površinu računamo
	 * @param visina Visina pravokutnika čiju površinu računamo
	 * @return površinu pravokutnika
	 */
	public static double površina(double širina, double visina) {
		return širina * visina;
	}

	public static void ispis(double širina, double visina) {

		if (širina > 0 && visina > 0) {
			System.out.println("Pravokutnik širine " + širina + " i visine " + visina + " ima površinu "
					+ površina(širina, visina) + " te opseg " + opseg(širina, visina) + ".");
		} else {
			throw new RuntimeException("Duljine stranica pravokutnika moraju biti pozitivne!");
		}

	}

	/**
	 * Metoda pokrece izvodenje programa.
	 * 
	 * @param args Argumenti komandne linije
	 */
	public static void main(String... args) {
		double širina, visina;

		if (args.length != 0 && args.length != 2) {
			System.out.println("Nisu zadane potrebne vrijednosti.");
			return;
		}

		if (args.length == 2) {
			try {
				širina = Double.parseDouble(args[0]);
				visina = Double.parseDouble(args[1]);
			} catch (NumberFormatException ex) {
				System.out.println("Oba argumenta moraju biti tipa double.");
				return;
			}
		} else {
			Scanner sc = new Scanner(System.in);
			širina = unesi("širinu", sc);
			visina = unesi("visinu", sc);
			sc.close();
		}

		ispis(širina, visina);

	}
}
