package hr.fer.zemris.java.hw01;

import java.util.Scanner;

/**
 * Ovaj razred korisnicima omogućava računanje funkcije faktorijel. Preko
 * tipkovnice se unose cijeli brojevi u rasponu od 3 do 20 za koje se računa
 * faktorijel.
 * 
 * @author Ivona
 *
 */
public class Factorial {

	/**
	 * Ova metoda računa faktorijel za dani cijeli broj.
	 * 
	 * @param broj broj za kojeg računamo faktorijel
	 * @return faktorijel unešenog broja
	 */
	public static long faktorijel(int broj) {
		if (broj < 0 || broj > 20) {
			throw new IllegalArgumentException("Broj izvan dopuštenog raspona.");
		}

		long fact = 1;
		for (int i = 2; i <= broj; i++) {
			fact *= i;
		}
		return fact;
	}

	/**
	 * Metoda pokrece izvodenje programa.
	 * 
	 * @param args Argumenti komandne linije
	 */
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.printf("Unesite broj > ");
			if (sc.hasNext("kraj")) {
				System.out.println("Doviđenja.");
				sc.close();
				return;
			}
			String current = sc.next();
			try {
				int element = Integer.parseInt(current);

				if (element < 3 || element > 20) {
					System.out.printf("'%d' nije u dozvoljenom rasponu.%n", element);
				} else {
					System.out.printf("%d! = %d%n", element, faktorijel(element));
				}
			} catch (IllegalArgumentException ex) {
				System.out.printf("'%s' nije cijeli broj.%n", current);
			}

		}
	}

}
