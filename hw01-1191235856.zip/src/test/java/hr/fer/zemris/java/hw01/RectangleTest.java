package hr.fer.zemris.java.hw01;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Razred sadrži skup testova za metode razreda Rectangle.
 * 
 * @author Ivona
 *
 */
class RectangleTest {

	@Test
	public void testPovršine() {
		assertEquals(26.0, Rectangle.površina(2.0, 13.0), 1E-10);
	}

	@Test
	public void testOpsega() {
		assertEquals(30.0, Rectangle.opseg(2, 13), 1E-10);
	}

	@Test
	public void testNegativnaŠirina() {
		boolean exception = false;
		try {
			Rectangle.ispis(-13, 4);
		} catch (RuntimeException ex) {
			exception = true;
		}
		assertTrue(exception);
	}

	@Test
	public void testNegativnaVisina() {
		boolean exception = false;
		try {
			Rectangle.ispis(13, -9);
		} catch (RuntimeException ex) {
			exception = true;
		}
		assertTrue(exception);
	}

	@Test
	public void testŠirinaString() {
		boolean exception = false;
		try {
			Double.parseDouble("Ivona");
			Double.parseDouble("13");
		} catch (IllegalArgumentException ex) {
			exception = true;
		}
		assertTrue(exception);
	}

}
