package hr.fer.zemris.java.hw01;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static hr.fer.zemris.java.hw01.UniqueNumbers.*;

/**
 * Razred sadrži skup testova za metode razreda UniqueNumbers.
 * 
 * @author Ivona
 *
 */
class UniqueNumbersTest {

	@Test
	public void addNodeTest1() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 42);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 21);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 35);

		assertEquals(42, glava.value);
		assertEquals(21, glava.left.value);
		assertEquals(35, glava.left.right.value);
		assertEquals(76, glava.right.value);
	}

	@Test
	public void addNodeTest2() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 13);
		glava = UniqueNumbers.addNode(glava, 2);

		assertEquals(13, glava.value);
		assertEquals(2, glava.left.value);
	}

	@Test
	public void treeSizeTest1() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 42);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 21);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 35);
		glava = UniqueNumbers.addNode(glava, 80);

		assertEquals(5, treeSize(glava));
	}

	@Test
	public void treeSizeTest2() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 42);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 76);

		assertEquals(2, treeSize(glava));
	}

	@Test
	public void constainsValueTest1() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 42);
		glava = UniqueNumbers.addNode(glava, 76);
		glava = UniqueNumbers.addNode(glava, 21);

		boolean answer = containsValue(glava, 76);
		assertEquals(answer, true);
	}

	@Test
	public void constainsValueTest2() {
		TreeNode glava = null;
		glava = UniqueNumbers.addNode(glava, 3);
		glava = UniqueNumbers.addNode(glava, 4);
		glava = UniqueNumbers.addNode(glava, 2);

		boolean answer = containsValue(glava, 7);
		assertEquals(answer, false);
	}

}
