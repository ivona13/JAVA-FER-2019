package hr.fer.zemris.java.hw01;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Razred sadrži skup testova za metode razreda Factorial.
 * 
 * @author Ivona
 *
 */
class FactorialTest {

	@Test
	public void faktorijelOd3() {
		assertEquals(6L, Factorial.faktorijel(3));
	}

	@Test
	public void faktorijelOd0() {
		assertEquals(1, Factorial.faktorijel(0));

	}

	@Test
	public void faktorijelNegativnogBroja() {
		boolean exception = false;
		try {
			Factorial.faktorijel(-1);
		} catch (IllegalArgumentException ex) {
			exception = true;
		}
		assertTrue(exception);
	}

	@Test
	public void faktorijelIznadGornjeGranice() {
		boolean exception = false;
		try {
			Factorial.faktorijel(28);
		} catch (IllegalArgumentException ex) {
			exception = true;
		}
		assertTrue(exception);
	}

}
