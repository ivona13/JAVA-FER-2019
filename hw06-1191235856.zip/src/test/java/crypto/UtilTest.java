package crypto;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;

import hr.fer.zemris.java.hw06.crypto.Util;

public class UtilTest {

	@Test
	public void hextobyteEmptyTest() {

		String keyText = "";
		byte[] expected = new byte[] {};
		byte[] actual = Util.hextobyte(keyText);
		assertArrayEquals(expected, actual);
	}

	@Test
	public void hextobyteTest() {
		String keyText = "01aE22";
		byte[] expected = new byte[] { 1, -82, 34 };
		byte[] actual = Util.hextobyte(keyText);
		assertArrayEquals(expected, actual);

	}
	
	  @Test
	    public void testHextobyteInvalid() {
		  try {
	        String keyText = "01a";

	        byte[] actual = Util.hextobyte(keyText);
		  } catch(IllegalArgumentException e) {
			  assertEquals(e.getMessage(), "Key should be divisible by 2!");
		  }

	}

	@Test
	public void bytetohexTest() {
		byte[] bytes = new byte[] { 1, -82, 34 };
		String expected = "01ae22";
		String actual = Util.bytetohex(bytes);
		assertEquals(expected, actual);
	}
	
	@Test
	public void bytetohextest() {
		byte[] bytes = new byte[] { 1, -82, 34 };
		String expected = "01AE22";
		String actual = Util.bytetohex(bytes);
		assertNotEquals(expected, actual);
	}
	
	
}
