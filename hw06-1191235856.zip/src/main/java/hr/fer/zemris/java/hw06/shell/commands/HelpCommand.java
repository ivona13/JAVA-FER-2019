package hr.fer.zemris.java.hw06.shell.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;

/**
 * This class is used to represent help command. If it has no arguments, it
 * lists all commands of MyShell. It it has one argument, it prints description
 * of input command.
 * 
 * @author ivona
 *
 */
public class HelpCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		Map<String, ShellCommand> commands = env.commands();

		if (arguments.length() == 0) {
			for (String command : commands.keySet()) {
				env.writeln(command);

			}

			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;

		} else {
			ShellCommand command = commands.get(arguments);
			if (command == null) {
				System.out.println("Not known command.");
			} else {
				for (String s : command.getCommandDescription()) {
					env.writeln(s);
				}

			}
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "help";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Help command.");
		commandDescription.add("If used with no arguments it lists all available commands.");
		commandDescription.add("If used with command name as argument, it prints description of given command.");

		return commandDescription;
	}

}
