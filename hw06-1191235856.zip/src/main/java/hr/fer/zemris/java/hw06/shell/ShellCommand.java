package hr.fer.zemris.java.hw06.shell;

import java.util.List;

/**
 * This class is used for representing commands in shell.
 * 
 * @author ivona
 *
 */
public interface ShellCommand {
	/**
	 * This method is used for executing command in environment with input
	 * arguments.
	 * 
	 * @param env       Environment
	 * @param arguments Command arguments
	 * @return ShellStatus
	 */
	ShellStatus executeCommand(Environment env, String arguments);

	/**
	 * This method is used to return name of ShellCommand.
	 * 
	 * @return name of command
	 */
	String getCommandName();

	/**
	 * This method is used for getting description of Command
	 * 
	 * @return List of Strings which are command descriptions
	 */
	List<String> getCommandDescription();

}
