package hr.fer.zemris.java.hw06.crypto;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.KeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Scanner;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * This class is used to represent crypting. Program can be used for digesting (used to verify if the data you have received  arrived unchanged),
 * encrypting and descrypting files. All nedded information(digest, key and initialization vector) are recieved through console.
 *
 * @author ivona
 */
public class Crypto {

	/**
	 * This method is used for crypting (encrypting and decrypting) files.
	 * @param input INput file
	 * @param output Output file
	 * @param arg action(encrypt/decrypt)
	 * @param keyText Key used in encrypting
	 * @param ivText initialization vector for encrypting
	 * @throws KeyException general KeyException
	 * @throws Exception basic Exception while digesting 
	 */
	private static void crypt(Path input, Path output, String arg, String keyText, String ivText) throws KeyException, Exception {
		try {
			InputStream inputStream = Files.newInputStream(input, StandardOpenOption.READ);
			OutputStream outputStream = Files.newOutputStream(output, StandardOpenOption.CREATE);

			byte[] buffer = new byte[4096];

			SecretKeySpec keySpec = new SecretKeySpec(Util.hextobyte(keyText), "AES");

			AlgorithmParameterSpec paramSpec = new IvParameterSpec(Util.hextobyte(ivText));

			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

			boolean encrypt = arg.equals("encrypt");
			cipher.init(encrypt ? Cipher.ENCRYPT_MODE : Cipher.DECRYPT_MODE, keySpec, paramSpec);

			// b equals total number of read bytes from buffer from the beginning
			// bytes are stored in buffer now
			int b = inputStream.read(buffer);
			while (b != -1) {

				// update buffer from 0 position, length of b
				outputStream.write(cipher.update(buffer, 0, b));
				b = inputStream.read(buffer);
			}

			outputStream.write(cipher.doFinal());
		} catch (IOException e) {
			System.out.print("Invalid operation of crypting.");
			System.exit(1);
		}
	}

	/**
	 * This method determines if if checkSum of given file equals expected checksum.
	 * @param p File to be checked
	 * @param expected Expected sum
	 * @throws NoSuchAlgorithmException if algorithm in initializing Message Digest is not valid
	 */
	private static void checksha(Path p, String expected) throws NoSuchAlgorithmException {

		try {
			InputStream inputStream = Files.newInputStream(p, StandardOpenOption.READ);

			byte[] buffer = new byte[4096];

			// initialize message digest -> algorithm which supports is SHA-265
			// used to verify if the data we recieved arrived unchanged
			MessageDigest md = MessageDigest.getInstance("SHA-256");

			int b = inputStream.read(buffer);
			while (b != -1) {

				md.update(buffer, 0, b);
				b = inputStream.read(buffer);
			}

			// final operations to complete hash computation
			byte[] sum = md.digest();

			String checkSum = Util.bytetohex(sum);

			if (expected.equals(checkSum)) {
				System.out.println("Digesting completed. Digest of " + p.getFileName() + " matches expected digest.");
			} else {
				System.out.println("Digesting completed. Digest of " + p.getFileName()
						+ " does not matche the expected digest. Digest\n" + "was:" + checkSum);
			}

		} catch (IOException e) {
			System.out.println("Error while digesting!");
			System.exit(1);
		}
	}

	/**
	 * Main method
	 * @param args Arguments for specifying action to be done
	 * @throws KeyException Exception while entering key for crypting
	 * @throws Exception basic Exception
	 */
	public static void main(String[] args) throws KeyException, Exception {
		if (args.length != 2 && args.length != 3) {
			// System.out.println(args.length);
			throw new IllegalArgumentException("Invalid number of operands!");
		}

		Scanner sc = new Scanner(System.in);

		switch (args[0]) {
		case "checksha":
			if (args.length != 2) {
				System.out.println("Inavlid number of arguments");
				System.exit(1);
			}

			System.out.println("Please provide expected sha-256 digest for hw06test.bin:\n>");
			String checkSum = sc.nextLine();

			checksha(Paths.get(args[1]), checkSum);
			break;

		case "encrypt":
		case "decrypt":
			if (args.length != 3) {
				System.out.println("Invalid number of arguments");
				System.exit(1);
			}

			System.out.println("Please provide password as hex-encoded text (16 bytes, i.e. 32 hex-digits):\n>");

			String password = sc.nextLine();

			System.out.println("Please provide initialization vector as hex-encoded text (32 hex-digits):\n>");

			String ivText = sc.nextLine();

			crypt(Paths.get(args[1]), Paths.get(args[2]), args[0], password, ivText);

			if (args[0].equals("encrypt")) {
				System.out.println("Encryption completed. Generated file " + Paths.get(args[2]) + "  based on file  "
						+ Paths.get(args[1]) + ".");
			} else if (args[0].equals("decrypt")) {
				System.out.println("Decryption completed. Generated file " + Paths.get(args[2]) + " based on file  "
						+ Paths.get(args[1]) + ".");
			}
			break;

		default:
			System.out.println("Unknown command.");
			System.exit(1);
		}

		sc.close();

	}
}
