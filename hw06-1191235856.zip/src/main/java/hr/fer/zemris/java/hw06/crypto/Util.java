package hr.fer.zemris.java.hw06.crypto;

/**
 * This class is used as utility class for {@link Crypto} class. 
 * There are two methods, hextobyte and bytetohex.
 * Hextobyte is used for transformation byte array to String.
 * Bytetohex is used for transformation byte array to String.
 * @author ivona
 *
 */
public class Util {

	/**
	 * This method is used for transformation of String to byte array.
	 * @param keyString String to be transformed
	 * @return byte Array
	 */
	public static byte[] hextobyte(String keyString) {

		if (keyString.length() == 0) {
			return new byte[0];
		}

		if (keyString.length() % 2 == 1) {
			throw new IllegalArgumentException("Key should be divisible by 2!");
		}

		byte[] byteArray = new byte[keyString.length() / 2];

		for (int i = 0; i < byteArray.length; i++) {
			int index = i * 2;
			int value = Integer.parseInt(keyString.substring(index, index + 2), 16);
			byteArray[i] = (byte) value;
		}

		return byteArray;
	}

	/**
	 * This class is used for transformation of byte Array to String.
	 * @param bytearray byte Array to be transformed
	 * @return String
	 */
	public static String bytetohex(byte[] bytearray) {
		StringBuilder string = new StringBuilder();

		for (Byte b : bytearray) {
			string.append(String.format("%02x", b));
		}

		return string.toString();
	}

}
