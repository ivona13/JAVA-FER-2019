package hr.fer.zemris.java.hw06.shell;

import java.util.SortedMap;

/**
 * This interface is used to represent environment. It is used for communication
 * between shell and user.
 * 
 * @author ivona
 *
 */
public interface Environment {

	/**
	 * This method is used for reading line from environment.
	 * @return read Line
	 * @throws ShellIOException if something goes wrong
	 */
	String readLine() ;

	/**
	 * This method is used for writing to environment.
	 * @param text Text to write
	 * @throws ShellIOException if something goes wrong
	 */
	void write(String text);

	/**
	 * 
	 * @param text
	 * @throws ShellIOException
	 */
	void writeln(String text);

	/**
	 * Used for storing all commands that are available in environment.
	 * @return
	 */
	SortedMap<String, ShellCommand> commands();

	/**
	 * This method is used for getting Multilines Symbol
	 * @return multiLinesSymbol
	 */
	Character getMultilineSymbol();

	/**
	 * This method is used for setting MultilineSymbol
	 * @param symbol MultilineSymbol
	 */
	void setMultilineSymbol(Character symbol);

	/**
	 * This method is used for getting Symbol of Command Prompt
	 * @return promptSymbol
	 */
	Character getPromptSymbol();

	/**
	 * This method is used for setting prompt Symbol
	 * @param symbol Prompt Symbol
	 */
	void setPromptSymbol(Character symbol);

	/**
	 * This method is used for getting MoreLinesSymbol
	 * @return MorelinesSymbol
	 */
	Character getMorelinesSymbol();

	/**
	 * This method is used for setting MorelinessSymbol
	 * @param symbol MorelinesSymbol
	 */
	void setMorelinesSymbol(Character symbol);

}
