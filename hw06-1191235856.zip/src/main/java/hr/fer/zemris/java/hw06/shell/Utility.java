package hr.fer.zemris.java.hw06.shell;

/**
 * This class is used as utility class for MyShell and ShellCommand. It has twoo
 * methods and they are used for parsing appropriate names.
 * 
 * @author ivona
 *
 */
public class Utility {

	/**
	 * This class is used for parsing name from file
	 * 
	 * @param line String to parse
	 * @param env  Environment
	 * @return String
	 */
	public static String parseName(String line, Environment env) {
		if (!(line.contains(" "))) {
			return line;
		}

		return line.substring(0, line.indexOf(" "));

	}

	/**
	 * This class is used for parsing path from line
	 * 
	 * @param line        String to be parsed
	 * @param environment Environmet
	 * @return parsed Path
	 */
	public static String parsePath(String line, Environment environment) {

		Environment env = environment;
		if (line.startsWith("\"")) {
			StringBuilder sb = new StringBuilder();
			int currentIndex = 0;
			currentIndex++;

			while (currentIndex <= line.length()) {
				if (currentIndex >= line.length()) {
					env.writeln("Invalid quote!");
					env.writeln(env.getPromptSymbol() + " ");
					break;
				}

				if (currentIndex < line.length()) {
					if (line.charAt(currentIndex) == '/') {
						currentIndex++;
						if (currentIndex > line.length()) {
							env.writeln("Invalid quote!");
							env.writeln(env.getPromptSymbol() + " ");
							break;

						}

						if (line.charAt(currentIndex) == '\"' || line.charAt(currentIndex) == '/') {
							sb.append(line.charAt(currentIndex++));
						} else {
						}
						if ((currentIndex + 1) >= line.length()) {
							env.writeln("Invalid quote!");
							env.writeln(env.getPromptSymbol() + " ");
							break;
						}
						sb.append("/").append(line.charAt(currentIndex++));
					} else if (line.charAt(currentIndex) == '\"') {
						currentIndex++;
						break;
					} else {
						sb.append(line.charAt(currentIndex++));
					}
				}

			}

			if (currentIndex == line.length() || Character.isSpaceChar(line.charAt(currentIndex))) {
				return sb.toString();
			} else {
				env.write("Invalid quote!");
				env.write(env.getPromptSymbol() + " ");
			}
		}

		if (line.contains(" ")) {
			return line.substring(0, line.indexOf(" "));
		} else {
			return line;
		}

	}

	/**
	 * This class is used to parse Path
	 * @param line Input string to be parsed as Path
	 * @return String
	 */
	public static String parsePath(String line) {

		if (line.startsWith("\"")) {
			StringBuilder sb = new StringBuilder();
			int currentIndex = 0;
			currentIndex++;

			while (currentIndex <= line.length()) {
				if (currentIndex >= line.length()) {
					System.out.println("Invalid quote!");

					break;
				}

				if (currentIndex < line.length()) {
					if (line.charAt(currentIndex) == '/') {
						currentIndex++;
						if (currentIndex > line.length()) {
							System.out.println("Invalid quote!");
							break;

						}

						if (line.charAt(currentIndex) == '\"' || line.charAt(currentIndex) == '/') {
							sb.append(line.charAt(currentIndex++));
						} else {
						}

						sb.append("/").append(line.charAt(currentIndex++));
					} else if (line.charAt(currentIndex) == '\"') {
						currentIndex++;
						break;
					} else {
						sb.append(line.charAt(currentIndex++));
					}
				}

			}

			if (currentIndex == line.length() || Character.isSpaceChar(line.charAt(currentIndex))) {
				return sb.toString();
			} else {
				System.out.println("Invalid quote!");

			}
		}

		if (line.contains(" ")) {
			return line.substring(0, line.indexOf(" "));
		} else {
			return line;
		}

	}
}
