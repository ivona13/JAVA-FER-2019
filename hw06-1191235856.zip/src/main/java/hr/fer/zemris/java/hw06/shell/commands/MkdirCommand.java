package hr.fer.zemris.java.hw06.shell.commands;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;


/**
 * This class is used to represent make directory command. It has one argument,
 * which is directory name, and creates directory structure.
 * 
 * @author ivona
 *
 */
public class MkdirCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {

		String parts[] = arguments.split(" ");
		String name = Utility.parsePath(arguments);

		if (parts.length != 1) {
			env.writeln("Invalid number of arguments.");
			env.writeln(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		String directoryName = name;

		try {
			Files.createDirectories(Paths.get(directoryName));
			env.writeln("Directory created");
		} catch (IOException e) {
			env.writeln("Error while creating directory.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	@Override
	public String getCommandName() {
		return "mkdir";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Mkdir command.");
		commandDescription.add(
				"It takes a single argument: directory name, and creates the appropriate directory\n" + "structure.");

		return commandDescription;
	}

}
