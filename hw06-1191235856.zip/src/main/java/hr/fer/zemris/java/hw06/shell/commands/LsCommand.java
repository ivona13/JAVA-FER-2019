package hr.fer.zemris.java.hw06.shell.commands;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.IntStream;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class represents ls command. It takes one argument, directory name and
 * lists all files inside IT has 4 columns. First one gives information about
 * next properties: isDirectory, readable, writable and executable. Second
 * column is file size. Third is creation date and time. Fourth is file name.
 * 
 * @author ivona
 *
 */
public class LsCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		String pathString = Utility.parsePath(arguments, env);

		Path directory = Paths.get(pathString);
		if (!Files.isDirectory(directory)) {
			env.writeln("File is not directory.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}
		// System.out.println(directory.getFileName());

		if (!Files.isDirectory(directory)) {
			env.writeln("Argument given isn't directory!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		long maxLengthFile = 0;
		try {
			DirectoryStream<Path> count = Files.newDirectoryStream(directory);
			for (Path path : count) {
				if (Files.size(path) > maxLengthFile) {
					maxLengthFile = Files.size(path);
				}
			}

			int longestLength = Long.toString(maxLengthFile).length();

			DirectoryStream<Path> entry = Files.newDirectoryStream(directory);

			for (Path path : entry) {
				StringBuilder string = new StringBuilder();

				if (Files.isDirectory(path)) {
					string.append("d");
				} else {
					string.append("-");
				}

				if (Files.isReadable(path)) {
					string.append("r");
				} else {
					string.append("-");
				}

				if (Files.isWritable(path)) {
					string.append("w");
				} else {
					string.append("-");
				}

				if (Files.isExecutable(path)) {
					string.append("x");
				} else {
					string.append("-");
				}

				string.append(" ");

				long fileSize = Files.size(path);
				int currentLength = Long.toString(fileSize).length();

				for (int i = 0; i < (longestLength - currentLength); i++) {
					string.append(" ");
				}

				string.append(fileSize).append(" ");

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				BasicFileAttributeView faView;
				faView = Files.getFileAttributeView(path, BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
				BasicFileAttributes attributes = faView.readAttributes();
				FileTime fileTime = attributes.creationTime();
				String formattedDateTime = sdf.format(new Date(fileTime.toMillis()));

				string.append(formattedDateTime);
				string.append(" ");
				string.append(path.getFileName());
				env.writeln(string.toString());

			}

		} catch (IOException ex) {
			env.write("Error while reading file");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	@Override
	public String getCommandName() {
		return "ls";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Ls command.");
		commandDescription.add("It takes a single argument which has to be directory name.");
		commandDescription.add("It writes directory listing(not recursive)");
		commandDescription.add("The output consists of 4 columns.");
		commandDescription.add(
				"First column indicates if current object is directory (d), readable (r), writable (w) and executable (x).");
		commandDescription
				.add("Second column contains object size in bytes that is right aligned and occupies 10 characters.");
		commandDescription.add("Third column is creation date/time and fourth column is file name.");

		return commandDescription;
	}
}
