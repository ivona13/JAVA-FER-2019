package hr.fer.zemris.java.hw06.shell.commands;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent cat command. It takes two arguments - the
 * first one is path to some file and is mandatory; the second argument is
 * charset name used for interpret chars from byte. It there is no second
 * argument, default charset is used. This command opens file and writes its
 * content to console.
 * 
 * @author ivona
 *
 */
public class CatCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {

		String pathString = Utility.parsePath(arguments, env);
		Charset charset = Charset.defaultCharset();

		int currentIndexInArgument = pathString.length();

		if (arguments.startsWith("\"")) {
			currentIndexInArgument += 2;
			currentIndexInArgument += IntStream.range(0, pathString.length())
					.filter(i -> pathString.charAt(i) == '"' || pathString.charAt(i) == '\\').count();

		}

		Path path;
		if (currentIndexInArgument >= arguments.length()) {
			path = Paths.get(pathString);
		} else {
			String charsetString = arguments.substring(currentIndexInArgument).trim();

			path = Paths.get(pathString);

			try {
				charset = Charset.forName(charsetString);
			} catch (UnsupportedCharsetException ex) {
				env.writeln("Invalid charset!");
				env.write(env.getPromptSymbol() + " ");
				return ShellStatus.CONTINUE;
			}
		}

		try {
			InputStream is = Files.newInputStream(path, StandardOpenOption.READ);
			byte[] buff = new byte[4096];

			while (true) {
				int r = is.read(buff);
				if (r < 1)
					break;

				String output = new String(Arrays.copyOf(buff, r), charset);
				env.writeln(output);
			}
		} catch (IOException e) {
			env.writeln("Error while opening files!");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}
		// env.writeln("");
		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;
	}

	@Override
	public String getCommandName() {
		return "cat";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<String>();

		commandDescription.add("Cat command.");
		commandDescription.add("It takes one or two arguments.");
		commandDescription.add("The first argument is path to some file and is mandatory.");
		commandDescription
				.add("The second argument is charset name that should be used to interpret chars from bytes.");
		commandDescription.add("If it is not provided, default charset is used.");
		commandDescription.add("This command opend given file and writes its content to console");

		return commandDescription;
	}

}
