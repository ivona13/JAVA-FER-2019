package hr.fer.zemris.java.hw06.shell.commands;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import hr.fer.zemris.java.hw06.shell.Environment;
import hr.fer.zemris.java.hw06.shell.ShellCommand;
import hr.fer.zemris.java.hw06.shell.ShellStatus;
import hr.fer.zemris.java.hw06.shell.Utility;

/**
 * This class is used to represent tree command. It takes one argument which is
 * directory name and prints tree of its files.(2 spaces to the right for each
 * level)
 * 
 * @author ivona
 *
 */
public class TreeCommand implements ShellCommand {

	@Override
	public ShellStatus executeCommand(Environment env, String arguments) {
		String pathString = Utility.parsePath(arguments, env);

		Path directory = Paths.get(pathString);
		if (!Files.isDirectory(directory)) {
			env.writeln("File is not directory.");
			env.write(env.getPromptSymbol() + " ");
			return ShellStatus.CONTINUE;
		}
	//	System.out.println(directory.getFileName());

		try {
			Files.walkFileTree(directory, new TreeVisitor(env));
		} catch (IOException e) {
			System.out.println("Invalid reading from file.");
		}

		env.write(env.getPromptSymbol() + " ");
		return ShellStatus.CONTINUE;

	}

	private static class TreeVisitor implements FileVisitor<Path> {

		private int level = 0;
		private Environment env;

		public TreeVisitor(Environment env) {
			super();
			this.env = env;
		}

		@Override
		public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
			StringBuilder string = new StringBuilder();
			for (int i = 0; i < level; i++) {
				string.append(" ");
			}

			string.append(dir.getFileName());
			env.writeln(string.toString());
			level += 2;
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
			StringBuilder string = new StringBuilder();
			for (int i = 0; i < level; i++) {
				string.append(" ");
			}
			string.append(file.getFileName());
			env.writeln(string.toString());
			return FileVisitResult.CONTINUE;
		}

		@Override
		public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
			return FileVisitResult.CONTINUE;

		}

		@Override
		public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
			level -= 2;
			return FileVisitResult.CONTINUE;
		}

	}

	@Override
	public String getCommandName() {
		return "tree";
	}

	@Override
	public List<String> getCommandDescription() {
		List<String> commandDescription = new ArrayList<>();

		commandDescription.add("Tree command.");
		commandDescription.add("It takes a single argument which has to be directory name.");
		commandDescription.add("It prints a tree (each directory level shifts output two characters to the right).");

		return commandDescription;

	}
}
