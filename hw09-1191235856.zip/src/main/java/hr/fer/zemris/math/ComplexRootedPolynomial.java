package hr.fer.zemris.math;

import java.util.List;

/**
 * This class is used to represent Complex polynomial in the following form:
 * f(z) = z0*(z - z1)*(z - z2)*...*(z-zn) where z0 is constant, and z1, ..., zn
 * are roots of polynomial.
 * 
 * @author ivona
 *
 */
public class ComplexRootedPolynomial {

	/**
	 * constant z0 of polynomial
	 */
	private Complex constant;
	/**
	 * Roots of polynomial
	 */
	private Complex[] roots;

	/**
	 * Basic constructor
	 * 
	 * @param constant constant
	 * @param roots    polynomial roots
	 */
	public ComplexRootedPolynomial(Complex constant, Complex... roots) {
		this.constant = constant;
		this.roots = roots;
	}

	/**
	 * Basic constructor where coefficient equals 1
	 * 
	 * @param complexNumbers
	 */
	public ComplexRootedPolynomial(List<Complex> complexNumbers) {
		this.constant = Complex.ONE;
		this.roots = complexNumbers.toArray(new Complex[] {});
	}

	/**
	 * This method is used for calculating value at given point.
	 *
	 * @param z point
	 * @return Complex
	 */
	public Complex apply(Complex z) {
		return toComplexPolynom().apply(z);
	}

	/**
	 * This method is used for transforming rooted polynomial to complex polynomial.
	 *
	 * @return ComplexPolynomial
	 */
	public ComplexPolynomial toComplexPolynom() {
		ComplexPolynomial polynomial = new ComplexPolynomial(Complex.ONE);

		for (Complex root : roots) {
			polynomial = polynomial.multiply(new ComplexPolynomial(root.negate(), Complex.ONE));
		}

		// besides roots, there is constant in front of polynomial, so lets multiply new
		// polynomial by this constant
		ComplexPolynomial constantPolynomial = new ComplexPolynomial(this.constant);
		return polynomial.multiply(constantPolynomial);

	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("( " + constant + ") *");
		for (int i = 0; i < roots.length; i++) {
			sb.append("(");

			sb.append("z - (");

			sb.append(roots[i].toString());

			sb.append(")");

			sb.append(") *");
		}

		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	/**
	 * This method is used for calculating index of closest root for given input
	 * that is within input treshold.
	 *
	 * @param z        complex number
	 * @param treshold treshold
	 * @return index of closest root
	 */
	public int indexOfClosestRootFor(Complex z, double treshold) {
		int index = -1;

		int i = 0;
		for (Complex root : roots) {
			if (z.sub(root).getMag() < treshold) {
				index = i;
			}
			i++;
		}

		return index;
	}
}