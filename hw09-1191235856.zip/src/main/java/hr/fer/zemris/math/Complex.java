package hr.fer.zemris.math;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This class is used to represent Complex number.
 * 
 * @author ivona
 *
 */
public class Complex {

	/**
	 * Complex number 0 + 0i
	 */
	public static final Complex ZERO = new Complex(0, 0);

	/**
	 * Complex number 1+0i
	 */
	public static final Complex ONE = new Complex(1, 0);

	/**
	 * Complex number -1+0i
	 */
	public static final Complex ONE_NEG = new Complex(-1, 0);

	/**
	 * Complex number 0+i
	 */
	public static final Complex IM = new Complex(0, 1);

	/**
	 * Complex number 0-i
	 */
	public static final Complex IM_NEG = new Complex(0, -1);

	/**
	 * Real part of complex number
	 */
	private double re;

	/**
	 * Imaginary part of complex number
	 */
	private double im;

	/**
	 * Magnitude
	 */
	private double mag;

	/**
	 * Angle
	 */
	private double ang;

	/**
	 * Basic constructor.
	 *
	 * @param re Real part
	 * @param im Imaginary part
	 */
	public Complex(double re, double im) {

		this.re = re;
		this.im = im;
		this.mag = Math.sqrt(re * re + im * im);
		this.ang = Math.atan2(im, re);
	}

	/**
	 * This method is used for parsing string into Complex number
	 * 
	 * @param s string which has to be parsed
	 * @return Complex number
	 */
	public static Complex parse(String s) {

		Objects.requireNonNull(s, "String cannot be null!");

		// no imaginary part
		if (!s.contains("i")) {
			try {
				return new Complex(Double.parseDouble(s), 0);
			} catch (NumberFormatException ex) {
				throw new RuntimeException("Invalid number!");
			}
		} else {

			if (s.equals("i")) {
				return new Complex(0, 1);
			}

			String[] parts = s.split("i");
			if (parts.length > 1) {
				s = parts[0] + parts[1] + "i";
			}
			s = s.replaceAll("\\s", "");

			Pattern pattern = Pattern.compile("^([-,+]?[0-9]+[.]?[0-9]*)([-,+]?[0-9]*[.]?[0-9]*i)$");
			Matcher matcher = pattern.matcher(s.trim());

			if (matcher.find() && !matcher.group(2).replace('i', ' ').trim().equals("")) {

				double real = Double.parseDouble(matcher.group(1));

				String imaginaryString = matcher.group(2).replace('i', ' ').trim();
				if (imaginaryString.length() == 1) {
					imaginaryString += "1";
				}

				double imaginary = Double.parseDouble(imaginaryString);
				return new Complex(real, imaginary);
			} else {

				// no real part
				pattern = Pattern.compile("^([-,+]?[0-9]*[.]?[0-9]*i)$");
				matcher = pattern.matcher(s.trim());

				if (matcher.find()) {
					double real = 0;

					String imaginaryString = matcher.group(1).replace('i', ' ').trim();
					if (imaginaryString.length() == 1) {
						imaginaryString += "1";
					}

					double imaginary = Double.parseDouble(imaginaryString);
					return new Complex(real, imaginary);
				}

			}
		}

		throw new RuntimeException("Invalid number!");
	}

	/**
	 * This method is used for calculating magnitude of complex number
	 *
	 * @return magnitude
	 */
	public double module() {
		return mag;
	}

	/**
	 * This method is used for multiplying complex numbers.
	 *
	 * @param c Complex number to be multiplied with
	 * @return product
	 */
	public Complex multiply(Complex c) {
		Objects.requireNonNull(c, "Complex number cannot be null!");
		return new Complex(re * c.getRe() - im * c.getIm(), re * c.getIm() + im * c.getRe());
	}

	/**
	 * This method is used for dividing complex numbers.
	 *
	 * @param c complex number to be divided by
	 * @return coefficient
	 */
	public Complex divide(Complex c) {
		Objects.requireNonNull(c, "Complex number cannot be null!");
		if (Double.compare(c.getMag(), 0) == 0) {
			throw new IllegalArgumentException("Can't divide by zero!");
		}

		double squaredDivisorNorm = c.getMag() * c.getMag();
		return new Complex((re * c.getRe() + im * c.getIm()) / squaredDivisorNorm,
				(im * c.getRe() - re * c.getIm()) / squaredDivisorNorm);
	}

	/**
	 * This method is used for adding two complex numbers.
	 *
	 * @param c number to be added with
	 * @return sum
	 */
	public Complex add(Complex c) {
		Objects.requireNonNull(c, "Complex number cannot be null!");
		return new Complex(re + c.getRe(), im + c.getIm());
	}

	/**
	 * This method is used for subtraction two complex numbers.
	 *
	 * @param c subtrahend
	 * @return difference
	 */
	public Complex sub(Complex c) {
		Objects.requireNonNull(c, "Complex number cannot be null!");
		return new Complex(re - c.getRe(), im - c.getIm());
	}

	/**
	 * This method is used for negating complex number.
	 *
	 * @return negation of complex number
	 */
	public Complex negate() {
		return new Complex(-re, -im);
	}

	/**
	 * This method is used for calculating complex number raised on a given
	 * exponent.
	 *
	 * @param n exponent
	 * @return power
	 * @throws IllegalArgumentException if n<0
	 */
	public Complex power(int n) {
		if (n < 0) {
			throw new IllegalArgumentException("Exponent can't be smaller than 0!");
		}

		double powerMag = Math.pow(mag, n);

		return new Complex(powerMag * Math.cos(n * ang), powerMag * Math.sin(n * ang));
	}

	/**
	 * Real part getter
	 *
	 * @return real part
	 */
	public double getRe() {
		return re;
	}

	/**
	 * Imaginary part getter
	 *
	 * @return imaginary part
	 */
	public double getIm() {
		return im;
	}

	/**
	 * Magnitude getter
	 *
	 * @return magnitutde
	 */
	public double getMag() {
		return mag;
	}

	/**
	 * Angle getter
	 *
	 * @return angle
	 */
	public double getAng() {
		return ang;
	}

	/**
	 * This method is used for calculating n-th roots of complex number.
	 *
	 * @param n root
	 * @return list of complex roots
	 * @throws IllegalArgumentException if n<1
	 */
	public List<Complex> root(int n) {
		if (n < 1) {
			throw new IllegalArgumentException("Root exponent can't be smaller than 1!");
		}

		List<Complex> roots = new ArrayList<>();
		double rootMag = Math.pow(mag, 1.0 / n);

		for (int k = 0; k < n; k++) {
			roots.add(new Complex(rootMag * Math.cos((ang + 2 * k * Math.PI) / n),
					rootMag * Math.sin((ang + 2 * k * Math.PI) / n)));
		}

		return roots;

	}

	@Override
	public String toString() {
		return String.format("%s %6f %s %6fi", re >= 0 ? "" : "-", Math.abs(re), im >= 0 ? "+" : "-", Math.abs(im));
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Complex complex = (Complex) o;
		return Math.abs(complex.re - re) < 1E-7 && Math.abs(complex.im - im) < 1E-7;
	}

	@Override
	public int hashCode() {

		return Objects.hash(re, im);
	}
}
