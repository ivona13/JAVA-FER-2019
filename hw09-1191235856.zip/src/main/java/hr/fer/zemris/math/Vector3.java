package hr.fer.zemris.math;

/**
 * This class is used to represent 3-dimensional vector.
 * 
 * @author ivona
 *
 */
public final class Vector3 {

	/**
	 * x coordinate
	 */
	private double x;

	/**
	 * y coordinate
	 */
	private double y;

	/**
	 * z coordinate
	 */
	private double z;

	/**
	 * Basic constructor
	 * @param x x coordinate
	 * @param y y coordinate
	 * @param z z coordinate
	 */
	public Vector3(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	/**
	 * This method calculates norm of the vector
	 * 
	 * @return norm of the vector
	 */
	public double norm() {
		return Math.sqrt(x * x + y * y + z * z);
	}

	/**
	 * This method returns normalized vector.
	 * 
	 * @return normalized vector
	 */
	public Vector3 normalized() {
		return new Vector3(x / norm(), y / norm(), z / norm());
	}

	/**
	 * This method returns sum of this vector and input vector.
	 * 
	 * @param other vector to add to this one
	 * @return vector
	 */
	public Vector3 add(Vector3 other) {
		return new Vector3(x + other.getX(), y + other.getY(), z + other.getZ());
	}

	/**
	 * This method returns subtraction of this vector and input vector.
	 * 
	 * @param other vector to subtract from this
	 * @return vector
	 */
	public Vector3 sub(Vector3 other) {
		return new Vector3(x - other.getX(), y - other.getY(), z - other.getZ());
	}

	/**
	 * This method is used to calculate scalar product of this vector and input
	 * vector.
	 * 
	 * @param other vector to calculate scalar vector
	 * @return vector
	 */
	public double dot(Vector3 other) {
		return x * other.getX() + y * other.getY() + z * other.getZ();
	}

	/**
	 * This method is used to calculate cross product of this vector and input
	 * vector.
	 * 
	 * @param other vector to calculate cross product
	 * @return vector
	 */
	public Vector3 cross(Vector3 other) {
		return new Vector3(y * other.getZ() - z * other.getY(), z * other.getX() - x * other.getZ(),
				x * other.getY() - y * other.getX());
	}

	/**
	 * This method is used for scaling vector.
	 * 
	 * @param s coefficient of scaling
	 * @return scaled vector
	 */
	public Vector3 scale(double s) {
		return new Vector3(x * s, y * s, z * s);
	}

	/**
	 * This method is used for calculating cosine of the angle between this vector
	 * and input vector.
	 * 
	 * @param other vector
	 * @return vector
	 */
	public double cosAngle(Vector3 other) {
		return this.dot(other) / (this.norm() * other.norm());
	}

	/**
	 * x coordinate getter
	 * 
	 * @return x
	 */
	public double getX() {
		return x;
	}

	/**
	 * y coordinate vector
	 * 
	 * @return y
	 */
	public double getY() {
		return y;
	}

	/**
	 * z coordinate getter
	 * 
	 * @return z
	 */
	public double getZ() {
		return z;
	}

	/**
	 * This method is used to represent vector as array with three elements
	 * 
	 * @return array
	 */
	public double[] toArray() {
		double array[] = new double[3];
		array[0] = x;
		array[1] = y;
		array[2] = z;

		return array;
	}

	@Override
	public String toString() {

		return String.format("(%.6f, %.6f, %.6f)", x, y, z);
	}

}
