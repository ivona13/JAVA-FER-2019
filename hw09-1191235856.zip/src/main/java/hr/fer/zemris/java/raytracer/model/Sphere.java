package hr.fer.zemris.java.raytracer.model;

/**
 * This class is used to represent object in scene.
 * 
 * @author ivona
 *
 */
public class Sphere extends GraphicalObject {

	/**
	 * Sphere center
	 */
	Point3D center;

	/**
	 * Sphere radius
	 */
	double radius;

	/**
	 * Red diffuse coef.
	 */
	double kdr;

	/**
	 * Green diffuse coef.
	 */
	double kdg;

	/**
	 * Blue diffuse coef.
	 */
	double kdb;

	/**
	 * Red reflective coef.
	 */
	double krr;

	/**
	 * Green reflective coef.
	 */
	double krg;

	/**
	 * Blue reflective coef.
	 */
	double krb;

	/**
	 * Shininess factor
	 */
	double krn;

	/**
	 * Basic constructor
	 * 
	 * @param center center
	 * @param radius radius
	 * @param kdr    red diffuse coef
	 * @param kdg    green diffuse coef
	 * @param kdb    blue diffuse coef
	 * @param krr    red reflective coef
	 * @param krg    green reflective coef
	 * @param krb    blue reflective coef
	 * @param krn    shininess factor
	 */
	public Sphere(Point3D center, double radius, double kdr, double kdg, double kdb, double krr, double krg, double krb,
			double krn) {
		this.center = center;
		this.radius = radius;
		this.kdr = kdr;
		this.kdg = kdg;
		this.kdb = kdb;
		this.krr = krr;
		this.krg = krg;
		this.krb = krb;
		this.krn = krn;
	}

	@Override
	public RayIntersection findClosestRayIntersection(Ray ray) {
		Point3D origin = ray.start;
		Point3D direction = ray.direction;

		double discriminant = Math.pow(direction.scalarProduct(origin.sub(center)), 2)
				- Math.pow((origin.sub(center)).norm(), 2) + radius * radius;

		if (discriminant < 0) {
			return null;
		}

		double distance = -direction.scalarProduct(origin.sub(center)) - Math.sqrt(discriminant);

		Point3D intersection = origin.add(direction.scalarMultiply(distance));

		return new RayIntersection(intersection, distance, true) {
			@Override
			public Point3D getNormal() {
				return intersection.sub(center).normalize();
			}

			@Override
			public double getKdr() {
				return kdr;
			}

			@Override
			public double getKdg() {
				return kdg;
			}

			@Override
			public double getKdb() {
				return kdb;
			}

			@Override
			public double getKrr() {
				return krr;
			}

			@Override
			public double getKrg() {
				return krg;
			}

			@Override
			public double getKrb() {
				return krb;
			}

			@Override
			public double getKrn() {
				return krn;
			}
		};

	}

}