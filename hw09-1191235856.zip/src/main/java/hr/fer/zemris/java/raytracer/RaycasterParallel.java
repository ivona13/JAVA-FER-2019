package hr.fer.zemris.java.raytracer;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.atomic.AtomicBoolean;

import hr.fer.zemris.java.raytracer.model.GraphicalObject;
import hr.fer.zemris.java.raytracer.model.IRayTracerProducer;
import hr.fer.zemris.java.raytracer.model.IRayTracerResultObserver;
import hr.fer.zemris.java.raytracer.model.LightSource;
import hr.fer.zemris.java.raytracer.model.Point3D;
import hr.fer.zemris.java.raytracer.model.Ray;
import hr.fer.zemris.java.raytracer.model.RayIntersection;
import hr.fer.zemris.java.raytracer.model.Scene;
import hr.fer.zemris.java.raytracer.viewer.RayTracerViewer;

/**
 * This class is used to represent RayCaster whose main program parallelizes the
 * calculation using Fork - Join framework and RecursiveAction.
 * 
 * @author ivona
 *
 */
public class RaycasterParallel {

	/**
	 * Used for comparing double numbers
	 */
	private static final double EPS = 1E-6;

	/**
	 * The main method
	 * 
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		RayTracerViewer.show(getIRayTracerProducer(), new Point3D(10, 0, 0), new Point3D(0, 0, 0),
				new Point3D(0, 0, 10), 20, 20);
	}

	/**
	 * This method is used to produce image using parallel algorithm.
	 *
	 * @return {@link IRayTracerProducer}
	 */
	private static IRayTracerProducer getIRayTracerProducer() {
		return new IRayTracerParallelProducer();
	}

	/**
	 * The {@link RecursiveAction} called for each thread.
	 *
	 * @author ivona
	 * 
	 */
	private static class Action extends RecursiveAction {

		/**
		 * The Constant serialVersionUID.
		 */
		private static final long serialVersionUID = 6795188588980589313L;

		/**
		 * Width of screen
		 */
		private int width;

		/**
		 * Height of screen
		 */
		private int height;

		/**
		 * Horizontal width of observed space
		 */
		private double horizontal;

		/**
		 * Horizontal width of observed space
		 */
		private double vertical;

		/**
		 * The screen corner
		 */
		private Point3D screenCorner;

		/**
		 * View
		 */
		private Point3D view;

		/**
		 * View Up
		 */
		private Point3D viewUp;
		/**
		 * Y min
		 */
		private int yMin;

		/**
		 * Y max
		 */
		private int yMax;
		/**
		 * Position of observer
		 */
		private Point3D eye;

		/**
		 * Scene
		 */
		private Scene scene;

		/**
		 * Red color array
		 */
		private short[] red;

		/**
		 * Green color array
		 */
		private short[] green;

		/**
		 * Blue color array
		 */
		private short[] blue;

		/**
		 * Atomic cancel
		 */
		AtomicBoolean cancel;

		/**
		 * Threshold
		 */
		int THRESHOLD = 100;

		/**
		 * Constructor
		 * @param eye eye
		 * @param view view
		 * @param viewUp viewUp
		 * @param horizontal horizontal
		 * @param vertical vertical
		 * @param width width
		 * @param height height
		 * @param yMin yMin
		 * @param yMax yMax
		 * @param red red
		 * @param green green
		 * @param blue blue
		 * @param cancel cancel
		 */
		public Action(Point3D eye, Point3D view, Point3D viewUp, double horizontal, double vertical, int width,
				int height, int yMin, int yMax, short[] red, short[] green, short[] blue, AtomicBoolean cancel) {
			super();
			this.eye = eye;
			this.view = view;
			this.viewUp = viewUp;
			this.horizontal = horizontal;
			this.vertical = vertical;
			this.width = width;
			this.height = height;
			this.red = red;
			this.green = green;
			this.blue = blue;
			this.yMin = yMin;
			this.yMax = yMax;

			this.cancel = cancel;
		}

		@Override
		protected void compute() {
			if (yMax - yMin + 1 <= THRESHOLD) {
				computeDirect();
				return;
			}
			invokeAll(
					new Action(eye, view, viewUp, horizontal, vertical, width, height, yMin, yMin + (yMax - yMin) / 2,
							red, green, blue, cancel),
					new Action(eye, view, viewUp, horizontal, vertical, width, height, yMin + (yMax - yMin) / 2, yMax,
							red, green, blue, cancel));
		}

		/**
		 * Computes the color of points. Called when threshold is satisfied.
		 */
		private void computeDirect() {

			Point3D zAxis = view.sub(eye).normalize();
			Point3D yAxis = viewUp.normalize().sub(zAxis.scalarMultiply(zAxis.scalarProduct(viewUp.normalize())));
			Point3D xAxis = zAxis.vectorProduct(yAxis);
			Point3D screenCorner = view.sub(xAxis.scalarMultiply(horizontal / 2))
					.add((yAxis.scalarMultiply(vertical / 2)));
			Scene scene = RayTracerViewer.createPredefinedScene();
			short[] rgb = new short[3];
			int offset = yMin * width;
			Point3D screenPoint;

			for (int y = yMin; y < yMax; y++) {
				for (int x = 0; x < width; x++) {
					screenPoint = screenCorner.add(xAxis.scalarMultiply(horizontal * x / (width - 1.0)))
							.sub(yAxis.scalarMultiply(vertical * y / (height - 1.0)));

					tracer(scene, Ray.fromPoints(eye, screenPoint), rgb);

					red[offset] = rgb[0] > 255 ? 255 : rgb[0];
					green[offset] = rgb[1] > 255 ? 255 : rgb[1];
					blue[offset] = rgb[2] > 255 ? 255 : rgb[2];

					offset++;
				}
			}
		}

		/**
		 * Tracer that determines the intersection of the ray and the closest object in
		 * the scene, and determines the colors for the point, if found.
		 *
		 * @param scene scene
		 * @param ray   ray
		 * @param rgb   rgb
		 */
		private void tracer(Scene scene, Ray ray, short[] rgb) {
			// Default ambient light (R,G,B) = (15,15,15)
			double[] colors = { 15, 15, 15 };

			determineColorFor(scene, ray, colors, findClosestIntersection(scene, ray));

			rgb[0] = (short) colors[0];
			rgb[1] = (short) colors[1];
			rgb[2] = (short) colors[2];
		}

		/**
		 * Finds the closest intersection of the ray and the closest object in the
		 * scene.
		 *
		 * @param scene the scene
		 * @param ray   the ray
		 * @return the intersection
		 */
		private RayIntersection findClosestIntersection(Scene scene, Ray ray) {
			RayIntersection closest = null;

			for (GraphicalObject s : scene.getObjects()) {
				RayIntersection local = s.findClosestRayIntersection(ray);

				if (local == null)
					continue;
				if (closest != null && closest.getDistance() < local.getDistance()) {
					continue;
				}

				closest = local;
			}

			return closest;
		}

		/**
		 * Determines the color (RGB) for the point of intersection of scene and ray.
		 *
		 * @param scene  scene
		 * @param ray    ray
		 * @param colors colors
		 * @param s      intersection
		 */
		private void determineColorFor(Scene scene, Ray ray, double[] colors, RayIntersection s) {
			if (s == null) {
				colors[0] = colors[1] = colors[2] = 0;
				return;
			}

			List<LightSource> lights = scene.getLights();

			for (LightSource ls : lights) {
				Point3D lightPoint = ls.getPoint();

				Ray r = Ray.fromPoints(lightPoint, s.getPoint());
				RayIntersection s2 = findClosestIntersection(scene, r);

				if (s2 == null)
					continue;

				if (lightPoint.sub(s2.getPoint()).norm() + EPS <= lightPoint.sub(s.getPoint()).norm()) {
					continue;
				}

				// diffusive component
				double lightNorm = lightPoint.sub(s2.getPoint()).normalize().scalarProduct(s2.getNormal());
				lightNorm = (lightNorm > 0) ? lightNorm : 0;

				colors[0] += ls.getR() * s2.getKdr() * lightNorm;
				colors[1] += ls.getG() * s2.getKdg() * lightNorm;
				colors[2] += ls.getB() * s2.getKdb() * lightNorm;

				// reflective component
				Point3D normal = s2.getNormal();
				Point3D l = lightPoint.sub(s2.getPoint());
				Point3D lightProjection = normal.scalarMultiply(l.scalarProduct(normal));

				Point3D rP = lightProjection.add(lightProjection.negate().add(l).scalarMultiply(-1));
				Point3D v = ray.start.sub(s2.getPoint());
				double ang = rP.normalize().scalarProduct(v.normalize());

				if (Double.compare(ang, 0) < 0) {
					continue;
				}

				double coef = Math.pow(ang, s2.getKrn());
				colors[0] += ls.getR() * s2.getKrr() * coef;
				colors[1] += ls.getG() * s2.getKrg() * coef;
				colors[2] += ls.getB() * s2.getKrb() * coef;
			}
		}
	}

	/**
	 * This class implements {@link IRayTracerProducer} (multithread).
	 * 
	 * @author ivona
	 *
	 */
	private static class IRayTracerParallelProducer implements IRayTracerProducer {

		/**
		 * Width of screen
		 */
		private int width;

		/**
		 * Height of screen
		 */
		private int height;

		/**
		 * Horizontal width of observed space
		 */
		private double horizontal;

		/**
		 * Horizontal width of observed space
		 */
		private double vertical;

		/**
		 * The screen corner
		 */
		private Point3D screenCorner;

		/**
		 * X axis
		 */
		private Point3D xAxis;

		/**
		 * Y axis
		 */
		private Point3D yAxis;

		/**
		 * Position of observer
		 */
		private Point3D eye;

		/**
		 * Scene
		 */
		private Scene scene;

		/**
		 * Red color array
		 */
		private short[] red;

		/**
		 * Green color array
		 */
		private short[] green;

		/**
		 * Blue color array
		 */
		private short[] blue;

		/**
		 * Atomic cancel
		 */
		AtomicBoolean cancel;

		@Override
		public void produce(Point3D eye, Point3D view, Point3D viewUp, double horizontal, double vertical, int width,
				int height, long requestNo, IRayTracerResultObserver observer, AtomicBoolean cancel) {
			this.width = width;
			this.height = height;
			this.horizontal = horizontal;
			this.vertical = vertical;
			this.eye = eye;
			this.cancel = cancel;

			System.out.println("Započinjem izračune...");
			red = new short[width * height];
			green = new short[width * height];
			blue = new short[width * height];

			Point3D vuv = viewUp.normalize();
			Point3D eyeView = view.sub(eye).modifyNormalize();

			// zAxis not used
			yAxis = vuv.sub(eyeView.scalarMultiply(vuv.scalarProduct(eyeView))).normalize();
			xAxis = eyeView.vectorProduct(yAxis).normalize();

			screenCorner = view.sub(xAxis.scalarMultiply(horizontal / 2.0)).add(yAxis.scalarMultiply(vertical / 2.0));

			scene = RayTracerViewer.createPredefinedScene();

			ForkJoinPool pool = new ForkJoinPool();
			pool.invoke(new Action(eye, view, viewUp, horizontal, vertical, width, height, 0, height, red, green, blue,
					cancel));
			pool.shutdown();

			System.out.println("Izračuni gotovi...");
			observer.acceptResult(red, green, blue, requestNo);
			System.out.println("Dojava gotova...");
		}

	}
}
