package hr.fer.zemris.java.fractals;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

import hr.fer.zemris.java.fractals.viewer.FractalViewer;
import hr.fer.zemris.java.fractals.viewer.IFractalProducer;
import hr.fer.zemris.java.fractals.viewer.IFractalResultObserver;
import hr.fer.zemris.math.Complex;
import hr.fer.zemris.math.ComplexPolynomial;
import hr.fer.zemris.math.ComplexRootedPolynomial;

/**
 * This class is used to represent main program which asks user to enter roots
 * based on which Newton - Raphson fractal image will be display.
 * 
 * @author ivona
 *
 */
public class Newton {

	/**
	 * Number of available threads in processor
	 */
	static int numberOfThreads = Runtime.getRuntime().availableProcessors();

	/**
	 * This class represents IFractalProducer implementation. It is used for
	 * displaying fractals.
	 */
	private static class NewtonProducer implements IFractalProducer {

		/**
		 * Polynomial in rooted form
		 */
		private ComplexRootedPolynomial polynomialRooted;

		/**
		 * Polynomial in factor form
		 */
		private ComplexPolynomial polynomial;

		ExecutorService pool;

		/**
		 * Basic constructor
		 *
		 * @param polynomial Rooted polynomial
		 */
		public NewtonProducer(ComplexRootedPolynomial polynomial) {
			this.pool = Executors.newFixedThreadPool(numberOfThreads, r -> {
				Thread radnik = new Thread(r);
				radnik.setDaemon(true);
				return radnik;
			});

			this.polynomialRooted = polynomial;
			this.polynomial = polynomial.toComplexPolynom();
		}

		@Override
		public void produce(double reMin, double reMax, double imMin, double imMax, int width, int height,
				long requestNo, IFractalResultObserver observer, AtomicBoolean cancel) {

			/**
			 * List of results of parallelization calculation
			 */
			List<Future<Void>> results = new ArrayList<>();

			short[] data = new short[width * height];
			int numberOfTracks = 8 * numberOfThreads;
			int numberOfYByTrack = height / numberOfTracks;

			for (int i = 0; i < numberOfTracks; i++) {
				int yMin = i * numberOfYByTrack;
				int yMax = (i + 1) * numberOfYByTrack - 1;
				if (i == numberOfTracks - 1) {
					yMax = height - 1;
				}

				Callable<Void> posao = new NewtonJob(reMin, reMax, imMin, imMax, width, height, yMin, yMax, data,
						polynomial, polynomialRooted);
				results.add(pool.submit(posao));
			}

			for (Future<Void> result : results) {
				try {
					result.get();
				} catch (InterruptedException | ExecutionException e) {
					continue;
				}
			}
			System.out.println("Racunanje gotovo. Idem obavijestiti promatraca tj. GUI!");
			observer.acceptResult(data, (short) (polynomial.order() + 1), requestNo);

		}

	}

	/**
	 * This class represents NewtonJob. It is used for parallelization of
	 * calculation of fractals.
	 * 
	 * @author ivona
	 */
	private static class NewtonJob implements Callable<Void> {

		/**
		 * Minimum real value.
		 */
		private double reMin;

		/**
		 * Maximum real value.
		 */
		private double reMax;

		/**
		 * Minimum imaginary value.
		 */
		private double imMin;

		/**
		 * Maximum imaginary value.
		 */
		private double imMax;

		/**
		 * Width of screen.
		 */
		private int width;

		/**
		 * Height of screen.
		 */
		private int height;

		/**
		 * Minimum y value.
		 */
		private int yMin;

		/**
		 * Maximum y value.
		 */
		private int yMax;

		/**
		 * Array used for storing results.
		 */
		private short[] data;

		/**
		 * Polynomial in factor form
		 */
		private ComplexPolynomial polynomial;

		/**
		 * Polynomial in rooted form
		 */
		private ComplexRootedPolynomial polynomialRooted;

		/**
		 * Maximum number of iterations
		 */
		private int maxIter = 16 * 16 * 16;

		/**
		 * Treshold for convergence
		 */
		private double convergenceTreshold = 0.001;

		/**
		 * Treshold for distance from root
		 */
		private double rootTreshold = 0.002;

		/**
		 * Basic constructor
		 *
		 * @param reMin            minimum real value.
		 * @param reMax            maximum real value.
		 * @param imMin            minimum imaginary value.
		 * @param imMax            maximum imaginary value.
		 * @param width            width of screen.
		 * @param height           height of screen.
		 * @param yMin             minimum y value
		 * @param yMax             maximum y value
		 * @param data             data for storing results
		 * @param polynomial       polynomial in factor form
		 * @param polynomialRooted polynomial in rooted form
		 */
		public NewtonJob(double reMin, double reMax, double imMin, double imMax, int width, int height, int yMin,
				int yMax, short[] data, ComplexPolynomial polynomial, ComplexRootedPolynomial polynomialRooted) {
			this.reMin = reMin;
			this.reMax = reMax;
			this.imMin = imMin;
			this.imMax = imMax;
			this.width = width;
			this.height = height;
			this.yMin = yMin;
			this.yMax = yMax;
			this.data = data;
			this.polynomial = polynomial;
			this.polynomialRooted = polynomialRooted;
		}

		public Void call() throws Exception {
			for (int y = yMin; y <= yMax; y++) {
				for (int x = 0; x <= width; x++) {

					double re = (double) x / (width - 1) * (reMax - reMin) + reMin;
					double im = (double) (height - 1 - y) / (height - 1) * (imMax - imMin) + imMin;

					Complex zn = new Complex(re, im);

					int iter = 0;
					ComplexPolynomial derived = polynomial.derive();

					while (true) {
						Complex numerator = polynomial.apply(zn);
						Complex denominator = derived.apply(zn);
						Complex znold = zn;
						// zn = zn - f(zn)/f'(zn)
						zn = zn.sub(numerator.divide(denominator));
						double module = zn.sub(znold).module();
						iter++;
						if (module <= convergenceTreshold || iter > maxIter) {
							break;
						}

					}

					// lets find the closest root
					short index = (short) polynomialRooted.indexOfClosestRootFor(zn, rootTreshold);

					data[y * width + x] = (short) (index + 1);

				}
			}

			return null;

		}

	}

	/**
	 * Main method.
	 *
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {

		System.out.println("Welcome to Newton-Raphson iteration-based fractal viewer.\n"
				+ "Please enter at least two roots, one root per line. Enter 'done' when done.");

		int rootNumber = 0;
		Scanner sc = new Scanner(System.in);
		List<Complex> Roots = new ArrayList<>();

		while (true) {
			System.out.print("Root " + (rootNumber + 1) + " > ");
			String input = sc.nextLine().trim();
			if (input.equals("done")) {
				break;
			}
			try {
				Roots.add(Complex.parse(input));
			} catch (RuntimeException e) {
				System.out.println("Root isn't valid!");
				rootNumber--;
			}
			rootNumber++;
		}

		sc.close();
		if (Roots.size() == 0) {
			System.out.println("No roots entered!");
			System.exit(1);
		}

		ComplexRootedPolynomial polynomial = new ComplexRootedPolynomial(Roots);

		FractalViewer.show(new NewtonProducer(polynomial));
	}

}
