package hr.fer.zemris.java.raytracer;

import java.util.List;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.util.concurrent.atomic.AtomicBoolean;

import hr.fer.zemris.java.raytracer.model.GraphicalObject;
import hr.fer.zemris.java.raytracer.model.IRayTracerAnimator;
import hr.fer.zemris.java.raytracer.model.IRayTracerProducer;
import hr.fer.zemris.java.raytracer.model.IRayTracerResultObserver;
import hr.fer.zemris.java.raytracer.model.LightSource;
import hr.fer.zemris.java.raytracer.model.Point3D;
import hr.fer.zemris.java.raytracer.model.Ray;
import hr.fer.zemris.java.raytracer.model.RayIntersection;
import hr.fer.zemris.java.raytracer.model.Scene;
import hr.fer.zemris.java.raytracer.viewer.RayTracerViewer;

/**
 * This class is used for creating simple animation of user rotating around the
 * scene.
 * More precisely:
 * The interface IRayTracerAnimator represents object
 * which can provide a temporal information to GUI showing the scene. The GUI
 * will first ask this object how often it wants the scene to be redrawn. Then
 * it will call the object to inform it about amount of time elapsed since the
 * last update call, and then ask for information on the current user position,
 * where is user looking-at and where is “up”-direction. Based on the
 * information provided, a new rendering will be scheduled and the result shown.
 * By repeating this procedure periodically, we can create a simple animation of
 * user rotating around the scene and from time to time going up-down
 * 
 * @author ivona
 *
 */
public class RaycasterParallel2 {
	private static final double EPS = 1E-6;

	/**
	 * The main method
	 *
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		RayTracerViewer.show(getIRayTracerProducer(), getIRayTracerAnimator(), 30, 30);
	}

	private static IRayTracerAnimator getIRayTracerAnimator() {
		return new IRayTracerAnimator() {
			long time;

			@Override
			public void update(long deltaTime) {
				time += deltaTime;
			}

			@Override
			public Point3D getViewUp() { // fixed in time
				return new Point3D(0, 0, 10);
			}

			@Override
			public Point3D getView() { // fixed in time
				return new Point3D(-2, 0, -0.5);
			}

			@Override
			public long getTargetTimeFrameDuration() {
				return 150; // redraw scene each 150 milliseconds
			}

			@Override
			public Point3D getEye() { // changes in time
				double t = (double) time / 10000 * 2 * Math.PI;
				double t2 = (double) time / 5000 * 2 * Math.PI;
				double x = 50 * Math.cos(t);
				double y = 50 * Math.sin(t);
				double z = 30 * Math.sin(t2);
				return new Point3D(x, y, z);
			}

		};
	}

	/**
	 * This method is used to produce image using parallel algorithm.
	 *
	 * @return {@link IRayTracerProducer}
	 */
	private static IRayTracerProducer getIRayTracerProducer() {
		return new IRayTracerParallelProducer();
	}

	/**
	 * This class implements {@link IRayTracerProducer} (multithread).
	 * 
	 * @author ivona
	 *
	 */
	private static class IRayTracerParallelProducer implements IRayTracerProducer {

		/**
		 * Width of screen
		 */
		private int width;

		/**
		 * Height of screen
		 */
		private int height;

		/**
		 * Horizontal width of observed space
		 */
		private double horizontal;

		/**
		 * Horizontal width of observed space
		 */
		private double vertical;

		/**
		 * The screen corner
		 */
		private Point3D screenCorner;

		/**
		 * X axis
		 */
		private Point3D xAxis;

		/**
		 * Y axis
		 */
		private Point3D yAxis;

		/**
		 * Position of observer
		 */
		private Point3D eye;

		/**
		 * Scene
		 */
		private Scene scene;

		/**
		 * Red color array
		 */
		private short[] red;

		/**
		 * Green color array
		 */
		private short[] green;

		/**
		 * Blue color array
		 */
		private short[] blue;

		@Override
		public void produce(Point3D eye, Point3D view, Point3D viewUp, double horizontal, double vertical, int width,
				int height, long requestNo, IRayTracerResultObserver observer, AtomicBoolean arg) {
			this.width = width;
			this.height = height;
			this.horizontal = horizontal;
			this.vertical = vertical;
			this.eye = eye;

			System.out.println("Započinjem izračune...");
			red = new short[width * height];
			green = new short[width * height];
			blue = new short[width * height];

			Point3D vuv = viewUp.normalize();
			Point3D eyeView = view.sub(eye).modifyNormalize();

			// zAxis not used
			yAxis = vuv.sub(eyeView.scalarMultiply(vuv.scalarProduct(eyeView))).normalize();
			xAxis = eyeView.vectorProduct(yAxis).normalize();

			screenCorner = view.sub(xAxis.scalarMultiply(horizontal / 2.0)).add(yAxis.scalarMultiply(vertical / 2.0));

			scene = RayTracerViewer.createPredefinedScene2();

			ForkJoinPool pool = new ForkJoinPool();
			pool.invoke(new Action());
			pool.shutdown();

			System.out.println("Izračuni gotovi...");
			observer.acceptResult(red, green, blue, requestNo);
			System.out.println("Dojava gotova...");
		}

		/**
		 * The {@link RecursiveAction} called for each thread.
		 *
		 * @author ivona
		 * 
		 */
		private class Action extends RecursiveAction {

			/**
			 * The Constant serialVersionUID.
			 */
			private static final long serialVersionUID = 6795188588980589313L;

			/**
			 * Minimum y
			 */
			private int yMin;

			/**
			 * Maximum y
			 */
			private int yMax;

			/**
			 * The recursive threshold
			 */
			private final int THRESHOLD;

			/**
			 * Instantiates a new action for the whole scene
			 */
			public Action() {
				this(0, height);
			}

			/**
			 * Instantiates a new action with the given y bounds.
			 *
			 * @param yMin lower y bound
			 * @param yMax upper y bound
			 */
			public Action(int yMin, int yMax) {
				super();
				this.yMin = yMin;
				this.yMax = yMax;
				this.THRESHOLD = height / Runtime.getRuntime().availableProcessors();
			}

			@Override
			protected void compute() {
				int delta = yMax - yMin;
				if (delta <= THRESHOLD) {
					computeDirect();
					return;
				}

				int half = delta / 2;
				invokeAll(new Action(yMin, yMin + half), new Action(yMin + half, yMax));
			}

			/**
			 * Computes the color of points. Called when threshold is satisfied.
			 */
			private void computeDirect() {
				short[] rgb = new short[3];
				int offset = yMin * width;
				Point3D screenPoint;

				for (int y = yMin; y < yMax; y++) {
					for (int x = 0; x < width; x++) {
						screenPoint = screenCorner.add(xAxis.scalarMultiply(horizontal * x / (width - 1.0)))
								.sub(yAxis.scalarMultiply(vertical * y / (height - 1.0)));

						tracer(scene, Ray.fromPoints(eye, screenPoint), rgb);

						red[offset] = rgb[0] > 255 ? 255 : rgb[0];
						green[offset] = rgb[1] > 255 ? 255 : rgb[1];
						blue[offset] = rgb[2] > 255 ? 255 : rgb[2];

						offset++;
					}
				}
			}

		}
	}

	/**
	 * Tracer that determines the intersection of the ray and the closest object in
	 * the scene, and determines the colors for the point, if found.
	 *
	 * @param scene scene
	 * @param ray   ray
	 * @param rgb   rgb
	 */
	private static void tracer(Scene scene, Ray ray, short[] rgb) {
		// Default ambient light (R,G,B) = (15,15,15)
		double[] colors = { 15, 15, 15 };

		determineColorFor(scene, ray, colors, findClosestIntersection(scene, ray));

		rgb[0] = (short) colors[0];
		rgb[1] = (short) colors[1];
		rgb[2] = (short) colors[2];
	}

	/**
	 * Finds the closest intersection of the ray and the closest object in the
	 * scene.
	 *
	 * @param scene the scene
	 * @param ray   the ray
	 * @return the intersection
	 */
	private static RayIntersection findClosestIntersection(Scene scene, Ray ray) {
		RayIntersection closest = null;

		for (GraphicalObject s : scene.getObjects()) {
			RayIntersection local = s.findClosestRayIntersection(ray);

			if (local == null)
				continue;
			if (closest != null && closest.getDistance() < local.getDistance()) {
				continue;
			}

			closest = local;
		}

		return closest;
	}

	/**
	 * Determines the color (RGB) for the point of intersection of scene and ray.
	 *
	 * @param scene   scene
	 * @param ray     ray
	 * @param colors  colors
	 * @param s       intersection
	 */
	private static void determineColorFor(Scene scene, Ray ray, double[] colors, RayIntersection s) {
		if (s == null) {
			colors[0] = colors[1] = colors[2] = 0;
			return;
		}

		List<LightSource> lights = scene.getLights();

		for (LightSource ls : lights) {
			Point3D lightPoint = ls.getPoint();

			Ray r = Ray.fromPoints(lightPoint, s.getPoint());
			RayIntersection s2 = findClosestIntersection(scene, r);

			if (s2 == null)
				continue;

			if (lightPoint.sub(s2.getPoint()).norm() + EPS <= lightPoint.sub(s.getPoint()).norm()) {
				continue;
			}

			// diffusive component
			double lightNorm = lightPoint.sub(s2.getPoint()).normalize().scalarProduct(s2.getNormal());
			lightNorm = (lightNorm > 0) ? lightNorm : 0;

			colors[0] += ls.getR() * s2.getKdr() * lightNorm;
			colors[1] += ls.getG() * s2.getKdg() * lightNorm;
			colors[2] += ls.getB() * s2.getKdb() * lightNorm;

			// reflective component
			Point3D normal = s2.getNormal();
			Point3D l = lightPoint.sub(s2.getPoint());
			Point3D lightProjection = normal.scalarMultiply(l.scalarProduct(normal));

			Point3D rP = lightProjection.add(lightProjection.negate().add(l).scalarMultiply(-1));
			Point3D v = ray.start.sub(s2.getPoint());
			double ang = rP.normalize().scalarProduct(v.normalize());

			if (Double.compare(ang, 0) < 0) {
				continue;
			}

			double coef = Math.pow(ang, s2.getKrn());
			colors[0] += ls.getR() * s2.getKrr() * coef;
			colors[1] += ls.getG() * s2.getKrg() * coef;
			colors[2] += ls.getB() * s2.getKrb() * coef;
		}
	}
}