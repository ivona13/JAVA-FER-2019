package hr.fer.zemris.java;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * This class is used to represent console for searching articles.
 * 
 * @author ivona
 *
 */
public class Console {

	/**
	 * List of documents
	 */
	private static List<Document> documents = new ArrayList<>();

	/**
	 * Vocabulary set
	 */
	private static Set<String> vocabulary = new HashSet<>();

	/**
	 * List of stop words
	 */
	private static List<String> stopWords = new LinkedList<>();

	/**
	 * List of documnets which are results
	 */
	private static List<Document> resultDocuments = new ArrayList<>();

	/**
	 * Idf vector
	 */
	private static Map<String, Double> idf = new HashMap<>();

	/**
	 * Main method
	 * 
	 * @param args arguments of command line
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		if (args.length != 1) {
			System.out.println("No neccessary arguments provided.");
			return;
		}

		String path = args[0];

		documentAndStopwordsInitialize(path);

		/*
		 * for (int i = 0; i < documents.size(); i++) {
		 * System.out.println(documents.get(i).getPath() + " - " +
		 * documents.get(i).getTf().keySet().size()); }
		 * 
		 */

		vocabularyInitialize();

		System.out.println("Veličina rječnika je " + vocabulary.size() + ".");

		Scanner sc = new Scanner(System.in);

		while (true) {

			boolean exit = false;

			System.out.print("Enter command > ");

			String command = sc.nextLine();

			String[] in = command.split("\\s+");

			switch (in[0]) {
			case "query":
				executeQuery(in);
				break;

			case "type":
				if (resultDocuments.isEmpty()) {
					System.out.println("Nema rezultata.");
					continue;
				} else {
					if (in.length != 2) {
						System.out.println("Nepoznata naredba");
						continue;
					}

					if (Integer.parseInt(in[1]) < resultDocuments.size()) {
						System.out.println("----------------------------------------------------------------");
						Document wishedDocument = resultDocuments.get(Integer.parseInt(in[1]));
						System.out.println("----------------------------------------------------------------");
						for (String line : Files.readAllLines(wishedDocument.getPath())) {
							System.out.println(line);
						}
						System.out.println("----------------------------------------------------------------");
						System.out.println();

					} else {
						System.out.println("Type izvan dosega.");
					}
					break;
				}
			case "results":
				if (resultDocuments.isEmpty()) {
					System.out.println("Nema rezultata.");
					continue;
				}

				if (in.length != 1) {
					System.out.println("Nepoznata naredba.");
					continue;
				}
				for (int i = 0; i < resultDocuments.size(); i++) {
					System.out.printf("[ %d] (%.4f) %s\n", i, resultDocuments.get(i).getSimilarityToActive(),
							resultDocuments.get(i).getPath());
				}
				System.out.println();
				break;

			case "exit":
				if (in.length != 1) {
					System.out.println("Nepoznata naredba.");
					continue;
				}

				exit = true;
				break;
			default:
				System.out.println("Nepoznata naredba.");
				break;
			}

			if (exit) {
				sc.close();
				return;
			}
		}

	}

	/**
	 * This method is used for executing query given in console.
	 * 
	 * @param in input words
	 */
	private static void executeQuery(String[] in) {

		// lets make new document with this words and search for nearest

		List<String> lines = new ArrayList<String>();
		for (int i = 1; i < in.length; i++) {
			lines.add(in[i]);
		}

		Document active = new Document(lines, stopWords);

		System.out.println("Query is: " + active.getTf().keySet());
		System.out.println("Najboljih 10 rezultata: ");

		resultDocuments = getClosestDocuments(active);
		for (int i = 0; i < resultDocuments.size(); i++) {
			System.out.printf("[ %d] (%.4f) %s\n", i, resultDocuments.get(i).getSimilarityToActive(),
					resultDocuments.get(i).getPath());
		}
		System.out.println();

	}

	/**
	 * This method is used to give set of closest documents to out search.
	 * 
	 * @param active active document made of words of query
	 * @return list of closes documents
	 */
	private static List<Document> getClosestDocuments(Document active) {

		Vector tfIdf = new Vector();
		for (String word : vocabulary) {
			Integer tf = active.getTf().get(word);
			if (tf == null)
				tf = 0;
			Double idfV = idf.get(word);
			tfIdf.addComponent(tf * idfV);
		}
		active.setTfidf(tfIdf);

		List<Document> results = new ArrayList<>();

		for (Document doc : documents) {
			double similarity = doc.getTfidf().scalarProduct(active.getTfidf());
			// System.out.println(similarity);
			if (similarity > 0) {
				doc.setSimilarityToActive(similarity);
				results.add(doc);
			}
		}

		results.sort((o, v) -> (Double.compare(v.getSimilarityToActive(), o.getSimilarityToActive())));

		List<Document> topResults = new ArrayList<>();

		for (int i = 0; i < 10; i++) {
			if (i == results.size()) {
				break;
			}
			topResults.add(results.get(i));
		}

		return topResults;

	}

	/**
	 * This method is used for initalizing vocabulary.
	 */
	private static void vocabularyInitialize() {

		for (Document document : documents) {
			vocabulary.addAll(document.getTf().keySet());
		}

		// calculating idf
		for (String word : vocabulary) {
			int count = 0;

			for (Document document : documents)
				if (document.getTf().get(word) != null) {
					count++;
				}

			idf.put(word, Math.log((documents.size() + 0.0) / count));
		}

		for (Document document : documents) {
			Vector tfidf = new Vector();
			for (String word : vocabulary) {
				Integer value;

				if (document.getTf().get(word) == null) {
					value = 0;
				} else {
					value = document.getTf().get(word);
				}

				tfidf.addComponent(value * idf.get(word));
			}
			document.setTfidf(tfidf);
		}
	}

	/**
	 * This method is used for document initialization and stop words
	 * initialization.
	 * 
	 * @param path path to file
	 * @throws IOException IOException if error happen
	 */
	private static void documentAndStopwordsInitialize(String path) throws IOException {
		stopWords = Files.readAllLines(Paths.get("hrvatski_stoprijeci.txt"));

		Files.walkFileTree(Paths.get(path), new FileVisitor<>() {
			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
				documents.add(new Document(file, stopWords));
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) {
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult postVisitDirectory(Path dir, IOException exc) {
				return FileVisitResult.CONTINUE;
			}
		});
	}

}
