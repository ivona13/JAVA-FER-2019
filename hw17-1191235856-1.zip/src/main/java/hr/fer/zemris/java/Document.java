package hr.fer.zemris.java;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


/**
 * This class is used to represent Document which is an article in our base.
 * @author ivona
 *
 */
public class Document {

	/**
	 * Filter regex
	 */
	public static final String FILTER_REGEX = "[^\\p{L}]";

	/**
	 * Path to file
	 */
	Path path;

	/**
	 * TF map - string - integer
	 */
	private Map<String, Integer> tf = new LinkedHashMap<>();

	/**
	 * tfidf vector
	 */
	private Vector tfidf = new Vector();

	/**
	 * Similarity to active document or input query
	 */
	double similarityToActive = 0.0;

	/**
	 * Constructor
	 * @param path path
	 * @param stopWords list of stop words
	 */
	public Document(Path path, List<String> stopWords) {
		this.path = path;

		try {
			initializeTf(Files.readAllLines(this.path), stopWords);
		} catch (IOException e) {
			System.out.println("Could not read file.");
		}
	}

	/**
	 * Constructor
	 * @param input lines
	 * @param stopWords stop words
	 */
	public Document(List<String> input, List<String> stopWords) {
		initializeTf(input, stopWords);

	}

	/**
	 * This class is used for initalizing tf
	 * @param lines lines
	 * @param stopWords stop words
	 */
	private void initializeTf(List<String> lines, List<String> stopWords) {

		for (String line : lines) {
		
			String[] words = line.trim().split(FILTER_REGEX);

			for (String word : words) {
				word = word.trim();
				if (!word.isEmpty()  && !stopWords.contains(word.toLowerCase())) {

					Integer newValue;
					if (tf.get(word) == null) {
						newValue = 1;
					} else {
						newValue = tf.get(word.toLowerCase()) + 1;
					}

					tf.put(word.toLowerCase(), newValue);
				}
			}
		}

	}

	/**
	 * Tf setter
	 * @param tf
	 */
	public void setTf(Map<String, Integer> tf) {
		this.tf = tf;
	}

	/**
	 * Tfidf setter
	 * @param tfidf tfidf
	 */
	public void setTfidf(Vector tfidf) {
		this.tfidf = tfidf;
	}

	/**
	 * Similarity setter
	 * @param similarityToActive similarity
	 */
	public void setSimilarityToActive(double similarityToActive) {
		this.similarityToActive = similarityToActive;
	}

	/**
	 * Tf getter
	 * @return tf
	 */
	public Map<String, Integer> getTf() {
		return tf;
	}

	/**
	 * Tfidf getter
	 * @return tfidf
	 */
	public Vector getTfidf() {
		return tfidf;
	}

	/**
	 * Similarity getter
	 * @return smimilyrity
	 */
	public double getSimilarityToActive() {
		return similarityToActive;
	}

	/**
	 * Path getter
	 * @return pathF
	 */
	public Path getPath() {
		return path;
	}

}
