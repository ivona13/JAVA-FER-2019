package hr.fer.zemris.java;

import java.util.LinkedList;
import java.util.List;

/**
 * This class is used to represent vector
 * @author ivona
 *
 */
public class Vector {

	/**
	 * List of vectors components.
	 */
	private List<Double> components;

	/**
	 * Constructor
	 */
	public Vector() {
		components = new LinkedList<Double>();
	}

	/**
	 * This method is used for adding components
	 * @param component
	 */
	public void addComponent(Double component) {
		components.add(component);
	}

	/**
	 * This method is used for calculating scalar product
	 * @param vector vector
	 * @return scalar product
	 */
	public double scalarProduct(Vector vector) {

		List<Double> componentsOfVector = vector.getComponents();

		Double numerator = 0.0;
		Double norm1 = 0.0;
		Double norm2 = 0.0;

		for (int i = 0; i < components.size(); i++) {
			numerator += (components.get(i) * componentsOfVector.get(i));
			norm1 += Math.pow(components.get(i), 2);
			norm2 += Math.pow(componentsOfVector.get(i), 2);
		}

		return numerator / (Math.sqrt(norm1) * Math.sqrt(norm2));

	}

	/**
	 * Component setter
	 * @param components components
	 */
	public void setComponents(List<Double> components) {
		this.components = components;
	}

	/**
	 * Components getter
	 * @return components
	 */
	public List<Double> getComponents() {
		return components;
	}

	/**
	 * This method is used for calculating norm
	 * @return norm of vectorF
	 */
	public double norm() {
		double norm = 0.0;
		for (int i = 0; i < components.size(); i++) {
			norm += components.get(i) * components.get(i);
		}
		
		return norm;
	}
}
