package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Collator;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.Timer;

import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Document;
import javax.swing.text.TextAction;

import hr.fer.zemris.java.hw11.jnotepadpp.local.FormLocalizationProvider;
import hr.fer.zemris.java.hw11.jnotepadpp.local.ILocalizationListener;
import hr.fer.zemris.java.hw11.jnotepadpp.local.ILocalizationProvider;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LJMenu;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LocalizableAction;
import hr.fer.zemris.java.hw11.jnotepadpp.local.LocalizationProvider;

/**
 * This class is used to implement clasic Notepad. It has many functionalities,
 * such as: saving document, opening document, Copying and pasting text from the
 * document, Statistical infos, sorting lines, .. This notepad supports three
 * languages: English, Croatian, German. Any of this languages can be selected
 * from Menu.
 * 
 * @author ivona
 *
 */
public class JNotepadPP extends JFrame {

	/**
	 * Default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * {@link MultipleDocumentModel} model of this Notepad - it supports more
	 * {@link SingleDocumentModel}
	 */
	private MultipleDocumentModel model;

	/**
	 * {@link ILocalizationProvider} provider for languages
	 */
	private ILocalizationProvider provider;

	/**
	 * Length label
	 */
	private JLabel length = new JLabel();

	/**
	 * Info label
	 */
	private JLabel info = new JLabel();

	/**
	 * Time label
	 */
	private JLabel timeLabel = new JLabel();

	/**
	 * Data label
	 */
	private JLabel dateLabel = new JLabel();

	/**
	 * Action of creating new document
	 */
	private Action createNewDocument;

	/**
	 * Action of opening Document
	 */
	private Action openDocument;

	/**
	 * Action of saving document
	 */
	private Action saveDocument;

	/**
	 * Action of saving document under some name
	 */
	private Action saveAsDocument;

	/**
	 * Action of closing tab
	 */
	private Action closeTab;

	/**
	 * Action of cutting selected text
	 */
	private Action cutText;

	/**
	 * Action of copying text
	 */
	private Action copyText;

	/**
	 * Action of pasting copied text
	 */
	private Action pasteText;

	/**
	 * Action of showing statistics - information about characters
	 */
	private Action statistics;

	/**
	 * Action of exiting notepad
	 */
	private Action exit;

	/**
	 * Action of providing English language
	 */
	private Action toEngl;

	/**
	 * Action of providing Croatian language
	 */
	private Action toCro;

	/**
	 * Action of providing Deutsch language
	 */
	private Action toDeu;

	/**
	 * Action of putting text to upper case
	 */
	private Action upperCase;

	/**
	 * Action of putting text to lower case
	 */
	private Action lowerCase;

	/**
	 * Action of inverting case of selected text
	 */
	private Action invertCase;

	/**
	 * Action of ascending sort of the lines of selected text
	 */
	private Action ascendingSort;

	/**
	 * Action of descending sort of the lines of selected text
	 */
	private Action descendingSort;

	/**
	 * Action of removing all repeted lines
	 */
	private Action unique;

	/**
	 * Constructor
	 */
	public JNotepadPP() {
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exit.actionPerformed(null);
			}
		});
		setLocation(0, 0);
		setSize(1000, 500);
		this.provider = new FormLocalizationProvider(LocalizationProvider.getInstance(), this);
		TimerThread timerThread = new TimerThread(timeLabel);
		timerThread.start();
		initGUI();
	}

	/**
	 * Initializiting GUI
	 */
	private void initGUI() {
		DefaultMultipleDocumentModel multipleModel = new DefaultMultipleDocumentModel();
		Container cp = getContentPane();

		cp.setLayout(new BorderLayout());
		cp.add(multipleModel, BorderLayout.CENTER);
		this.model = multipleModel;

		this.model.createNewDocument();

		// beginning
		initializeActions();
		setActions();
		setMenus();
		setToolbars();

		JTextArea editor = this.model.getCurrentDocument().getTextComponent();

		editor.getCaret().addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				statusBarChanged();
			}
		});

		statusBarChanged();
		String path = "Untitled";

		SingleDocumentModel current = model.getCurrentDocument();
		if (current.getFilePath() != null) {
			path = current.getFilePath().getFileName().toString();
		}

		setTitle(path + " - JNotepad++");
		model.addMultipleDocumentListener(new MultipleDocumentListener() {
			@Override
			public void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel) {
				String path = "Untitled";
				if (currentModel.getFilePath() != null) {
					path = currentModel.getFilePath().getFileName().toString();
				}
				setTitle(path + " - JNotepad++");

				currentModel.getTextComponent().addCaretListener(e -> statusBarChanged());

				statusBarChanged();
			}

			@Override
			public void documentAdded(SingleDocumentModel model) {
			}

			@Override
			public void documentRemoved(SingleDocumentModel model) {
			}
		});

	}

	/**
	 * This method is used for putting accelerator and mnemonic keys to actions.
	 */
	private void setActions() {
		createNewDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control N"));
		createNewDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_N);

		openDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
		openDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);

		saveDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
		saveDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);

		saveAsDocument.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control W"));
		saveAsDocument.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_W);

		closeTab.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control D"));
		closeTab.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_D);

		cutText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control X"));
		cutText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_X);

		copyText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control C"));
		copyText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_C);

		pasteText.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control V"));
		pasteText.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_V);

		statistics.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control Q"));
		statistics.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_Q);

		exit.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E"));
		exit.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);

		toEngl.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control J"));
		toEngl.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_J);

		toCro.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control K"));
		toCro.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_K);

		toDeu.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control L"));
		toDeu.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_L);

		upperCase.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control U"));
		upperCase.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_U);
		upperCase.setEnabled(false);

		lowerCase.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control I"));
		lowerCase.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_I);
		lowerCase.setEnabled(false);

		invertCase.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control T"));
		invertCase.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_T);
		invertCase.setEnabled(false);

		ascendingSort.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control F"));
		ascendingSort.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_F);

		descendingSort.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control G"));
		descendingSort.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_G);

		unique.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control H"));
		unique.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_H);

	}

	/**
	 * This method is used for initializing actions of the Notepad
	 */
	private void initializeActions() {
		createNewDocument = new LocalizableAction("new", provider) {

			@Override
			public void actionPerformed(ActionEvent e) {
				model.createNewDocument();
				statusBarChanged();

			}
		};

		openDocument = new LocalizableAction("open", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.setDialogTitle("Open file");

				int returnVal = chooser.showOpenDialog(JNotepadPP.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = chooser.getSelectedFile();
					Path path = file.toPath();

					try {
						model.loadDocument(path);
					} catch (RuntimeException e1) {
						JOptionPane.showMessageDialog(JNotepadPP.this,
								"Error while loading file " + file.getAbsolutePath(), "Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
				statusBarChanged();
			}
		};

		saveDocument = new LocalizableAction("save", provider) {

			@Override
			public void actionPerformed(ActionEvent e) {
				// the same as saveAs
				if (model.getCurrentDocument().getFilePath() == null) {
					saveAsDocument.actionPerformed(e);
					return;
				}

				try {
					model.saveDocument(model.getCurrentDocument(), null);
				} catch (RuntimeException e1) {
					JOptionPane.showMessageDialog(JNotepadPP.this,
							"Error while saving file " + model.getCurrentDocument().getFilePath(), "Error",
							JOptionPane.ERROR_MESSAGE);
				}
				statusBarChanged();

			}
		};

		saveAsDocument = new LocalizableAction("saveas", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.setDialogTitle("Save document as ..");

				int returnVal = chooser.showSaveDialog(JNotepadPP.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					Path savePath = chooser.getSelectedFile().toPath();

					if (Files.exists(savePath)) {
						int answer = JOptionPane.showConfirmDialog(JNotepadPP.this,
								"File already exists. Do you want to overwrite it?", "Saving",
								JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
						if (answer == JOptionPane.NO_OPTION) {
							return;
						}
					}

					try {
						model.saveDocument(model.getCurrentDocument(), savePath);
						statusBarChanged();

					} catch (RuntimeException e1) {
						JOptionPane.showMessageDialog(JNotepadPP.this, "Error while saving to" + savePath, "Error",
								JOptionPane.ERROR_MESSAGE);
					}

					JOptionPane.showMessageDialog(JNotepadPP.this, "File saved.", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(JNotepadPP.this, "Nothing is saved.", "Warning",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		};

		closeTab = new LocalizableAction("closetab", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!model.getCurrentDocument().isModified()) {
					model.closeDocument(model.getCurrentDocument());
					return;
				}

				int answer = JOptionPane.showConfirmDialog(JNotepadPP.this,
						"File is modified. Are you sure you want to close the tab?", "Closing",
						JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
				if (answer == JOptionPane.YES_OPTION) {
					model.closeDocument(model.getCurrentDocument());
				}
				statusBarChanged();

			}
		};

		cutText = new LocalizableAction("cut", provider) {
			Action cutAction = new DefaultEditorKit.CutAction();

			@Override
			public void actionPerformed(ActionEvent e) {
				cutAction.actionPerformed(e);
				statusBarChanged();

			}
		};

		copyText = new LocalizableAction("copy", provider) {
			Action copyAction = new DefaultEditorKit.CopyAction();

			@Override
			public void actionPerformed(ActionEvent e) {
				copyAction.actionPerformed(e);
				statusBarChanged();

			}
		};

		pasteText = new LocalizableAction("paste", provider) {
			Action pasteAction = new DefaultEditorKit.PasteAction();

			@Override
			public void actionPerformed(ActionEvent e) {
				pasteAction.actionPerformed(e);
				statusBarChanged();

			}
		};

		statistics = new LocalizableAction("stats", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				String text = model.getCurrentDocument().getTextComponent().getText();

				int length = text.length();
				int nonBlankChar = text.replaceAll("\\s+", "").length();
				int lines = text.length() - text.replaceAll("\n", "").length() + 1;

				String message = "Your document has " + length + " characters, " + nonBlankChar
						+ " non-blank characters and " + lines + " lines";
				JOptionPane.showMessageDialog(JNotepadPP.this, message, "Statistic info",
						JOptionPane.INFORMATION_MESSAGE);
			}
		};

		exit = new LocalizableAction("exit", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < model.getNumberOfDocuments(); i++) {
					// unsaved changes, ask for saving
					if (model.getDocument(i).isModified()) {
						int answer = JOptionPane.showConfirmDialog(JNotepadPP.this,
								"File is motified. Are you sure you want to close the tab?", "Exit",
								JOptionPane.YES_NO_OPTION, JOptionPane.CANCEL_OPTION);

						if (answer == JOptionPane.YES_OPTION) {
							model.closeDocument(model.getDocument(i));
						} else {
							return;
						}
						statusBarChanged();

					}
				}

				dispose();

			}
		};

		toEngl = new LocalizableAction("en", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalizationProvider.getInstance().setLanguage("en");
				statusBarChanged();

			}
		};

		toCro = new LocalizableAction("hr", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalizationProvider.getInstance().setLanguage("hr");
				statusBarChanged();

			}
		};

		toDeu = new LocalizableAction("de", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalizationProvider.getInstance().setLanguage("de");
				statusBarChanged();

			}
		};

		upperCase = new LocalizableAction("upper", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				changeCase(model, "upper");
				statusBarChanged();
			}
		};

		lowerCase = new LocalizableAction("lower", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				changeCase(model, "lower");
				statusBarChanged();

			}
		};

		invertCase = new LocalizableAction("invert", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				changeCase(model, "invert");
				statusBarChanged();
			}
		};

		ascendingSort = new LocalizableAction("asc", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				sortByName(model, "ascending");
			}
		};

		descendingSort = new LocalizableAction("desc", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				sortByName(model, "descending");
			}
		};

		unique = new LocalizableAction("uniq", provider) {
			@Override
			public void actionPerformed(ActionEvent e) {
				removeDuplicates(model);
				statusBarChanged();

			}
		};

	}

	/**
	 * This method is used for setting MenuBar
	 */
	private void setMenus() {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new LJMenu("file", provider);

		fileMenu.add(new JMenuItem(createNewDocument));
		fileMenu.add(new JMenuItem(openDocument));
		fileMenu.add(new JMenuItem(saveDocument));
		fileMenu.add(new JMenuItem(saveAsDocument));

		fileMenu.add(new JMenuItem(closeTab));
		fileMenu.add(new JMenuItem(exit));
		menuBar.add(fileMenu);

		JMenu editMenu = new LJMenu("edit", provider);

		editMenu.add(new JMenuItem(cutText));
		editMenu.add(new JMenuItem(copyText));
		editMenu.add(new JMenuItem(pasteText));
		editMenu.add(new JMenuItem(statistics));

		JMenu languageMenu = new LJMenu("languages", provider);
		menuBar.add(languageMenu);

		languageMenu.add(new JMenuItem(toEngl));
		languageMenu.add(new JMenuItem(toCro));
		languageMenu.add(new JMenuItem(toDeu));

		JMenu toolsMenu = new LJMenu("tools", provider);
		menuBar.add(toolsMenu);

		JMenu changeCaseMenu = new LJMenu("case", provider);
		toolsMenu.add(changeCaseMenu);

		changeCaseMenu.add(new JMenuItem(upperCase));
		changeCaseMenu.add(new JMenuItem(lowerCase));
		changeCaseMenu.add(new JMenuItem(invertCase));

		JMenu sortMenu = new LJMenu("sort", provider);
		toolsMenu.add(sortMenu);

		sortMenu.add(new JMenuItem(ascendingSort));
		sortMenu.add(new JMenuItem(descendingSort));
		sortMenu.add(new JMenuItem(unique));

		menuBar.setVisible(true);
		this.setJMenuBar(menuBar);

	}

	/**
	 * This class is used for setting Tool Bar
	 */
	private void setToolbars() {
		JToolBar toolBar = new JToolBar(provider.getString("tools"));
		toolBar.setFloatable(true);

		toolBar.add(new JButton(createNewDocument));
		toolBar.add(new JButton(openDocument));
		toolBar.add(new JButton(saveDocument));
		toolBar.add(new JButton(saveAsDocument));
		toolBar.addSeparator();
		toolBar.add(new JButton(closeTab));
		toolBar.add(new JButton(exit));
		toolBar.addSeparator();
		toolBar.add(new JButton(cutText));
		toolBar.add(new JButton(copyText));
		toolBar.add(new JButton(pasteText));
		toolBar.add(new JButton(statistics));
		toolBar.addSeparator();

		this.getContentPane().add(toolBar, BorderLayout.PAGE_START);

		JToolBar status = new JToolBar(provider.getString("stats"));
		status.setVisible(true);
		status.setLayout(new BorderLayout());

		status.add(length, BorderLayout.WEST);
		status.add(info, BorderLayout.CENTER);
		status.add(timeLabel, BorderLayout.EAST);

		this.getContentPane().add(status, BorderLayout.PAGE_END);

	}

	/**
	 * This private method is auxiliary method. It is used for sorting selected
	 * lines inside the Document. Which kind of sort depends on input sortName
	 * 
	 * @param model    Documents where sorting will happen
	 * @param sortName Kind of sorting -> "descending" or "ascending"
	 */
	private void sortByName(MultipleDocumentModel model, String sortName) {
		JTextArea editor = model.getCurrentDocument().getTextComponent();
		Document document = editor.getDocument();

		int length = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
		int start = 0;
		if (length != 0) {
			start = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());
		}

		try {
			start = editor.getLineOfOffset(editor.getLineOfOffset(start));
			length = editor.getLineEndOffset(editor.getLineOfOffset(start + length));

			String text = document.getText(start, length - start);

			document.remove(start, length);
			if (sortName == "ascending") {
				document.insertString(start, sort(text, true), null);
			} else {
				document.insertString(start, sort(text, false), null);
			}

		} catch (BadLocationException e) {

		}

	}

	/**
	 * This method is auxiliary method in method called sortByName. Sort depends on
	 * current used language, so the Collator is used inside the sort.
	 * 
	 * @param text      Text to be sorted
	 * @param ascending <code>true</code> if sort is ascending, <code>false</code>
	 *                  otherwise
	 * @return Sorted String
	 */
	private String sort(String text, boolean ascending) {
		StringBuilder sb = new StringBuilder();
		Locale locale = new Locale(LocalizationProvider.getInstance().getCurrentLanguage());
		Collator collator = Collator.getInstance(locale);

		List<String> lines = new ArrayList<>(Arrays.asList(text.split("\\r?\\n")));
		if (ascending) {
			lines.sort(collator);
		} else {
			lines.sort(collator.reversed());
		}

		for (String line : lines) {
			sb.append(line + "\n");
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	/**
	 * This private method is used as auxiliary method to change case of selected
	 * text.
	 * 
	 * @param model      Document to do this changes of changing case
	 * @param caseString Sort of changing case -> it can be "upper", "lower", or
	 *                   "invert" (three sorts of changing case)
	 */
	private void changeCase(MultipleDocumentModel model, String caseString) {

		Document document = model.getCurrentDocument().getTextComponent().getDocument();

		JTextArea editor = model.getCurrentDocument().getTextComponent();
		int length = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
		int start = 0;
		if (length != 0) {
			start = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());
			try {

				String text = document.getText(start, length);
				String newText = "";

				if (caseString == "upper") {
					newText = text.toUpperCase();
				} else if (caseString == "lower") {
					newText = text.toLowerCase();
				} else if (caseString == "invert") {
					char[] oldSequence = text.toCharArray();
					for (char c : oldSequence) {
						if (Character.isUpperCase(c)) {
							newText += Character.toLowerCase(c);
						} else {
							newText += Character.toUpperCase(c);
						}
					}
				}

				document.remove(start, length);
				document.insertString(start, newText, null);
			} catch (BadLocationException e1) {
				System.out.println("Error while case action.");
			}
		}

	}

	/**
	 * This method is used as auxiliary method to remove duplicates in selected
	 * text. Only the first appearance of a line will be displayed - others will be
	 * removed.
	 * 
	 * @param model Document to do changes
	 */
	private void removeDuplicates(MultipleDocumentModel model) {
		JTextArea editor = model.getCurrentDocument().getTextComponent();
		Document document = editor.getDocument();

		int length = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
		int start = 0;
		if (length != 0) {
			start = Math.min(editor.getCaret().getDot(), editor.getCaret().getMark());

			try {
				start = editor.getLineOfOffset(editor.getLineOfOffset(start));
				length = editor.getLineEndOffset(editor.getLineOfOffset(start + length));

				String text = document.getText(start, length - start);

				Set<String> lines = new HashSet<String>();
				List<String> linesList = new ArrayList<String>(Arrays.asList(text.split("\\r?\\n")));

				document.remove(start, length);

				StringBuilder stringbuilder = new StringBuilder();

				for (String line : linesList) {
					if (!lines.contains(line)) {
						stringbuilder.append(line + "\n");
						lines.add(line);
					}
				}

				document.insertString(start, "\n" + stringbuilder.toString(), null);

			} catch (BadLocationException e) {

			}
		}

	}

	/**
	 * This method is used to represent changes on status Bar. Changes on status bar
	 * happen every time we enter some character to the current document. There are
	 * displayed some information, as: current line, current column, number of
	 * selected characters. In this method, some actions may be disabled - these
	 * are: upperCase, loweCase, invertCase (if there is no selected text). Inside
	 * method, this condition of equality of getCaret().getDot() and
	 * getCarent.getMark() is checked. If they are equal, there actions can not be
	 * chosen.
	 * 
	 */
	private void statusBarChanged() {
		JTextArea editor = this.model.getCurrentDocument().getTextComponent();

		boolean imaSelekcije = editor.getCaret().getDot() != editor.getCaret().getMark();
		upperCase.setEnabled(imaSelekcije);
		lowerCase.setEnabled(imaSelekcije);
		invertCase.setEnabled(imaSelekcije);

		this.length.setText(String.format("%s: %d", this.provider.getString("length"), editor.getText().length()));
		try {
			int currentLine = editor.getLineOfOffset(editor.getCaretPosition());
			int currentColumn = editor.getCaretPosition() - editor.getLineStartOffset(currentLine);
			int selected = Math.abs(editor.getCaret().getDot() - editor.getCaret().getMark());
			info.setText(String.format("    %s:%d %s:%d %s:%d", provider.getString("ln"), currentLine + 1,
					provider.getString("col"), currentColumn + 1, provider.getString("sel"), selected));

		} catch (BadLocationException ignored) {
		}

	}

	/**
	 * Main method
	 * 
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new JNotepadPP().setVisible(true));
	}

	/**
	 * This class is used as auxiliary class to represent time to the status bar.
	 * This thread sets dateLabel and timeLabel based on current time which is
	 * needed above.
	 * 
	 * @author ivona
	 *
	 */
	public class TimerThread extends Thread {

		/**
		 * Running flag
		 */
		protected boolean isRunning;

		/**
		 * Data Label used for recording current date
		 */
		protected JLabel dateLabel;

		/**
		 * Time label used for recording current time
		 */
		protected JLabel timeLabel;

		/**
		 * Date format
		 */
		protected SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/d ");

		/**
		 * Time format
		 */
		protected SimpleDateFormat timeFormat = new SimpleDateFormat("h:mm:ss");

		/**
		 * Constructor
		 * 
		 * @param dateLabel dataLabel
		 */
		public TimerThread(JLabel dateLabel) {
			this.dateLabel = dateLabel;
			this.isRunning = true;
		}

		@Override
		public void run() {
			while (isRunning) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						Calendar currentCalendar = Calendar.getInstance();
						Date currentTime = currentCalendar.getTime();
						dateLabel.setText(dateFormat.format(currentTime) + timeFormat.format(currentTime));
					}
				});

				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
				}
			}
		}

		/**
		 * Runninf setter
		 * 
		 * @param isRunning
		 */
		public void setRunning(boolean isRunning) {
			this.isRunning = isRunning;
		}

	}

}