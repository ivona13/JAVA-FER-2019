package hr.fer.zemris.java.hw11.jnotepadpp;

import java.nio.file.Path;

/**
 * This interface is used to represent {@link MultipleDocumentModel}. It is
 * collection of {@link SingleDocumentModel} with one
 * {@link SingleDocumentModel} outstanding - current {@link SingleDocumentModel}
 * 
 * @author ivona
 *
 */
public interface MultipleDocumentModel {

	/**
	 * This method is used to create new Document
	 * 
	 * @return New created document
	 */
	SingleDocumentModel createNewDocument();

	/**
	 * This method is used to get current document
	 * 
	 * @return Current document
	 */
	SingleDocumentModel getCurrentDocument();

	/**
	 * This method is used to load document whose path is input path.
	 * 
	 * @param path Path of the document
	 * @return document
	 */
	SingleDocumentModel loadDocument(Path path);

	/**
	 * This method is used to save document to the path.
	 * 
	 * @param model   Document to be saved
	 * @param newPath Path to be saved to
	 */
	void saveDocument(SingleDocumentModel model, Path newPath);

	/**
	 * This method is used for closing {@link SingleDocumentModel}
	 * 
	 * @param model Document to be closed
	 */
	void closeDocument(SingleDocumentModel model);

	/**
	 * This method is used for adding listener to this model.
	 * 
	 * @param l Listener to be added
	 */
	void addMultipleDocumentListener(MultipleDocumentListener l);

	/**
	 * This method is used for removing listener of this model
	 * 
	 * @param l Listener to be removed
	 */
	void removeMultipleDocumentListener(MultipleDocumentListener l);

	/**
	 * This method is used to return number of documents in
	 * {@link MultipleDocumentModel}
	 * 
	 * @return number of documents
	 */
	int getNumberOfDocuments();

	/**
	 * This method is used for getting document at the index.
	 * 
	 * @param index index of document
	 * @return Document at the index
	 */
	SingleDocumentModel getDocument(int index);
}
