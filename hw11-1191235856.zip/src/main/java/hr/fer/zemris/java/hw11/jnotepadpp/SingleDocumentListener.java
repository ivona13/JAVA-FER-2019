package hr.fer.zemris.java.hw11.jnotepadpp;

/**
 * This interface is used for representing listener for
 * {@link SingleDocumentModel}
 * 
 * @author ivona
 *
 */
public interface SingleDocumentListener {

	/**
	 * This method is used to note that some modification happened on the model.
	 * 
	 * @param model Model
	 */
	void documentModifyStatusUpdated(SingleDocumentModel model);

	/**
	 * This method is used to note that path of model has been updated.
	 * 
	 * @param model Model whose file will be updated
	 */
	void documentFilePathUpdated(SingleDocumentModel model);
}
