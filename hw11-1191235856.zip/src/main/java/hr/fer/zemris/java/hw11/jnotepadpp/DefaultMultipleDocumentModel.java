package hr.fer.zemris.java.hw11.jnotepadpp;

import java.awt.BorderLayout;
import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * This class represents default implementation of
 * {@link MultipleDocumentModel}.
 * 
 * @author ivona
 *
 */
public class DefaultMultipleDocumentModel extends JTabbedPane implements MultipleDocumentModel {

	/**
	 * Default serialVersion
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * List of documents
	 */
	private List<SingleDocumentModel> documents = new ArrayList<>();

	/**
	 * Current opened document
	 */
	SingleDocumentModel currentDocument;

	/**
	 * List of listeners
	 */
	private List<MultipleDocumentListener> listeners = new ArrayList<>();

	/**
	 * Basic constructor
	 */
	public DefaultMultipleDocumentModel() {
		addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				SingleDocumentModel oldDocument = currentDocument;
				currentDocument = documents.get(getSelectedIndex());
				notifyListenersCurrentDocument(oldDocument, currentDocument);
			}
		});
	}

	/**
	 * This method is used for notifying listeners that current document has
	 * changed.
	 * 
	 * @param oldDocumentModel  old current model
	 * @param currDocumentModel new current model
	 */
	private void notifyListenersCurrentDocument(SingleDocumentModel oldDocumentModel,
			SingleDocumentModel currDocumentModel) {
		for (MultipleDocumentListener listener : listeners) {
			listener.currentDocumentChanged(oldDocumentModel, currDocumentModel);
		}
	}

	@Override
	public SingleDocumentModel createNewDocument() {

		try {
			return addNewDocument(null, "");
		} catch (IOException e) {
			System.out.println("Error while creating document.");
		}
		return null;
	}

	@Override
	public SingleDocumentModel getCurrentDocument() {

		return currentDocument;
	}

	@Override
	public SingleDocumentModel loadDocument(Path path) {

		if (path == null) {
			System.out.println("Path can not be null");
			return null;
		}

		// insert new Document
		if (!Files.isReadable(path)) {
			System.out.println("File is not readable.");
			return null;
		}

		byte[] bytes = null;

		try {

			bytes = Files.readAllBytes(path);
		} catch (IOException e) {
			System.out.println("PRoblems with reading file");

		}
		try {

			SingleDocumentModel newDocument = addNewDocument(path, new String(bytes, StandardCharsets.UTF_8));
			setIconAt(documents.indexOf(newDocument), new ImageIcon("redDisk.png"));

			return newDocument;

		} catch (IOException e) {
			System.out.println("Could not load document");
		}
		return null;

	}

	/**
	 * This method is used for adding new document to the list of documents.
	 * 
	 * @param path Path of new document
	 * @param text Text of document
	 * @return new created document
	 * @throws IOException if error happened during setting icon
	 */
	private SingleDocumentModel addNewDocument(Path path, String text) throws IOException {
		SingleDocumentModel newDocument = new DefaultSingleDocumentModel(path, text);

		documents.add(newDocument);
		notifyListenersAdded(newDocument);
		newDocument.addSingleDocumentListener(new SingleDocumentListener() {

			@Override
			public void documentModifyStatusUpdated(SingleDocumentModel model) {
				try {
					changeIcon(model);
				} catch (IOException e) {
					System.out.println("Invalid set of icon image.");
				}

			}

			@Override
			public void documentFilePathUpdated(SingleDocumentModel model) {
				changePath(model);
			}
		});

		addToPane(newDocument);
		return newDocument;

	}

	/**
	 * This method is used for adding document to the pane.
	 * 
	 * @param model model
	 * @throws IOException if error happened during getting icon
	 */
	private void addToPane(SingleDocumentModel model) throws IOException {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());

		panel.add(new JScrollPane(model.getTextComponent()), BorderLayout.CENTER);

		String fileName = "";
		String absolutePath = "";

		if (model.getFilePath() != null) {
			fileName = model.getFilePath().getFileName().toString();
			absolutePath = model.getFilePath().toAbsolutePath().toString();
		}

		addTab(fileName, getIcon("greenDisk.png"), panel, absolutePath);

	}

	/**
	 * This method is used for changing icon depending of the state of current
	 * document. If document has modified without saving, icon will be redDisk.png,
	 * otherwise greenDisk.png
	 * 
	 * @param model model
	 * @throws IOException if error happened druing getting icon
	 */
	public void changeIcon(SingleDocumentModel model) throws IOException {
		if (model.isModified()) {
			setIconAt(documents.indexOf(model), getIcon("redDisk.png"));
		} else {
			setIconAt(documents.indexOf(model), getIcon("greenDisk.png"));
		}
	}

	/**
	 * This method is used for getting icon from the image with the name given in
	 * input.
	 * 
	 * @param name name of file
	 * @return ImageIcon
	 * @throws IOException if error happened during reading file
	 */
	public ImageIcon getIcon(String name) throws IOException {
		InputStream is = this.getClass().getResourceAsStream("icons/" + name);
		if (is == null) {
			throw new RuntimeException("Icon does not exist");
		}

		byte[] bytes = is.readAllBytes();

		is.close();

		Image img = new ImageIcon(bytes).getImage();
		Image newImg = img.getScaledInstance(15, 15, Image.SCALE_SMOOTH);
		return new ImageIcon(newImg);

	}

	/**
	 * This method is used for changing path of single document model
	 * 
	 * @param model model
	 */
	private void changePath(SingleDocumentModel model) {
		setTitleAt(documents.indexOf(model), model.getFilePath().getFileName().toString());
		setToolTipTextAt(documents.indexOf(model), model.getFilePath().toString());
	}

	/**
	 * This method is used for notifying Listeners that new documents has been added
	 * to the list of documents.
	 * 
	 * @param newDocument
	 */
	private void notifyListenersAdded(SingleDocumentModel newDocument) {
		for (MultipleDocumentListener listener : listeners) {
			listener.documentAdded(newDocument);
		}
	}

	@Override
	public void saveDocument(SingleDocumentModel model, Path newPath) {
		for (SingleDocumentModel document : documents) {
			if (document.equals(model)) {
				continue;
			}

			if (document.getFilePath() != null && document.getFilePath().equals(newPath) && !document.equals(model)) {
				throw new RuntimeException("File is already opened!");
			}
		}

		byte[] bytes = model.getTextComponent().getText().getBytes(StandardCharsets.UTF_8);

		if (newPath == null) {
			newPath = model.getFilePath();
		} else {
			currentDocument.setFilePath(newPath);
		}

		try {
			Files.write(newPath, bytes);
		} catch (IOException e1) {
			throw new RuntimeException("Error while writing to file!");
		}

		currentDocument.setModified(false);
	}

	@Override
	public void closeDocument(SingleDocumentModel model) {

		// only one document in tab; after removing, trivial one will be opened
		if (documents.size() == 1) {
			createNewDocument();
		}

		int indexOfDocument = documents.indexOf(model);
		int newFocused = indexOfDocument - 1;
		if (newFocused < 0) {
			newFocused = 0;
		}

		removeTabAt(indexOfDocument);
		setSelectedIndex(newFocused);
		documents.remove(model);
		currentDocument = documents.get(newFocused);
		notifyRemoved(model);

	}

	private void notifyRemoved(SingleDocumentModel model) {
		for (MultipleDocumentListener listener : listeners) {
			listener.documentRemoved(model);
		}

	}

	@Override
	public void addMultipleDocumentListener(MultipleDocumentListener l) {
		listeners.add(l);
	}

	@Override
	public void removeMultipleDocumentListener(MultipleDocumentListener l) {
		listeners.remove(l);
	}

	@Override
	public int getNumberOfDocuments() {
		return documents.size();
	}

	@Override
	public SingleDocumentModel getDocument(int index) {
		return documents.get(index);
	}

}
