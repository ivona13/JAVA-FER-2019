package hr.fer.zemris.java.hw11.jnotepadpp.local;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * This class is used to represent Localization Provider for language.
 * 
 * @author ivona
 *
 */
public class LocalizationProvider extends AbstractLocalizationProvider {

	/**
	 * Current language
	 */
	private String language;

	/**
	 * Resource bundle for language translation
	 */
	private ResourceBundle bundle;

	/**
	 * Instance of {@link LocalizationProvider}
	 */
	private static LocalizationProvider instance = new LocalizationProvider();

	/**
	 * Basic constructor
	 */
	public LocalizationProvider() {
		this.language = "en";
		setBundle();
	}

	/**
	 * This method is used for setting resource bundle.
	 */
	private void setBundle() {
		Locale locale = Locale.forLanguageTag(this.language);
		this.bundle = ResourceBundle.getBundle("hr.fer.zemris.java.hw11.jnotepadpp.local.prijevodi", locale);

	}

	/**
	 * {@link LocalizationProvider} instance getter
	 * 
	 * @return
	 */
	public static LocalizationProvider getInstance() {

		return instance;
	}

	/**
	 * Current provider's language setter
	 * 
	 * @param language Language to be set
	 */
	public void setLanguage(String language) {
		this.language = language;
		setBundle();
		fire();
	}

	@Override
	public String getString(String key) {
		return this.bundle.getString(key);
	}

	@Override
	public String getCurrentLanguage() {
		return this.language;
	}

}
