package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * This interface is used to represent listener for
 * {@link ILocalizationProvider}.
 * 
 * @author ivona
 *
 */
public interface ILocalizationListener {

	/**
	 * This method is used to note that localization change has happened.
	 */
	public void localizationChanged();
}
