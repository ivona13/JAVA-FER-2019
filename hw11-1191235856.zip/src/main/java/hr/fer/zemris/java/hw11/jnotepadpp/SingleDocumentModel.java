package hr.fer.zemris.java.hw11.jnotepadpp;

import java.nio.file.Path;

import javax.swing.JTextArea;

/**
 * This interface is used to represent {@link SingleDocumentModel}. It
 * represents one document in {@link MultipleDocumentModel}
 * 
 * @author ivona
 *
 */
public interface SingleDocumentModel {

	/**
	 * This method is used for getting {@link JTextArea} for writing text into this
	 * model
	 * 
	 * @return {@link JTextArea}
	 */
	JTextArea getTextComponent();

	/**
	 * This method is used for getting file path
	 * 
	 * @return file path
	 */
	Path getFilePath();

	/**
	 * This method is used for setting file path
	 * 
	 * @param path path to be set
	 */
	void setFilePath(Path path);

	/**
	 * This method is used to give information about modification of the model.
	 * 
	 * @return <code>true</code> if document has been modificated;
	 *         <code>false</code> otherwise
	 */
	boolean isModified();

	/**
	 * This method is used as setter for modification flag.
	 * 
	 * @param modified
	 */
	void setModified(boolean modified);

	/**
	 * This method is used for adding listener to {@link SingleDocumentModel}
	 * 
	 * @param l Listener to be added to the list of listeners
	 */
	void addSingleDocumentListener(SingleDocumentListener l);

	/**
	 * This method is used for removing listener of the list of listeners of
	 * {@link SingleDocumentModel}
	 * 
	 * @param l Listener to be removed from the list
	 */
	void removeSingleDocumentListener(SingleDocumentListener l);
}
