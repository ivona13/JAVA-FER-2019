package hr.fer.zemris.java.hw11.jnotepadpp.local;

import javax.swing.AbstractAction;

/**
 * This class is used to represent localized {@link AbstractAction}
 * 
 * @author ivona
 *
 */
public abstract class LocalizableAction extends AbstractAction {

	/**
	 * Default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Key name of the action
	 */
	private String key;

	/**
	 * Listener for action
	 */
	private ILocalizationListener listener;

	/**
	 * Provider for language
	 */
	private ILocalizationProvider provider;

	/**
	 * Constructor
	 * 
	 * @param key      key name of the action
	 * @param provider provider
	 */
	public LocalizableAction(String key, ILocalizationProvider provider) {
		this.provider = provider;
		this.key = key;
		this.listener = this::update;
		update();
		this.provider.addLocalizationListener(this.listener);

	}

	/**
	 * This method is used for updating name of the action based on current
	 * language.
	 */
	private void update() {
		putValue(NAME, provider.getString(key));
	}

}
