package hr.fer.zemris.java.hw11.jnotepadpp;

/**
 * This interface is used to represent listener of {@link MultipleDocumentModel}
 * 
 * @author ivona
 *
 */
public interface MultipleDocumentListener {

	/**
	 * This method is used to note that current document has changed.
	 * 
	 * @param previousModel Previous current document
	 * @param currentModel  Future current document
	 */
	void currentDocumentChanged(SingleDocumentModel previousModel, SingleDocumentModel currentModel);

	/**
	 * This method is used to note that new document has been added.
	 * 
	 * @param model Model to be added
	 */
	void documentAdded(SingleDocumentModel model);

	/**
	 * This method is used to note that model has been removed from the list of
	 * models.
	 * 
	 * @param model Model to be removed
	 */
	void documentRemoved(SingleDocumentModel model);
}
