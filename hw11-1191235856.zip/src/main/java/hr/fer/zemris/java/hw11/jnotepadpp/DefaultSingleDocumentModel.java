package hr.fer.zemris.java.hw11.jnotepadpp;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * This class is used to implement {@link SingleDocumentModel}.
 * 
 * @author ivona
 *
 */
public class DefaultSingleDocumentModel implements SingleDocumentModel {

	/**
	 * Text area for writing content
	 */
	private JTextArea textArea;

	/**
	 * File path
	 */
	private Path filePath;

	/**
	 * Flag that informs about apperance of modification
	 */
	private boolean modified = false;

	/**
	 * List of listeners
	 */
	private List<SingleDocumentListener> listeners = new ArrayList<>();

	/**
	 * Constructor
	 * 
	 * @param filePath filePath of model
	 * @param text     text of model
	 */
	public DefaultSingleDocumentModel(Path filePath, String text) {
		this.filePath = filePath;
		this.textArea = new JTextArea(text);

		this.textArea.getDocument().addDocumentListener(new DocumentListener() {
			@Override
			public void removeUpdate(DocumentEvent e) {
				modified = true;
				notifyListenersStatus();
			}

			@Override
			public void insertUpdate(DocumentEvent e) {
				modified = true;
				notifyListenersStatus();
			}

			@Override
			public void changedUpdate(DocumentEvent e) {
				modified = true;
				notifyListenersStatus();
			}

		});

	}

	/**
	 * This method is used for notifying all listeners that modification has
	 * happened.
	 */
	private void notifyListenersStatus() {
		for (SingleDocumentListener listener : listeners) {
			listener.documentModifyStatusUpdated(this);
		}
	}

	/**
	 * This method is used for notifying all listeners that file path of model has
	 * changed.
	 */
	private void notifyListenersPath() {
		for (SingleDocumentListener listener : listeners) {
			listener.documentFilePathUpdated(this);
		}
	}

	@Override
	public JTextArea getTextComponent() {
		return textArea;
	}

	@Override
	public Path getFilePath() {
		return filePath;
	}

	@Override
	public void setFilePath(Path path) {
		if (path == null) {
			System.out.println("Path can not be null.");
			return;
		}

		this.filePath = path;
		notifyListenersPath();
	}

	@Override
	public boolean isModified() {
		return modified;
	}

	@Override
	public void setModified(boolean modified) {
		this.modified = modified;
		notifyListenersStatus();
	}

	@Override
	public void addSingleDocumentListener(SingleDocumentListener l) {
		listeners.add(l);
	}

	@Override
	public void removeSingleDocumentListener(SingleDocumentListener l) {
		listeners.remove(l);
	}

}
