package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * This class is used as bridge to {@link LocalizationProvider}.
 * 
 * @author ivona
 *
 */
public class LocalizationProviderBridge extends AbstractLocalizationProvider {

	/**
	 * Connected flag
	 */
	private boolean connected;

	/**
	 * {@link ILocalizationProvider} provider for language
	 */
	private ILocalizationProvider provider;

	/**
	 * Listener for {@link ILocalizationProvider}
	 */
	private ILocalizationListener listener;

	/**
	 * Constructor
	 * 
	 * @param provider Provider for language
	 */
	public LocalizationProviderBridge(ILocalizationProvider provider) {
		this.provider = provider;
		listener = this::fire;
	}

	@Override
	public String getString(String key) {
		return provider.getString(key);
	}

	/**
	 * This method is used to connect to provider. All listeners will be notified
	 * about connecting.
	 */
	public void connect() {
		if (!connected) {
			connected = true;
			provider.addLocalizationListener(listener);
		}

	}

	/**
	 * This method is used to disconnect from provider. All listeners will be
	 * notified about disconecting.
	 */
	public void disconnect() {
		provider.removeLocalizationListener(listener);
		connected = false;
		System.exit(0);
	}

	@Override
	public String getCurrentLanguage() {
		return provider.getCurrentLanguage();
	}

}
