package hr.fer.zemris.java.hw11.jnotepadpp.local;

import javax.swing.JMenu;

/**
 * This class is used to represent localizated {@link JMenu}
 * 
 * @author ivona
 *
 */
public class LJMenu extends JMenu {

	/**
	 * Default serialVersionUID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Listener of LJMenu
	 */
	private ILocalizationListener listener;

	/**
	 * Provider for language
	 */
	private ILocalizationProvider provider;

	/**
	 * Key name of the menu
	 */
	private String key;

	/**
	 * Constructor
	 * 
	 * @param key      key name of menu
	 * @param provider provider of language
	 */
	public LJMenu(String key, ILocalizationProvider provider) {
		super();
		this.provider = provider;
		this.key = key;
		this.listener = this::newText;
		newText();

		this.provider.addLocalizationListener(listener);

	}

	/**
	 * This method is used for setting text of the menu depending on provider's
	 * current language.
	 */
	private void newText() {
		setText(this.provider.getString(key));
	}

}
