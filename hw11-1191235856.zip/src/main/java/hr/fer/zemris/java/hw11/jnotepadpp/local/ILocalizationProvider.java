package hr.fer.zemris.java.hw11.jnotepadpp.local;

/**
 * This interface is used to represent provider for language.
 * 
 * @author ivona
 *
 */
public interface ILocalizationProvider {

	/**
	 * This method is used for adding listener to the provider.
	 * 
	 * @param listener Listener to be added
	 */
	public void addLocalizationListener(ILocalizationListener listener);

	/**
	 * This method is used to remove listener from provider's list of listeners.
	 * 
	 * @param listener Listener to be removed
	 */
	public void removeLocalizationListener(ILocalizationListener listener);

	/**
	 * This method is used to get String (Name) based on given key.
	 * 
	 * @param key Key of the word we want to get
	 * @return String
	 */
	public String getString(String key);

	/**
	 * This method is used to get current language of provider.
	 * 
	 * @return current language
	 */
	public String getCurrentLanguage();

}
