package hr.fer.zemris.java.hw17.jvdraw.drawing;

import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;
import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;
import hr.fer.zemris.java.hw17.jvdraw.objects.Line;

/**
 * This class is used to represent geometrical object visitor
 * 
 * @author ivona
 *
 */
public interface GeometricalObjectVisitor {

	/**
	 * This method is called when something has to happen with line.
	 * 
	 * @param line line
	 */
	public abstract void visit(Line line);

	/**
	 * This method is called when something has to happen with circle.
	 * 
	 * @param circle circle
	 */
	public abstract void visit(Circle circle);

	/**
	 * This method is called when something has to happen with filled circle
	 * 
	 * @param filledCircle filled circle
	 */
	public abstract void visit(FilledCircle filledCircle);
}