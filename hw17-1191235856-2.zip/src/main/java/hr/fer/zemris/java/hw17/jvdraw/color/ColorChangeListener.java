package hr.fer.zemris.java.hw17.jvdraw.color;

import java.awt.Color;

/**
 * This class is used as interface of Color change listener.
 * 
 * @author ivona
 *
 */
public interface ColorChangeListener {

	/**
	 * This method is used to change color of IColorProvider.
	 * 
	 * @param source   source to change color of
	 * @param oldColor old color
	 * @param newColor new color
	 */
	void newColorSelected(IColorProvider source, Color oldColor, Color newColor);
}
