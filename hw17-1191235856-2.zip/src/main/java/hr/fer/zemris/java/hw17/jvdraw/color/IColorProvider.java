package hr.fer.zemris.java.hw17.jvdraw.color;

import java.awt.Color;

/**
 * This class is used to represent color provider.
 * @author ivona
 *
 */
public interface IColorProvider {
	
	/**
	 * This method is used to get current color.
	 * @return current color
	 */
	public Color getCurrentColor();

	/**
	 * This method is used for adding Color Change listener.
	 * @param l listener
	 */
	public void addColorChangeListener(ColorChangeListener l);

	/**
	 * This method is used for removing color change listener.
	 * @param l listener to be removedF
	 */
	public void removeColorChangeListener(ColorChangeListener l);
}
