package hr.fer.zemris.java.hw17.jvdraw.util;

import java.awt.Color;
import java.awt.Point;

import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;
import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;
import hr.fer.zemris.java.hw17.jvdraw.objects.Line;

/**
 * This class is used as util class for parsing lines from documents. Based on
 * this document, some geometrical object has to be drawn.
 * 
 * @author ivona
 *
 */
public class Util {

	/**
	 * This method is used for parsing line content
	 * 
	 * @param line line
	 * @return Line based on this info
	 */
	public static Line parseLine(String line) {
		String[] args = line.split(" ");
		int sx = Integer.parseInt(args[1]);
		int sy = Integer.parseInt(args[2]);
		int ex = Integer.parseInt(args[3]);
		int ey = Integer.parseInt(args[4]);
		int r = Integer.parseInt(args[5]);
		int g = Integer.parseInt(args[6]);
		int b = Integer.parseInt(args[7]);

		return new Line(new Point(sx, sy), new Point(ex, ey), new Color(r, g, b));
	}

	/**
	 * This method is used for parsing circle content
	 * 
	 * @param circle circle
	 * @return Circle based on this info
	 */
	public static Circle parseCircle(String line) {

		String[] args = line.split(" ");

		int x = Integer.parseInt(args[1]);
		int y = Integer.parseInt(args[2]);
		int radius = Integer.parseInt(args[3]);
		int r = Integer.parseInt(args[4]);
		int g = Integer.parseInt(args[5]);
		int b = Integer.parseInt(args[6]);

		return new Circle(new Point(x, y), radius, new Color(r, g, b));
	}

	/**
	 * This method is used for parsing filled circle content
	 * 
	 * @param filledcircle filled circle
	 * @return filled circle based on this info
	 */
	public static FilledCircle parseFCircle(String line) {
		String[] args = line.split(" ");

		int x = Integer.parseInt(args[1]);
		int y = Integer.parseInt(args[2]);
		int radius = Integer.parseInt(args[3]);
		int r1 = Integer.parseInt(args[4]);
		int g1 = Integer.parseInt(args[5]);
		int b1 = Integer.parseInt(args[6]);
		int r2 = Integer.parseInt(args[7]);
		int g2 = Integer.parseInt(args[8]);
		int b2 = Integer.parseInt(args[9]);

		return new FilledCircle(new Point(x, y), radius, new Color(r1, g1, b1), new Color(r2, g2, b2));
	}

}
