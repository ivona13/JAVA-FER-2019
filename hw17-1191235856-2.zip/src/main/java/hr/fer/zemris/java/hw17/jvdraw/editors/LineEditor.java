package hr.fer.zemris.java.hw17.jvdraw.editors;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import hr.fer.zemris.java.hw17.jvdraw.objects.Line;

/**
 * This class is used to implement line editor.
 * 
 * @author ivona
 *
 */
public class LineEditor extends GeometricalObjectEditor {

	/**
	 * serail Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * JSpinner for x coord. of start
	 */
	private JSpinner startX;

	/**
	 * JSpinner for y coord. of start
	 */
	private JSpinner startY;

	/**
	 * JSpinner for x coord of end
	 */
	private JSpinner endX;

	/**
	 * JSpinner for y coord of end
	 */
	private JSpinner endY;

	/**
	 * JSpinner for green part of color
	 */
	private JSpinner gColor;

	/**
	 * Jspinner for red part of color
	 */
	private JSpinner rColor;

	/**
	 * JSpinner for blue part of color
	 */
	private JSpinner bColor;

	/**
	 * Line we edit
	 */
	private Line line;

	/**
	 * Constructor
	 * 
	 * @param line line
	 */
	public LineEditor(Line line) {
		this.line = line;
		this.setLayout(new BorderLayout());
		JPanel left = new JPanel(new GridLayout(3, 1));
		JPanel right = new JPanel(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);

		left.add(new JLabel("Start point (x,y): "));
		left.add(new JLabel("End point (x,y): "));
		left.add(new JLabel("Color (r,g,b): "));

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 0;
		startX = new JSpinner((SpinnerModel) new SpinnerNumberModel(line.getStart().x, 0, 2000, 1));
		right.add(startX, constraints);

		constraints.gridx = 1;
		constraints.gridy = 0;
		startY = new JSpinner(new SpinnerNumberModel(line.getStart().y, 0, 2000, 1));
		right.add(startY, constraints);

		constraints.gridx = 0;
		constraints.gridy = 1;
		endX = new JSpinner(new SpinnerNumberModel(line.getEnd().x, 0, 2000, 1));
		right.add(endX, constraints);

		constraints.gridx = 1;
		constraints.gridy = 1;
		endY = new JSpinner(new SpinnerNumberModel(line.getEnd().y, 0, 2000, 1));
		right.add(endY, constraints);

		constraints.gridx = 0;
		constraints.gridy = 2;
		rColor = new JSpinner(new SpinnerNumberModel(line.getColor().getRed(), 0, 255, 1));
		right.add(rColor, constraints);

		constraints.gridx = 1;
		constraints.gridy = 2;
		gColor = new JSpinner(new SpinnerNumberModel(line.getColor().getGreen(), 0, 255, 1));
		right.add(gColor, constraints);

		constraints.gridx = 2;
		constraints.gridy = 2;
		bColor = new JSpinner(new SpinnerNumberModel(line.getColor().getBlue(), 0, 255, 1));
		right.add(bColor, constraints);
	}

	@Override
	public void checkEditing() {
		// not neccessary to impelement since this JSpinner cares about it
	}

	@Override
	public void acceptEditing() {

		Point newStartPoint = new Point((Integer) startX.getValue(), (Integer) startY.getValue());
		line.setStart(newStartPoint);

		Point newEndPoint = new Point((Integer) endX.getValue(), (Integer) endY.getValue());
		line.setEnd(newEndPoint);

		Color newColor = new Color((Integer) rColor.getValue(), (Integer) bColor.getValue(),
				(Integer) gColor.getValue());
		line.setColor(newColor);
	}

}
