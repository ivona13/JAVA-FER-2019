package hr.fer.zemris.java.hw17.jvdraw.editors;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;

/**
 * This class is used to represent circle editor. It can edit selected circle
 * 
 * @author ivona
 *
 */
public class CircleEditor extends GeometricalObjectEditor {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * JSpinner of x - it enables setting x coordinate
	 */
	private JSpinner x;

	/**
	 * JSpinner of y - it enables setting y coordinate
	 */
	private JSpinner y;

	/**
	 * JSpinner of radius - it enables setting radius
	 */
	private JSpinner radius;

	/**
	 * JSpinner of green part of color
	 */
	private JSpinner gColor;

	/**
	 * JSpinner of red part of color
	 */
	private JSpinner rColor;

	/**
	 * Jspinner of blue part of color
	 */
	private JSpinner bColor;

	/**
	 * Circle that has been edited
	 */
	private Circle circle;

	/**
	 * Constructor
	 * 
	 * @param circle circle
	 */
	public CircleEditor(Circle circle) {
		this.circle = circle;

		this.setLayout(new BorderLayout());
		JPanel left = new JPanel(new GridLayout(3, 1));
		JPanel right = new JPanel(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);

		left.add(new JLabel("Center (x,y): "));
		left.add(new JLabel("Radius: "));
		left.add(new JLabel("Color (r,g,b): "));

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 0;
		x = new JSpinner(new SpinnerNumberModel(circle.getCenter().x, 0, 1500, 1));
		right.add(x, constraints);

		constraints.gridx = 1;
		constraints.gridy = 0;
		y = new JSpinner(new SpinnerNumberModel(circle.getCenter().y, 0, 1500, 1));
		right.add(y, constraints);

		constraints.gridx = 0;
		constraints.gridy = 1;
		radius = new JSpinner(new SpinnerNumberModel(circle.getRadius(), 1, 1000, 1));
		right.add(radius, constraints);

		constraints.gridx = 0;
		constraints.gridy = 2;
		rColor = new JSpinner(new SpinnerNumberModel(circle.getColor().getRed(), 0, 255, 1));
		right.add(rColor, constraints);

		constraints.gridx = 1;
		constraints.gridy = 2;
		gColor = new JSpinner(new SpinnerNumberModel(circle.getColor().getGreen(), 0, 255, 1));
		right.add(gColor, constraints);

		constraints.gridx = 2;
		constraints.gridy = 2;
		bColor = new JSpinner(new SpinnerNumberModel(circle.getColor().getBlue(), 0, 255, 1));
		right.add(bColor, constraints);
	}

	@Override
	public void checkEditing() {
		// this method is already done beacuse of our organizing editing object -
		// JSpinners

	}

	@Override
	public void acceptEditing() {
		Point newCenter = new Point((Integer) x.getValue(), (Integer) y.getValue());
		circle.setCenter(newCenter);
		circle.setRadius((Integer) radius.getValue());
		Color newColor = new Color((Integer) rColor.getValue(), (Integer) bColor.getValue(),
				(Integer) gColor.getValue());
		circle.setColor(newColor);
	}

}
