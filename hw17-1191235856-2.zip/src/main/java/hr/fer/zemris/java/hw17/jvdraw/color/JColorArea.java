package hr.fer.zemris.java.hw17.jvdraw.color;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JColorChooser;
import javax.swing.JComponent;

/**
 * This class is used to represent color area for choosing colors-
 * 
 * @author ivona
 *
 */
public class JColorArea extends JComponent implements IColorProvider {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Selected color
	 */
	Color selected;

	/**
	 * List of Color Change listeners
	 */
	private List<ColorChangeListener> listeners = new ArrayList<>();

	/**
	 * Constructor
	 * 
	 * @param selected selected color
	 */
	public JColorArea(Color selected) {

		this.selected = selected;

		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {

				Color newColor = JColorChooser.showDialog(JColorArea.this, "Choose a color:", selected);

				if (newColor != null) {
					setNewColor(newColor);
				}
			}

		});
	}

	/**
	 * This method is used to set new color as current.
	 * 
	 * @param newColor new color to be set
	 */
	private void setNewColor(Color newColor) {
		Color old = new Color(JColorArea.this.selected.getRGB());

		JColorArea.this.selected = newColor;
		notifyListeners(old, newColor);
		repaint();
	}

	/**
	 * This class is used to notify all listeners about changing colors.
	 * 
	 * @param old      old color
	 * @param newColor new set color
	 */
	private void notifyListeners(Color old, Color newColor) {

		for (ColorChangeListener listener : listeners) {
			listener.newColorSelected(this, old, newColor);
		}
	}

	@Override
	public Color getCurrentColor() {
		return selected;
	}

	@Override
	public void addColorChangeListener(ColorChangeListener l) {
		if (!listeners.contains(l)) {
			listeners.add(l);
		}
	}

	@Override
	public void removeColorChangeListener(ColorChangeListener l) {
		listeners.remove(l);
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(15, 15);
	}

	@Override
	public Dimension getMinimumSize() {
		return getPreferredSize();
	}

	@Override
	public Dimension getMaximumSize() {
		return getPreferredSize();
	}

	@Override
	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;

		Dimension dimenstion = getSize();

		Insets inset = getInsets();

		g2d.setColor(selected);
		g2d.fillRect(inset.left, inset.right, dimenstion.width, dimenstion.height);
	}

}
