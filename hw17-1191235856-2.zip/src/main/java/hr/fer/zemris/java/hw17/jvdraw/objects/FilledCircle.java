package hr.fer.zemris.java.hw17.jvdraw.objects;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw17.jvdraw.editors.FilledCircleEditor;
import hr.fer.zemris.java.hw17.jvdraw.editors.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectVisitor;

/**
 * This class is used to impelment filled circle.
 * 
 * @author ivona
 *
 */
public class FilledCircle extends GeometricalObject {

	/**
	 * List of circle's listeners
	 */
	private List<GeometricalObjectListener> listeners = new ArrayList<>();

	/**
	 * Center
	 */
	private Point center;

	/**
	 * Point on its edge
	 */
	private Point end;

	/**
	 * Rafius
	 */
	private int radius;

	/**
	 * Foreground color
	 */
	private Color fColor;

	/**
	 * Background color
	 */
	private Color bColor;

	/**
	 * Constructor
	 * 
	 * @param center center
	 * @param end    end
	 * @param fColor foreground color
	 * @param bColor background color
	 */
	public FilledCircle(Point center, Point end, Color fColor, Color bColor) {
		this.center = center;
		this.end = end;
		this.fColor = fColor;
		this.bColor = bColor;

		this.radius = (int) Math.sqrt(Math.pow(end.x - center.x, 2) + Math.pow(end.y - end.y, 2));

	}

	/**
	 * Construcotr
	 * 
	 * @param center center
	 * @param end    end
	 * @param fColor foreground color
	 * @param bColor background color
	 */
	public FilledCircle(Point center, int radius, Color fColor, Color bColor) {
		this.center = center;
		this.radius = radius;
		this.fColor = fColor;
		this.bColor = bColor;
	}

	@Override
	public void accept(GeometricalObjectVisitor v) {
		v.visit(this);
	}

	@Override
	public GeometricalObjectEditor createGeometricalObjectEditor() {
		return new FilledCircleEditor(this);
	}

	@Override
	public void addGeometricalObjectListener(GeometricalObjectListener l) {

		if (!listeners.contains(l)) {
			listeners.add(l);
		}
	}

	@Override
	public void removeGeometricalObjectListener(GeometricalObjectListener l) {
		listeners.remove(l);
	}

	/**
	 * Center getter
	 * 
	 * @return center
	 */
	public Point getCenter() {
		return center;
	}

	/**
	 * Center setter
	 * 
	 * @param center center
	 */
	public void setCenter(Point center) {
		this.center = center;
		notifyListeners();
	}

	/**
	 * End getter
	 */
	public Point getEnd() {
		return end;
	}

	/**
	 * End setter
	 * 
	 * @param end end
	 */
	public void setEnd(Point end) {
		this.end = end;
		notifyListeners();
	}

	/**
	 * Radius getter
	 * 
	 * @return radius
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * Radius setter
	 * 
	 * @param radius radius
	 */
	public void setRadius(int radius) {
		this.radius = radius;
		notifyListeners();
	}

	/**
	 * Foreground getter
	 * 
	 * @return foreground color
	 */
	public Color getfColor() {
		return fColor;
	}

	/**
	 * Foreground setter
	 * 
	 * @param fColor foegrund color
	 */
	public void setfColor(Color fColor) {
		this.fColor = fColor;
		notifyListeners();
	}

	/**
	 * Color getter
	 * 
	 * @return color
	 */
	public Color getbColor() {
		return bColor;

	}

	/**
	 * Color setter
	 * 
	 * @param bColor background color
	 */
	public void setbColor(Color bColor) {
		this.bColor = bColor;
		notifyListeners();
	}

	/**
	 * This method is used for notifying all listeners that object has changed.
	 */
	private void notifyListeners() {
		for (GeometricalObjectListener l : listeners) {
			l.geometricalObjectChanged(this);
		}
	}

	@Override
	public String toString() {
		return String.format("Filled Circle (%d, %d), %d, %s \n", center.x, center.y, radius,
				String.format("#%02x%02x%02x", fColor.getRed(), fColor.getGreen(), fColor.getBlue()));
	}

}
