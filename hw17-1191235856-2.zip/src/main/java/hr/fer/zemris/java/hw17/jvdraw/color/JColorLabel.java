package hr.fer.zemris.java.hw17.jvdraw.color;

import java.awt.Color;

import javax.swing.JLabel;

/**
 * This class is used to implement Color label used for giving information about
 * current set colors.
 * 
 * @author ivona
 *
 */
public class JColorLabel extends JLabel implements ColorChangeListener {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Foreground color provider
	 */
	private IColorProvider fColor;

	/**
	 * Background color provided
	 */
	private IColorProvider bColor;

	/**
	 * Constructor
	 * 
	 * @param fColor foreground color provider
	 * @param bColor background color provider
	 */
	public JColorLabel(IColorProvider fColor, IColorProvider bColor) {
		this.fColor = fColor;
		this.bColor = bColor;

		fColor.addColorChangeListener(this);
		bColor.addColorChangeListener(this);

		updateText();
	}

	@Override
	public void newColorSelected(IColorProvider source, Color oldColor, Color newColor) {

		updateText();

	}

	/**
	 * Foreground Color setter
	 * 
	 * @return foreground color
	 */
	public IColorProvider getfColor() {
		return fColor;
	}

	/**
	 * Background color setter
	 * 
	 * @return background color
	 */
	public IColorProvider getbColor() {
		return bColor;
	}

	/**
	 * This method is used for updating color label - each time color changes, it
	 * changes its content, giving information about current colors.F
	 */
	public void updateText() {
		Color currentF = fColor.getCurrentColor();
		Color currentB = bColor.getCurrentColor();
		setText("Foreground color: (" + currentF.getRed() + ", " + currentF.getGreen() + ", " + currentF.getBlue()
				+ "), background color: (" + currentB.getRed() + ", " + currentB.getGreen() + ", " + currentB.getBlue()
				+ ")");
	}

}
