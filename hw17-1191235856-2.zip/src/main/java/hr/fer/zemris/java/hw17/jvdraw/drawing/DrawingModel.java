package hr.fer.zemris.java.hw17.jvdraw.drawing;

import hr.fer.zemris.java.hw17.jvdraw.objects.GeometricalObject;
import hr.fer.zemris.java.hw17.jvdraw.objects.GeometricalObjectListener;

/**
 * This class is used to represent drawing model whose contents are geometric
 * objects.
 * 
 * @author ivona
 *
 */
public interface DrawingModel extends GeometricalObjectListener {

	/**
	 * Size getter
	 * 
	 * @return size
	 */
	public int getSize();

	/**
	 * Object getter
	 * 
	 * @param index index of object
	 * @return object
	 */
	public GeometricalObject getObject(int index);

	/**
	 * This method is used for adding object to list of model's geomtrical objects
	 * 
	 * @param object
	 */
	public void add(GeometricalObject object);

	/**
	 * This class is used for removing object from the list of geometrical objects.
	 * 
	 * @param object
	 */
	public void remove(GeometricalObject object);

	/**
	 * This method is used for changing order of objects in model
	 * 
	 * @param object object to change place
	 * @param offset offset
	 */
	public void changeOrder(GeometricalObject object, int offset);

	/**
	 * 
	 * This method is used for getting index of object
	 * 
	 * @param object object
	 * @return index
	 */
	public int indexOf(GeometricalObject object);

	/**
	 * This method is used for clearing drawing model.
	 */
	public void clear();

	/**
	 * This method is used to clearing modified flag.
	 */
	public void clearModifiedFlag();

	/**
	 * This method is used to give information about modifying model.
	 * 
	 * @return <code>true</code> if model has been changed, <code>false</code>
	 *         otherwise
	 */
	public boolean isModified();

	/**
	 * This method is used for adding drawing model listeners
	 * 
	 * @param l listener to be added
	 */
	public void addDrawingModelListener(DrawingModelListener l);

	/**
	 * This method is used for removing drawing model listener.
	 * 
	 * @param l listener to be removed
	 */
	public void removeDrawingModelListener(DrawingModelListener l);

}