package hr.fer.zemris.java.hw17.jvdraw.objects;

/**
 * This class is used as geometrical object visitor interface.
 * 
 * @author ivona
 *
 */
public interface GeometricalObjectVisitor {

	/**
	 * This method is used for visiting line.
	 * 
	 * @param line line to be visited
	 */
	public abstract void visit(Line line);

	/**
	 * This method is used for visiting circle
	 * 
	 * @param circle circle to be visited
	 */
	public abstract void visit(Circle circle);

	/**
	 * This method is used for visiting filled circle
	 * 
	 * @param filledCircle filled circle to be visited
	 */
	public abstract void visit(FilledCircle filledCircle);
}
