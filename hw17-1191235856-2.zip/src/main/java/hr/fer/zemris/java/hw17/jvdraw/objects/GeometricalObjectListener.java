package hr.fer.zemris.java.hw17.jvdraw.objects;

/**
 * This class is used as geometrical object listener.
 * 
 * @author ivona
 *
 */
public interface GeometricalObjectListener {

	/**
	 * This method is used for giving information about objects' change.
	 * 
	 * @param o
	 */
	public void geometricalObjectChanged(GeometricalObject o);
}
