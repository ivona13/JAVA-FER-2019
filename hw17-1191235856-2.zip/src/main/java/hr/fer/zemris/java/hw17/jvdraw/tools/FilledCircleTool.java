package hr.fer.zemris.java.hw17.jvdraw.tools;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;

import hr.fer.zemris.java.hw17.jvdraw.color.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;

/**
 * This class is used to implement filled circle tool
 * 
 * @author ivona
 *
 */
public class FilledCircleTool implements Tool {

	/**
	 * Graphics 2d
	 */
	Graphics2D g2d;

	/**
	 * Icolor providers
	 */
	private IColorProvider fprov, bprov;

	/**
	 * Start point
	 */
	private Point start;

	/**
	 * End point
	 */
	private Point end;

	/**
	 * First click flag
	 */
	private boolean firstClick = true;

	/**
	 * Filled circle
	 */
	private FilledCircle filledCircle;

	/**
	 * Model
	 */
	private DrawingModel model;

	/**
	 * Construcor
	 * 
	 * @param fprov foreground color provider
	 * @param bprov background color provider
	 * @param model model
	 */
	public FilledCircleTool(IColorProvider fprov, IColorProvider bprov, DrawingModel model) {
		this.fprov = fprov;
		this.bprov = bprov;
		this.model = model;
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		if (firstClick) {
			start = e.getPoint();
			firstClick = false;
		} else {
			end = e.getPoint();

			filledCircle = new FilledCircle(start, end, fprov.getCurrentColor(), bprov.getCurrentColor());
			model.add(filledCircle);
			firstClick = true;
			model.remove(filledCircle);
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {

		if (!firstClick) {
			model.remove(filledCircle);
			end = e.getPoint();

			filledCircle = new FilledCircle(start, end, fprov.getCurrentColor(), bprov.getCurrentColor());
			model.add(filledCircle);

		}

	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void paint(Graphics2D g2d) {
		this.g2d = g2d;
	}

}
