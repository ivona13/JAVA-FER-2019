package hr.fer.zemris.java.hw17.jvdraw.editors;

/**
 * This class is used to model geometrical object editor - each object has its own editor.
 */
import javax.swing.JPanel;

public abstract class GeometricalObjectEditor extends JPanel {
	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method is used to check correction of values of editing.
	 */
	public abstract void checkEditing();

	/**
	 * This method is used for doing new changes.
	 */
	public abstract void acceptEditing();
}