package hr.fer.zemris.java.hw17.jvdraw.tools;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

/**
 * This class is used as Tool interface
 * 
 * @author ivona
 *
 */
public interface Tool {

	/**
	 * This method is called when mouse is pressed.
	 * 
	 * @param e event
	 */
	public void mousePressed(MouseEvent e);

	/**
	 * This method is callend when mouse is released-
	 * 
	 * @param e event
	 */
	public void mouseReleased(MouseEvent e);

	/**
	 * This method is called when mouse is clicked.
	 * 
	 * @param e event
	 */
	public void mouseClicked(MouseEvent e);

	/**
	 * This method is called when mouse is moved.
	 * 
	 * @param e event
	 */
	public void mouseMoved(MouseEvent e);

	/**
	 * This method is called when mouse is dragged.
	 * 
	 * @param e event
	 */
	public void mouseDragged(MouseEvent e);

	/**
	 * This method is used for painting.
	 * 
	 * @param g2d graphics2d
	 */
	public void paint(Graphics2D g2d);
}
