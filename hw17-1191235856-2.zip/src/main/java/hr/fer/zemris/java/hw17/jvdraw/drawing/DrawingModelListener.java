package hr.fer.zemris.java.hw17.jvdraw.drawing;

/**
 * This class is used as interface of drawing model listener.
 * 
 * @author ivona
 *
 */
public interface DrawingModelListener {

	/**
	 * This method is used for adding objects to model
	 * 
	 * @param source source of objects
	 * @param index0 start index
	 * @param index1 end index
	 */
	public void objectsAdded(DrawingModel source, int index0, int index1);

	/**
	 * This method is used for removing objects from model.
	 * 
	 * @param source source of objects
	 * @param index0 start index
	 * @param index1 end index
	 */
	public void objectsRemoved(DrawingModel source, int index0, int index1);

	/**
	 * This method is used for changing objects from model.
	 * 
	 * @param source source of objects
	 * @param index0 start index
	 * @param index1 end index
	 */
	public void objectsChanged(DrawingModel source, int index0, int index1);
}