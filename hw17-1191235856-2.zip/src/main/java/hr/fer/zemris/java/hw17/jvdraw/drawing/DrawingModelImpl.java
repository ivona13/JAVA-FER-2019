package hr.fer.zemris.java.hw17.jvdraw.drawing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import hr.fer.zemris.java.hw17.jvdraw.objects.GeometricalObject;

/**
 * This class is used for implementing drawing model.
 * 
 * @author ivona
 *
 */
public class DrawingModelImpl implements DrawingModel {

	/**
	 * This list stores Geometrical objects of drawing model.
	 */
	private List<GeometricalObject> geometricalObjects = new ArrayList<>();

	/**
	 * This list stores drawing model listeners
	 */
	private List<DrawingModelListener> listeners = new ArrayList<DrawingModelListener>();

	/**
	 * Modification flag
	 */
	private boolean modificationFlag = false;

	@Override
	public int getSize() {
		return geometricalObjects.size();
	}

	@Override
	public GeometricalObject getObject(int index) {
		return geometricalObjects.get(index);
	}

	@Override
	public void add(GeometricalObject object) {
		geometricalObjects.add(object);
		object.addGeometricalObjectListener(this);

		modificationFlag = true;

		for (DrawingModelListener listener : listeners) {
			listener.objectsAdded(this, geometricalObjects.size(), geometricalObjects.size());
		}

	}

	@Override
	public void remove(GeometricalObject object) {

		geometricalObjects.remove(object);

		modificationFlag = true;

		if (geometricalObjects.indexOf(object) != -1)
			for (DrawingModelListener listener : listeners) {
				listener.objectsRemoved(this, geometricalObjects.indexOf(object), geometricalObjects.indexOf(object));

			}
	}

	@Override
	public void changeOrder(GeometricalObject object, int offset) {
		int indexOfObject = geometricalObjects.indexOf(object);

		int newIndex = indexOfObject + offset;

		if (newIndex < 0 || newIndex > geometricalObjects.size()) {
			System.out.println("Invalid offset - out of bounds.");
			return;
		}

		Collections.swap(geometricalObjects, indexOfObject, newIndex);
		for (DrawingModelListener listener : listeners) {
			listener.objectsChanged(this, indexOfObject, newIndex);
		}

		modificationFlag = true;

	}

	@Override
	public int indexOf(GeometricalObject object) {
		return geometricalObjects.indexOf(object);
	}

	@Override
	public void clear() {
		geometricalObjects.clear();
		modificationFlag = true;
	}

	@Override
	public void clearModifiedFlag() {

		modificationFlag = false;
	}

	@Override
	public boolean isModified() {
		return modificationFlag;
	}

	@Override
	public void addDrawingModelListener(DrawingModelListener l) {

		if (listeners.contains(l)) {
			return;
		}

		listeners.add(l);
	}

	@Override
	public void removeDrawingModelListener(DrawingModelListener l) {
		listeners.remove(l);
	}

	@Override
	public void geometricalObjectChanged(GeometricalObject o) {
		for (DrawingModelListener listener : listeners) {
			listener.objectsChanged(this, geometricalObjects.indexOf(o), geometricalObjects.indexOf(o));
		}
	}

}
