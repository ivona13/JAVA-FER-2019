package hr.fer.zemris.java.hw17.jvdraw.drawing;

import java.awt.Graphics2D;

import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;
import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;
import hr.fer.zemris.java.hw17.jvdraw.objects.Line;

/**
 * This class is used to impelement one Geometrical object visitor - this one's
 * task is to draw 2d objects.
 * 
 * @author ivona
 *
 */
public class GeometricalObjectPainter implements GeometricalObjectVisitor {

	/**
	 * Graphics
	 */
	private Graphics2D g;

	public GeometricalObjectPainter(Graphics2D g) {
		this.g = g;
	}

	@Override
	public void visit(Line line) {
		g.setColor(line.getColor());
		g.drawLine(line.getStart().x, line.getStart().y, line.getEnd().x, line.getEnd().y);
	}

	@Override
	public void visit(Circle circle) {
		g.setColor(circle.getColor());
		g.drawOval(circle.getCenter().x - circle.getRadius() / 2, circle.getCenter().y - circle.getRadius() / 2,
				circle.getRadius(), circle.getRadius());

	}

	@Override
	public void visit(FilledCircle filledCircle) {
		g.setColor(filledCircle.getfColor());
		g.drawOval(filledCircle.getCenter().x - filledCircle.getRadius() / 2,
				filledCircle.getCenter().y - filledCircle.getRadius() / 2, filledCircle.getRadius(),
				filledCircle.getRadius());

		// lets fill it
		g.setColor(filledCircle.getbColor());
		g.fillOval(filledCircle.getCenter().x - filledCircle.getRadius() / 2,
				filledCircle.getCenter().y - filledCircle.getRadius() / 2, filledCircle.getRadius(),
				filledCircle.getRadius());

	}

}
