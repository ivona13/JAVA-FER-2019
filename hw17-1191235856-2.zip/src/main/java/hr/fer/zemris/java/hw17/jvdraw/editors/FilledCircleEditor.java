package hr.fer.zemris.java.hw17.jvdraw.editors;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Point;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;

/**
 * This class is used to implement filled circle editor.
 * 
 * @author ivona
 *
 */
public class FilledCircleEditor extends GeometricalObjectEditor {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * JSpinner for x
	 */
	private JSpinner x;

	/**
	 * 
	 * JSpinner for y
	 */
	private JSpinner y;

	/**
	 * JSpinner for radius
	 */
	private JSpinner radius;

	/**
	 * JSpinner for green part of background color
	 */
	private JSpinner gColorB;

	/**
	 * Jspinner for red part of background color
	 */
	private JSpinner rColorB;

	/**
	 * JSpinner for blue part of background color
	 */
	private JSpinner bColorB;

	/**
	 * Jspinner for green part of foreground color
	 */
	private JSpinner gColorF;

	/**
	 * JSpinner for red part of foreground color
	 */
	private JSpinner rColorF;

	/**
	 * JSpinner for blue part of foreground color
	 */
	private JSpinner bColorF;

	/**
	 * filled circle that is editing now
	 */
	private FilledCircle filledCircle;

	/**
	 * Constructor
	 * 
	 * @param filledCircle filled circle
	 */
	public FilledCircleEditor(FilledCircle filledCircle) {
		this.filledCircle = filledCircle;

		this.setLayout(new BorderLayout());
		JPanel left = new JPanel(new GridLayout(4, 1));
		JPanel right = new JPanel(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();

		this.add(left, BorderLayout.WEST);
		this.add(right, BorderLayout.EAST);

		left.add(new JLabel("Center (x,y): "));
		left.add(new JLabel("Radius: "));
		left.add(new JLabel("Foregorund Color (r,g,b): "));
		left.add(new JLabel("Background Color (r,g,b): "));

		constraints.fill = GridBagConstraints.HORIZONTAL;
		constraints.gridx = 0;
		constraints.gridy = 0;
		x = new JSpinner(new SpinnerNumberModel(filledCircle.getCenter().x, 0, 2000, 1));
		right.add(x, constraints);

		constraints.gridx = 1;
		constraints.gridy = 0;
		y = new JSpinner(new SpinnerNumberModel(filledCircle.getCenter().y, 0, 2000, 1));
		right.add(y, constraints);

		constraints.gridx = 0;
		constraints.gridy = 1;
		radius = new JSpinner(new SpinnerNumberModel(filledCircle.getRadius(), 1, 1000, 1));
		right.add(radius, constraints);

		constraints.gridx = 0;
		constraints.gridy = 2;
		rColorF = new JSpinner(new SpinnerNumberModel(filledCircle.getfColor().getRed(), 0, 255, 1));
		right.add(rColorF, constraints);

		constraints.gridx = 1;
		constraints.gridy = 2;
		gColorF = new JSpinner(new SpinnerNumberModel(filledCircle.getfColor().getGreen(), 0, 255, 1));
		right.add(gColorF, constraints);

		constraints.gridx = 2;
		constraints.gridy = 2;
		bColorF = new JSpinner(new SpinnerNumberModel(filledCircle.getfColor().getBlue(), 0, 255, 1));
		right.add(bColorF, constraints);

		constraints.gridx = 0;
		constraints.gridy = 3;
		rColorB = new JSpinner(new SpinnerNumberModel(filledCircle.getbColor().getRed(), 0, 255, 1));
		right.add(rColorB, constraints);

		constraints.gridx = 1;
		constraints.gridy = 3;
		gColorB = new JSpinner(new SpinnerNumberModel(filledCircle.getbColor().getGreen(), 0, 255, 1));
		right.add(gColorB, constraints);

		constraints.gridx = 2;
		constraints.gridy = 3;
		bColorB = new JSpinner(new SpinnerNumberModel(filledCircle.getbColor().getBlue(), 0, 255, 1));
		right.add(bColorB, constraints);
	}

	@Override
	public void checkEditing() {
		// this is already cheching according to Jspinner used here-
	}

	@Override
	public void acceptEditing() {

		Point newCenter = new Point((Integer) x.getValue(), (Integer) y.getValue());
		filledCircle.setCenter(newCenter);

		Integer newRadius = (Integer) radius.getValue();
		filledCircle.setRadius(newRadius);

		Color newFColor = new Color((Integer) rColorF.getValue(), (Integer) bColorF.getValue(),
				(Integer) gColorF.getValue());
		filledCircle.setfColor(newFColor);

		Color newBColor = new Color((Integer) rColorB.getValue(), (Integer) bColorB.getValue(),
				(Integer) gColorB.getValue());
		filledCircle.setbColor(newBColor);

	}
}
