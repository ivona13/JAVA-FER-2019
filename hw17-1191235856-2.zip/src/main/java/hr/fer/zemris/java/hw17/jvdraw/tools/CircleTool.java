package hr.fer.zemris.java.hw17.jvdraw.tools;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;

import hr.fer.zemris.java.hw17.jvdraw.color.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;

/**
 * This class is used to implement circle tool.
 * 
 * @author ivona
 *
 */
public class CircleTool implements Tool {

	/**
	 * Graphics 2d
	 */
	Graphics2D g2d;

	/**
	 * Icolor provider
	 */
	private IColorProvider prov;

	/**
	 * Start point
	 */
	private Point start;

	/**
	 * End point
	 */
	private Point end;

	/**
	 * Fist click flag
	 */
	private boolean firstClick = true;

	/**
	 * Circle
	 */
	private Circle circle;

	/**
	 * Drawing model
	 */
	private DrawingModel model;

	/**
	 * Constructor
	 * 
	 * @param prov         provider
	 * @param drawingModel model
	 */
	public CircleTool(IColorProvider prov, DrawingModel drawingModel) {
		this.prov = prov;
		this.model = drawingModel;
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		if (firstClick) {
			start = e.getPoint();
			firstClick = false;

		} else {
			end = e.getPoint();
			circle = new Circle(start, end, prov.getCurrentColor());
			model.add(circle);
			firstClick = true;
			model.remove(circle);

		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		if (!firstClick) {
			model.remove(circle);
			end = e.getPoint();

			circle = new Circle(start, end, prov.getCurrentColor());
			model.add(circle);

		}

	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void paint(Graphics2D g2d) {
		this.g2d = g2d;

	}

}
