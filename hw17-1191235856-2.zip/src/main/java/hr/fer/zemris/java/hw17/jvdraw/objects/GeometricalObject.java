package hr.fer.zemris.java.hw17.jvdraw.objects;

import hr.fer.zemris.java.hw17.jvdraw.editors.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectVisitor;

/**
 * This class is used to model geometrical object.
 * 
 * @author ivona
 *
 */
public abstract class GeometricalObject {

	/**
	 * This class is used to accept visitor.
	 * 
	 * @param visitor visitor
	 */
	public abstract void accept(GeometricalObjectVisitor visitor);

	/**
	 * This method is used to create object's editor.
	 * 
	 * @return object editor
	 */
	public abstract GeometricalObjectEditor createGeometricalObjectEditor();

	/**
	 * This method is used for adding geometrical object listener to object.
	 * 
	 * @param l listener
	 */
	public abstract void addGeometricalObjectListener(GeometricalObjectListener l);

	/**
	 * This method is used for removing geometrical object listener from object-
	 * 
	 * @param l listener
	 */
	public abstract void removeGeometricalObjectListener(GeometricalObjectListener l);

}
