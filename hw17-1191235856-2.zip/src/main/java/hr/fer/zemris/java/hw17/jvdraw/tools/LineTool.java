package hr.fer.zemris.java.hw17.jvdraw.tools;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;

import hr.fer.zemris.java.hw17.jvdraw.color.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.objects.Line;

/**
 * This class is used to represent line tool
 * 
 * @author ivona
 *
 */
public class LineTool implements Tool {

	/**
	 * Graphics 2d
	 */
	Graphics2D g2d;

	/**
	 * IColor provider
	 */
	private IColorProvider prov;

	/**
	 * Start point
	 */
	private Point start;

	/**
	 * End point
	 */
	private Point end;

	/**
	 * First click flag
	 */
	private boolean firstClick = true;

	/**
	 * Model
	 */
	private DrawingModel model;

	/**
	 * Line
	 */
	private Line line = null;

	/**
	 * Line tool constructor
	 * 
	 * @param prov  provider
	 * @param model model
	 */
	public LineTool(IColorProvider prov, DrawingModel model) {
		this.prov = prov;
		this.model = model;
	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {

		if (firstClick) {
			start = e.getPoint();
			firstClick = false;

		} else {
			end = e.getPoint();

			line = new Line(start, end, prov.getCurrentColor());
			model.add(line);
			firstClick = true;
			model.remove(line);
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {

		if (!firstClick) {
			model.remove(line);
			end = e.getPoint();
			line = new Line(start, end, prov.getCurrentColor());
			model.add(line);

		}

	}

	@Override
	public void mouseDragged(MouseEvent e) {

	}

	@Override
	public void paint(Graphics2D g2d) {
		this.g2d = g2d;

	}

}
