package hr.fer.zemris.java.hw17.jvdraw.objects;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw17.jvdraw.editors.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.editors.LineEditor;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectVisitor;

/**
 * This class is used to implement geometrical object line.
 * 
 * @author ivona
 *
 */
public class Line extends GeometricalObject {

	/**
	 * List of listeners
	 */
	private List<GeometricalObjectListener> listeners = new ArrayList<>();

	/**
	 * Start point
	 */
	private Point start;

	/**
	 * End point
	 */
	private Point end;

	/**
	 * Color
	 */
	private Color color;

	/**
	 * Constructor
	 * 
	 * @param start start
	 * @param end   end
	 * @param color color
	 */
	public Line(Point start, Point end, Color color) {
		this.start = start;
		this.end = end;
		this.color = color;
	}

	@Override
	public void accept(GeometricalObjectVisitor v) {
		v.visit(this);
	}

	@Override
	public GeometricalObjectEditor createGeometricalObjectEditor() {
		return new LineEditor(this);
	}

	@Override
	public void addGeometricalObjectListener(GeometricalObjectListener l) {
		if (!listeners.contains(l)) {
			listeners.add(l);
		}

	}

	@Override
	public void removeGeometricalObjectListener(GeometricalObjectListener l) {
		listeners.remove(l);
	}

	/**
	 * Start getter
	 * 
	 * @return start
	 */
	public Point getStart() {
		return start;
	}

	/**
	 * Start setter
	 * 
	 * @param start start
	 */
	public void setStart(Point start) {
		this.start = start;
		notifyListeners();
	}

	/**
	 * End getter
	 * 
	 * @return end
	 */
	public Point getEnd() {
		return end;
	}

	/**
	 * End setter
	 * 
	 * @param end end
	 */
	public void setEnd(Point end) {
		this.end = end;
		notifyListeners();
	}

	/**
	 * Color getter
	 * 
	 * @return color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * Color setter
	 * 
	 * @param color color
	 */
	public void setColor(Color color) {
		this.color = color;
		notifyListeners();
	}

	/**
	 * This method is used for notifying all listeners that object has changed.
	 */
	private void notifyListeners() {
		for (GeometricalObjectListener l : listeners) {
			l.geometricalObjectChanged(this);
		}
	}

	@Override
	public String toString() {
		return String.format("Line (%d, %d) -  (%d, %d)\r\n", start.x, start.y, end.x, end.y);
	}

}
