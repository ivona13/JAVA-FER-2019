package hr.fer.zemris.java.hw17.jvdraw.objects;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectVisitor;

/**
 * This class is used for calculating size of box.
 * 
 * @author ivona
 *
 */
public class GeometricalObjectBBCalculator implements GeometricalObjectVisitor {

	/**
	 * Left, right, top and bottom values
	 */
	private int left = Integer.MAX_VALUE, right = 0, top = 0, bottom = Integer.MAX_VALUE;

	public GeometricalObjectBBCalculator(int left, int right, int top, int bottom) {
		this.left = left;
		this.right = right;
		this.top = top;
		this.bottom = bottom;
	}

	/**
	 * Constructor
	 */
	public GeometricalObjectBBCalculator() {
	}

	@Override
	public void visit(Line line) {

		Point beginning = new Point(Math.min(line.getStart().x, line.getEnd().x),
				Math.min(line.getStart().y, line.getEnd().y));

		Dimension boxDimensions = new Dimension(Math.abs(line.getStart().x - line.getEnd().x),
				Math.abs(line.getStart().y - line.getEnd().y));

		Rectangle box = new Rectangle(beginning, boxDimensions);
		//System.out.println(beginning.toString() + "  " + boxDimensions.toString());

		checkBox(box);
	}

	@Override
	public void visit(Circle circle) {
		Point beginning = new Point(circle.getCenter().x - circle.getRadius() / 2,
				circle.getCenter().y - circle.getRadius() / 2);

		Dimension boxDimensions = new Dimension(circle.getRadius(), circle.getRadius());
		Rectangle box = new Rectangle(beginning, boxDimensions);

		checkBox(box);
	}

	@Override
	public void visit(FilledCircle filledCircle) {

		Point beginning = new Point(filledCircle.getCenter().x - filledCircle.getRadius() / 2,
				filledCircle.getCenter().y - filledCircle.getRadius() / 2);

		Dimension boxDimensions = new Dimension(filledCircle.getRadius(), filledCircle.getRadius());
		Rectangle box = new Rectangle(beginning, boxDimensions);

		checkBox(box);
	}

	/**
	 * This method is used for checking bounds of box.
	 * 
	 * @param box
	 */
	private void checkBox(Rectangle box) {

		if (left > box.x) {
			left = box.x;
		}

		if (right < box.x + box.width) {
			right = box.x + box.width;
		}

		if (top < box.y) {
			top = box.y;
		}

		if (bottom > box.y + box.height) {
			bottom = box.y + box.height;
		}

	}

	/**
	 * Box getter
	 * 
	 * @return box values
	 */
	public Rectangle getBox() {

		if (left == Integer.MAX_VALUE) {
			left = 0;
		}

		if (top == Integer.MAX_VALUE) {
			top = 0;
		}

		return new Rectangle(left, top, right - left, bottom - top);

	}

}
