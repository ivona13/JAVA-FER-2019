package hr.fer.zemris.java.hw17.jvdraw;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

import hr.fer.zemris.java.hw17.jvdraw.color.IColorProvider;
import hr.fer.zemris.java.hw17.jvdraw.color.JColorArea;
import hr.fer.zemris.java.hw17.jvdraw.color.JColorLabel;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModel;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModelImpl;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingModelListener;
import hr.fer.zemris.java.hw17.jvdraw.drawing.DrawingObjectListModel;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectPainter;
import hr.fer.zemris.java.hw17.jvdraw.drawing.JDrawingCanvas;
import hr.fer.zemris.java.hw17.jvdraw.editors.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.objects.Circle;
import hr.fer.zemris.java.hw17.jvdraw.objects.FilledCircle;
import hr.fer.zemris.java.hw17.jvdraw.objects.GeometricalObject;
import hr.fer.zemris.java.hw17.jvdraw.objects.GeometricalObjectBBCalculator;
import hr.fer.zemris.java.hw17.jvdraw.objects.Line;
import hr.fer.zemris.java.hw17.jvdraw.tools.CircleTool;
import hr.fer.zemris.java.hw17.jvdraw.tools.FilledCircleTool;
import hr.fer.zemris.java.hw17.jvdraw.tools.LineTool;
import hr.fer.zemris.java.hw17.jvdraw.tools.Tool;
import hr.fer.zemris.java.hw17.jvdraw.util.Util;

/**
 * This class is used for implementing JFrame used for drawing.
 * 
 * @author ivona
 *
 */
public class JVDraw extends JFrame {
	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Foreground color provider
	 */
	private IColorProvider fgColorProvider;

	/**
	 * Background color provider
	 */
	private IColorProvider bgColorProvider;

	/**
	 * List of geometrical objects
	 */
	private JList<GeometricalObject> list;

	/**
	 * Drawing model
	 */
	private DrawingModel drawingModel;

	/**
	 * Canvas used for drawinf on it
	 */
	private JDrawingCanvas canvas;

	/**
	 * Current selected tool
	 */
	private Tool currentTool;

	/**
	 * Tool for drawing line
	 */
	private Tool lineTool;

	/**
	 * Tool for drawing circle
	 */
	private Tool circleTool;

	/**
	 * Tool for drawing filled circle
	 */
	private Tool filledCircleTool;

	/**
	 * Open action
	 */
	private Action openAction;

	/**
	 * Save action
	 */
	private Action saveAction;

	/**
	 * Save as action
	 */
	private Action saveAsAction;

	/**
	 * Export action
	 */
	private Action exportAction;

	/**
	 * Exit action
	 */
	private Action exitAction;

	/**
	 * Current path
	 */
	private Path currentPath;

	/**
	 * Unsaved changes flag.
	 */
	private boolean unsavedChanges;

	/**
	 * Basic constructor
	 */
	public JVDraw() {

		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				exitAction.actionPerformed(null);
			}
		});

		setLocation(0, 0);
		setSize(1200, 600);
		setTitle("JVDraw");

		initGui();
	}

	/**
	 * This method is used for initializing graphical user interface.
	 */
	private void initGui() {
		getContentPane().setLayout(new BorderLayout());

		initToolbar();

		drawingModel = new DrawingModelImpl();

		ListModel<GeometricalObject> listModel = new DrawingObjectListModel(drawingModel);

		list = new JList<>(listModel);

		list.setFixedCellWidth((int) (getWidth() * 0.3 - 4));
		list.setVisible(true);

		list.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() != 2) {
					return;
				}
				int index = list.getSelectedIndex();
				if (index == -1) {
					return;
				}

				GeometricalObjectEditor editor = drawingModel.getObject(index).createGeometricalObjectEditor();

				if (JOptionPane.showConfirmDialog(JVDraw.this, editor, "Edit object",
						JOptionPane.YES_NO_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
					try {
						editor.checkEditing();
						editor.acceptEditing();
					} catch (Exception ex) {
						JOptionPane.showMessageDialog(JVDraw.this, "Error in object parameters!");
					}
				}
			}
		});

		list.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				int index = list.getSelectedIndex();
				if (index == -1) {
					return;
				}
				if (e.getKeyCode() == 127) {
					drawingModel.remove(drawingModel.getObject(index));
				} else if (e.getKeyCode() == 107) {
					drawingModel.changeOrder(drawingModel.getObject(index), 1);
					if ((index + 1) > list.getMaxSelectionIndex()) {
						list.setSelectedIndex(index + 1);
					}
				} else if (e.getKeyCode() == 109) {
					drawingModel.changeOrder(drawingModel.getObject(index), -1);
					if ((index - 1) < list.getMinSelectionIndex()) {
						list.setSelectedIndex(index - 1);
					}
				}
			}
		});

		JScrollPane listPane = new JScrollPane(list);

		listPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));

		getContentPane().add(listPane, BorderLayout.EAST);

		lineTool = new LineTool(fgColorProvider, drawingModel);

		circleTool = new CircleTool(fgColorProvider, drawingModel);

		filledCircleTool = new FilledCircleTool(fgColorProvider, bgColorProvider, drawingModel);

		currentTool = lineTool;

		canvas = new JDrawingCanvas(drawingModel, currentTool, (int) (getWidth() * 0.7));

		getContentPane().add(canvas, BorderLayout.WEST);

		addComponentListener(new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				canvas.setWidth((int) (getWidth() * 0.7));
				list.setFixedCellWidth((int) (getWidth() * 0.3));
			}
		});

		initializeActions();
		createActions();
		createMenus();

		drawingModel.addDrawingModelListener(new DrawingModelListener() {
			@Override
			public void objectsAdded(DrawingModel source, int index0, int index1) {
				unsavedChanges = true;
			}

			@Override
			public void objectsRemoved(DrawingModel source, int index0, int index1) {
				unsavedChanges = true;
			}

			@Override
			public void objectsChanged(DrawingModel source, int index0, int index1) {
				unsavedChanges = true;
			}
		});
	}

	/**
	 * This method is used for initializing toolbars.
	 */
	private void initToolbar() {
		JToolBar toolBar = new JToolBar();
		toolBar.setFloatable(true);

		fgColorProvider = new JColorArea(Color.RED);
		bgColorProvider = new JColorArea(Color.BLUE);
		toolBar.add((JColorArea) fgColorProvider);
		toolBar.addSeparator();
		toolBar.add((JColorArea) bgColorProvider);

		toolBar.addSeparator();
		ButtonGroup buttons = new ButtonGroup();

		JToggleButton line = new JToggleButton("Line");
		line.addActionListener(l -> {
			currentTool = lineTool;
			canvas.setCurrentTool(lineTool);
		});

		buttons.add(line);
		toolBar.add(line);

		JToggleButton circle = new JToggleButton("Circle");
		circle.addActionListener(l -> {
			currentTool = circleTool;
			canvas.setCurrentTool(circleTool);
		});
		buttons.add(circle);
		toolBar.add(circle);

		JToggleButton filledCircle = new JToggleButton("Filled circle");
		filledCircle.addActionListener(l -> {
			currentTool = filledCircleTool;
			canvas.setCurrentTool(filledCircleTool);
		});

		buttons.add(filledCircle);
		toolBar.add(filledCircle);

		line.setSelected(true);

		getContentPane().add(toolBar, BorderLayout.PAGE_START);

		JToolBar status = new JToolBar();
		status.setFloatable(true);

		JColorLabel colorLabel = new JColorLabel(fgColorProvider, bgColorProvider);

		status.add(colorLabel);

		getContentPane().add(status, BorderLayout.PAGE_END);

	}

	/**
	 * This method is used for initializing actions.
	 */
	private void initializeActions() {
		openAction = new AbstractAction() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {

				if (unsavedChanges) {
					int pressed = JOptionPane.showConfirmDialog(JVDraw.this,
							"There are unsaved changes. Do you want to save it?", "Opening",
							JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
					if (pressed == JOptionPane.YES_OPTION) {
						if (currentPath == null) {
							saveAsAction.actionPerformed(null);
						} else {
							saveAction.actionPerformed(null);
						}
					} else if (pressed == JOptionPane.CANCEL_OPTION) {
						return;
					}
				}

				JFileChooser fc = new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("JVDraw files", "jvd");
				fc.setFileFilter(filter);
				fc.setDialogTitle("Open file");
				if (fc.showOpenDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
					return;
				}
				File fileName = fc.getSelectedFile();
				Path filePath = fileName.toPath();

				try {
					List<String> lines = Files.readAllLines(filePath);

					int size = drawingModel.getSize();
					for (int i = 0; i < size; i++) {
						drawingModel.remove(drawingModel.getObject(i));
					}

					List<GeometricalObject> objects = new ArrayList<>();
					for (String line : lines) {

						if (line.startsWith("LINE")) {
							objects.add(Util.parseLine(line));
						} else if (line.startsWith("CIRCLE")) {
							objects.add(Util.parseCircle(line));
						} else if (line.startsWith("FCIRCLE")) {
							objects.add(Util.parseFCircle(line));
						} else {
							throw new RuntimeException();
						}
					}
					for (GeometricalObject object : objects) {
						drawingModel.add(object);
					}
					currentPath = filePath;
					setTitle("JVDraw " + filePath);
					unsavedChanges = false;
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(JVDraw.this, "Error while reading file " + fileName.getAbsolutePath(),
							"Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		};

		saveAction = new AbstractAction() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if (currentPath == null) {
					saveAsAction.actionPerformed(e);
					return;
				}

				StringBuilder sb = new StringBuilder();

				for (int i = 0; i < drawingModel.getSize(); i++) {
					GeometricalObject object = drawingModel.getObject(i);
					if (object instanceof Line) {
						sb.append(object.toString());
					} else if (object instanceof Circle) {
						sb.append(object.toString());
					} else if (object instanceof FilledCircle) {
						sb.append(object.toString());
					} else {
						throw new RuntimeException();
					}
				}

				try {
					Files.write(currentPath, sb.toString().getBytes(StandardCharsets.UTF_8));
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(JVDraw.this, "Error while saving" + currentPath, "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				unsavedChanges = false;
				JOptionPane.showMessageDialog(JVDraw.this, "Document saved.", "Information",
						JOptionPane.INFORMATION_MESSAGE);

			}
		};

		saveAsAction = new AbstractAction() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser jfc = new JFileChooser();
				jfc.setDialogTitle("Save document");
				FileNameExtensionFilter filter = new FileNameExtensionFilter("JVDraw files", "jvd");
				jfc.setFileFilter(filter);
				if (jfc.showSaveDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JVDraw.this, "Nothing saved.", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				Path savePath = jfc.getSelectedFile().toPath();

				String extension = savePath.toString().substring(savePath.toString().length() - 3);
				if (!extension.equals("jvd")) {
					JOptionPane.showMessageDialog(JVDraw.this, "Bad extension " + savePath, "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				if (Files.exists(savePath)) {
					int pressed = JOptionPane.showConfirmDialog(JVDraw.this,
							"File already exists. Are you sure you want to save to selected file?", "Saving",
							JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
					if (pressed == JOptionPane.NO_OPTION) {
						return;
					}
				}
				currentPath = savePath;
				setTitle("JVDraw " + savePath);
				saveAction.actionPerformed(e);
			}
		};

		exportAction = new AbstractAction() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				GeometricalObjectBBCalculator bbcalc = new GeometricalObjectBBCalculator();
				for (int i = 0; i < drawingModel.getSize(); i++) {
					GeometricalObject object = drawingModel.getObject(i);
					object.accept(bbcalc);
				}
				
				Rectangle box = bbcalc.getBox();
				BufferedImage image = new BufferedImage(box.width, box.height, BufferedImage.TYPE_3BYTE_BGR);
				Graphics2D g = image.createGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, box.width, box.height);
				g.translate(-box.x, -box.y);
				GeometricalObjectPainter painter = new GeometricalObjectPainter(g);
				for (int i = 0; i < drawingModel.getSize(); i++) {
					GeometricalObject object = drawingModel.getObject(i);
					object.accept(painter);
				}
				g.dispose();
				JFileChooser jfc = new JFileChooser();
				FileNameExtensionFilter filter = new FileNameExtensionFilter("Image files", "jpg", "png", "gif");
				jfc.setFileFilter(filter);
				jfc.setDialogTitle("Export image");
				if (jfc.showSaveDialog(JVDraw.this) != JFileChooser.APPROVE_OPTION) {
					JOptionPane.showMessageDialog(JVDraw.this, "Nothing saved.", "Warning",
							JOptionPane.WARNING_MESSAGE);
					return;
				}
				Path savePath = jfc.getSelectedFile().toPath();

				if (Files.exists(savePath)) {
					int pressed = JOptionPane.showConfirmDialog(JVDraw.this,
							"File already exists. Are you sure you want to save to selected file?", "Saving",
							JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
					if (pressed == JOptionPane.NO_OPTION) {
						return;
					}
				}
				File file = savePath.toFile();
				try {
					String extension = savePath.toString().substring(savePath.toString().length() - 3);
					if (!extension.equals("jpg") && !extension.equals("png") && !extension.equals("gif")) {
						throw new RuntimeException("Bad extension");
					}
					ImageIO.write(image, extension, file);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(JVDraw.this, "Error while saving " + savePath, "Error",
							JOptionPane.ERROR_MESSAGE);
					return;
				}

				JOptionPane.showMessageDialog(JVDraw.this, "Image saved.", "Info", JOptionPane.INFORMATION_MESSAGE);

			}

		};

		exitAction = new AbstractAction() {
			/**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			@Override
			public void actionPerformed(ActionEvent e) {
				if (unsavedChanges) {
					int pressed = JOptionPane.showConfirmDialog(JVDraw.this,
							"There are unsaved changes. Do you want to save before exiting?", "Exiting",
							JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.WARNING_MESSAGE);
					if (pressed == JOptionPane.YES_OPTION) {
						if (currentPath == null) {
							saveAsAction.actionPerformed(null);
						} else {
							saveAction.actionPerformed(null);
						}
					} else if (pressed == JOptionPane.CANCEL_OPTION) {
						return;
					}
				}

				JVDraw.this.dispose();
			}
		};
	}

	/**
	 * This method is used for creating actions.
	 */
	private void createActions() {
		openAction.putValue(Action.NAME, "Open");
		openAction.putValue(Action.SHORT_DESCRIPTION, "Open .jvd files from disk");
		openAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control O"));
		openAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_O);

		saveAction.putValue(Action.NAME, "Save");
		saveAction.putValue(Action.SHORT_DESCRIPTION, "Save drawing to disk");
		saveAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control S"));
		saveAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_S);

		saveAsAction.putValue(Action.NAME, "Save as");
		saveAsAction.putValue(Action.SHORT_DESCRIPTION, "Save drawing to disk");
		saveAsAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control W"));
		saveAsAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_W);

		exportAction.putValue(Action.NAME, "Export");
		exportAction.putValue(Action.SHORT_DESCRIPTION, "Export drawing to disk");
		exportAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control F"));
		exportAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_F);

		exitAction.putValue(Action.NAME, "Exit");
		exitAction.putValue(Action.SHORT_DESCRIPTION, "Exit from application");
		exitAction.putValue(Action.ACCELERATOR_KEY, KeyStroke.getKeyStroke("control E"));
		exitAction.putValue(Action.MNEMONIC_KEY, KeyEvent.VK_E);
	}

	/**
	 * This method is used for creating menus.
	 */
	private void createMenus() {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");

		fileMenu.add(new JMenuItem(openAction));
		fileMenu.add(new JMenuItem(saveAction));
		fileMenu.add(new JMenuItem(saveAsAction));
		fileMenu.add(new JMenuItem(exportAction));
		fileMenu.add(new JMenuItem(exitAction));

		menuBar.add(fileMenu);

		setJMenuBar(menuBar);
	}

	/**
	 * Main method.
	 *
	 * @param args Command line arguments
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new JVDraw().setVisible(true));

	}
}
