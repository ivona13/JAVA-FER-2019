package hr.fer.zemris.java.hw17.jvdraw.objects;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import hr.fer.zemris.java.hw17.jvdraw.editors.CircleEditor;
import hr.fer.zemris.java.hw17.jvdraw.editors.GeometricalObjectEditor;
import hr.fer.zemris.java.hw17.jvdraw.drawing.GeometricalObjectVisitor;

/**
 * This class is used to implement geometrical object circle.
 * 
 * @author ivona
 *
 */
public class Circle extends GeometricalObject {

	/**
	 * List of circle's listeners
	 */
	private List<GeometricalObjectListener> listeners = new ArrayList<>();

	/**
	 * Center
	 */
	private Point center;

	/**
	 * Point on its edge
	 */
	private Point end;

	/**
	 * Radius
	 */
	private int radius;

	/**
	 * Color
	 */
	private Color color;

	/**
	 * Constructor
	 * 
	 * @param center center
	 * @param radius radius
	 * @param color  color
	 */
	public Circle(Point center, int radius, Color color) {
		this.center = center;
		this.radius = radius;
		this.color = color;
	}

	/**
	 * Construcotr
	 * 
	 * @param center center
	 * @param end    end
	 * @param color  color
	 */
	public Circle(Point center, Point end, Color color) {
		this.center = center;
		this.end = end;
		this.color = color;

		this.radius = (int) Math.sqrt(Math.pow(end.x - center.x, 2) + Math.pow(end.y - center.y, 2));
	}

	@Override
	public void accept(GeometricalObjectVisitor v) {
		v.visit(this);

	}

	@Override
	public GeometricalObjectEditor createGeometricalObjectEditor() {
		return new CircleEditor(this);
	}

	@Override
	public void addGeometricalObjectListener(GeometricalObjectListener l) {
		if (!listeners.contains(l)) {
			listeners.add(l);
		}

	}

	@Override
	public void removeGeometricalObjectListener(GeometricalObjectListener l) {
		listeners.remove(l);

	}

	/**
	 * Center getter
	 * 
	 * @return color
	 */
	public Point getCenter() {
		return center;
	}

	/**
	 * End point getter
	 * 
	 * @return end point
	 */
	public Point getEnd() {
		return end;
	}

	/**
	 * Radius getter
	 * 
	 * @return radius
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * Color getter
	 * 
	 * @return color
	 */
	public Color getColor() {
		return color;
	}

	/**
	 * Center setter
	 * 
	 * @param center center
	 */
	public void setCenter(Point center) {
		this.center = center;
		notifyListeners();
	}

	/**
	 * End setter
	 * 
	 * @param end end
	 */
	public void setEnd(Point end) {
		this.end = end;
		notifyListeners();
	}

	/**
	 * Radius setter
	 * 
	 * @param radius radius
	 */
	public void setRadius(int radius) {
		this.radius = radius;
		notifyListeners();
	}

	/**
	 * Color setter
	 * 
	 * @param color color
	 */
	public void setColor(Color color) {
		this.color = color;
		notifyListeners();
	}

	/**
	 * This method is used for notifying all listeners about changes of object
	 */
	private void notifyListeners() {
		for (GeometricalObjectListener listener : listeners) {
			listener.geometricalObjectChanged(this);
		}
	}

	@Override
	public String toString() {
		return String.format("Circle (%d, %d), %d\n", center.x, center.y, radius);
	}

}
