package hr.fer.zemris.java.servleti;

/**
 * This class is used as util class to contain sin and cos of some number.
 * 
 * @author ivona
 *
 */
public class SinCos {

	/**
	 * Value
	 */
	int value;

	/**
	 * sin(value)
	 */
	double sin;

	/**
	 * cos(value)
	 */
	double cos;

	/**
	 * Constructor
	 * 
	 * @param value value
	 */
	public SinCos(int value) {
		this.value = value;
		this.sin = Math.sin(Math.toRadians(value));
		this.cos = Math.cos(Math.toRadians(value));
	}

	/**
	 * Value getter
	 * 
	 * @return value
	 */
	public int getValue() {
		return value;
	}

	/**
	 * Sin getter
	 * 
	 * @return sin
	 */
	public double getSin() {
		return sin;
	}

	/**
	 * Cos getter
	 * 
	 * @return cos
	 */
	public double getCos() {
		return cos;
	}

}
