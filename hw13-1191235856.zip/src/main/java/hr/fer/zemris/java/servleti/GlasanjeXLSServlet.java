package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * This class is used for generating spreadsheet of result of voting (with
 * .xls).
 * 
 * @author ivona
 *
 */
@WebServlet(name = "glasanje-xls", urlPatterns = "/glasanje-xls")
public class GlasanjeXLSServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("application/octet-stream");
		resp.setHeader("Content-Disposition", "attachment;filename=rezultati.xls");

		HSSFWorkbook hwb = createTable(GlasanjeRezultatiServlet.getOrder(req));

		hwb.write(resp.getOutputStream());
		resp.getOutputStream().flush();
	}

	/**
	 * This method is used for creating spreadsheet of result.
	 * 
	 * @param order Result to generate sheet based on
	 * @return {@link HSSFWorkbook}
	 */
	private HSSFWorkbook createTable(List<Band> order) {
		HSSFWorkbook hwb = new HSSFWorkbook();

		HSSFSheet sheet = hwb.createSheet("Rezultati");
		HSSFRow rowhead = sheet.createRow((short) 0);
		rowhead.createCell((short) 0).setCellValue("Bend");
		rowhead.createCell((short) 1).setCellValue("Broj glasova");

		int rowNumber = 1;

		for (Band band : order) {

			HSSFRow row = sheet.createRow((short) rowNumber);

			row.createCell((short) 0).setCellValue(band.getName());
			row.createCell((short) 1).setCellValue(band.getVotesNumber());
			rowNumber++;
		}

		return hwb;

	}

}
