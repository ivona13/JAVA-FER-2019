package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class is used for generating result of voting.
 * 
 * @author ivona
 *
 */
@WebServlet(name = "glasanje-rezultati", urlPatterns = "/glasanje-rezultati")
public class GlasanjeRezultatiServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<Band> bands = getOrder(req);

		List<Band> best = new ArrayList<Band>();
		Band first = bands.get(0);
		best.add(first);

		// lets check if there are more bands with same votes
		for (int i = 1; i < bands.size(); i++) {
			if (first.getVotesNumber().equals(bands.get(i).getVotesNumber())) {
				best.add(bands.get(i));
			}
		}

		req.setAttribute("bands", bands);
		req.setAttribute("best", best);
		req.getRequestDispatcher("/WEB-INF/pages/glasanjeRez.jsp").forward(req, resp);
	}

	/**
	 * This method is used for generating result of voting.
	 * 
	 * @param req {@link HttpServletRequest}
	 * @return sorted list of result of voting
	 * @throws IOException if error occure
	 */
	public static List<Band> getOrder(HttpServletRequest req) throws IOException {
		String defFile = req.getServletContext().getRealPath("/WEB-INF/glasanje-definicija.txt");
		List<String> lines = Files.readAllLines(Paths.get(defFile));

		List<Band> bands = new ArrayList<Band>();

		for (String line : lines) {
			String[] parts = line.split("\\t");
			bands.add(new Band(parts[0], parts[1], parts[2]));
		}

		String file = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");

		if (!Files.exists(Paths.get(file))) {
			Files.createFile(Paths.get(file));
		}

		lines = Files.readAllLines(Paths.get(file));

		List<Band> sorted = new ArrayList<Band>();
		for (String line : lines) {
			String[] parts = line.split("\\t");
			// int votes = Integer.parseInt(parts[1]);
			String name = "";
			String link = "";

			for (Band band : bands) {
				if (band.getId().equals(parts[0])) {
					name = band.getName();
					link = band.getLink();
				}
			}
			sorted.add(new Band(parts[0], name, link, parts[1]));

		}

		// lets sort bands by its number of votes
		Collections.sort(sorted, new Comparator<Band>() {

			@Override
			public int compare(Band o1, Band o2) {
				Integer obj1 = Integer.parseInt(o1.getVotesNumber());
				Integer obj2 = Integer.parseInt(o2.getVotesNumber());
				if (obj1.intValue() <= obj2.intValue()) {
					return 1;
				}
				return -1;
			}

		});

		return sorted;
	}
}
