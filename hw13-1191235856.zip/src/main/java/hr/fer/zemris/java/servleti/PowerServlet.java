package hr.fer.zemris.java.servleti;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 * This class is used to output powers of selected numbers into spreadsheet.
 * 
 * @author ivona
 *
 */
@WebServlet(name = "powers", urlPatterns = "/powers")
public class PowerServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1769984080470598097L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		int a = 0, b = 0, n = 0;

		try {

			a = Integer.parseInt(req.getParameter("a"));

		} catch (NumberFormatException ex) {
		}

		try {

			b = Integer.parseInt(req.getParameter("b"));

		} catch (NumberFormatException ex) {
		}

		try {

			n = Integer.parseInt(req.getParameter("n"));

		} catch (NumberFormatException ex) {
		}

		if (a < -100 || a > 100 || b < -100 || b > 100 || n < 1 || n > 5) {
			req.setAttribute("message", "Invalid parameters.");
			req.getRequestDispatcher("/WEB-INF/pages/error.jsp").forward(req, resp);
			return;
		}

		resp.setContentType("application/octet-stream");

		resp.setHeader("Content-Disposition", "attachment; filename=\"tablica.xls\"");

		HSSFWorkbook hwb = createTable(a, b, n);

		hwb.write(resp.getOutputStream());
		resp.getOutputStream().flush();

	}

	/**
	 * This method is used to generate {@link HSSFWorkbook} which contains powers of
	 * numbers in range of a to b
	 * 
	 * @param a lower limit
	 * @param b upper limit
	 * @param n powers from 1 to n
	 * @return {@link HSSFWorkbook}
	 */
	public HSSFWorkbook createTable(int a, int b, int n) {
		HSSFWorkbook hwb = new HSSFWorkbook();

		for (int i = 1; i <= n; i++) {

			int rowNumber = 1;
			HSSFSheet sheet = hwb.createSheet("Number to the power of " + i);
			HSSFRow rowhead = sheet.createRow((short) 0);
			rowhead.createCell((short) 0).setCellValue("x");
			rowhead.createCell((short) 1).setCellValue("x^" + i);

			for (int j = a; j <= b; j++) {
				HSSFRow row = sheet.createRow((short) rowNumber);

				row.createCell((short) 0).setCellValue((int) j);
				row.createCell((short) 1).setCellValue((int) Math.pow(j, i));
				rowNumber++;
			}
		}
		return hwb;

	}
}