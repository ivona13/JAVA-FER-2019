package hr.fer.zemris.java.servleti;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class is used to represent voting servlet. It is used for voting for the
 * band.
 * 
 * @author ivona
 *
 */
@WebServlet(name = "glasanje-glasaj", urlPatterns = "/glasanje-glasaj")
public class GlasanjeGlasajServlet extends HttpServlet {

	/**
	 * Default UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// Record vote...
		String file = req.getServletContext().getRealPath("/WEB-INF/glasanje-rezultati.txt");
		Path path = Paths.get(file);

		if (!Files.exists(path)) {
			Files.createFile(path);
		}

		String id = req.getParameter("id");

		List<String> lines = Files.readAllLines(path);

		List<Band> list = new ArrayList<Band>();
		for (String line : lines) {
			String[] parts = line.split("\\t");

			int votes = Integer.parseInt(parts[1]);

			if (parts[0].equals(id)) {
				votes++;
			}
			list.add(new Band(parts[0], null, null, Integer.toString(votes)));

		}

		StringBuilder sb = new StringBuilder();
		for (Band band : list) {
			sb.append(band.getId()).append("\t").append(band.getVotesNumber()).append("\n");
		}
		sb.setLength(sb.length() - 1);
		// System.out.println(sb.toString());

		OutputStream os = Files.newOutputStream(Paths.get(file));
		os.write(sb.toString().getBytes());

		resp.sendRedirect(req.getContextPath() + "/glasanje-rezultati");

	}

}
