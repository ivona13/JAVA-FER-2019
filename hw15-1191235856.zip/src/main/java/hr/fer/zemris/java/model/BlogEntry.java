package hr.fer.zemris.java.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
/**
 * This class is used to model Blog Entries.
 * 
 * @author ivona
 *
 */
@Entity
@Table(name = "blog_entries")
@Cacheable()
public class BlogEntry {

	/**
	 * Entry id
	 */
	private Long id;

	/**
	 * List of comments
	 */
	private List<BlogComment> comments = new ArrayList<>();

	/**
	 * Date of creation
	 */
	private Date createdAt;

	/**
	 * Date of last modification
	 */
	private Date lastModifiedAt;

	/**
	 * Title of entry
	 */
	private String title;

	/**
	 * Text of entry
	 */
	private String text;

	/**
	 * Creator of entry
	 */
	private BlogUser creator;

	/**
	 * id getter
	 *
	 * @return id
	 */
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	/**
	 * Comments getter
	 *
	 * @return Comments
	 */
	@OneToMany(mappedBy = "blogEntry", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, orphanRemoval = true)
	@OrderBy("postedOn")
	public List<BlogComment> getComments() {
		return comments;
	}

	/**
	 * Date of creation getter
	 *
	 * @return Date of creation
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	public Date getCreatedAt() {
		return createdAt;
	}

	/**
	 * Last modification date getter
	 *
	 * @return Last modification date
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	public Date getLastModifiedAt() {
		return lastModifiedAt;
	}

	/**
	 * Title getter
	 *
	 * @return title
	 */
	@Column(length = 200, nullable = false)
	public String getTitle() {
		return title;
	}

	/**
	 * Text getter
	 *
	 * @return text
	 */
	@Column(length = 4096, nullable = false)
	public String getText() {
		return text;
	}

	/**
	 * Creatior getter
	 *
	 * @return Creator
	 */
	@ManyToOne
	@JoinColumn(nullable = false)
	public BlogUser getCreator() {
		return creator;
	}

	/**
	 * Id setter
	 *
	 * @param id id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Comments setter
	 *
	 * @param comments Comments
	 */
	public void setComments(List<BlogComment> comments) {
		this.comments = comments;
	}

	/**
	 * Date of creation setter
	 *
	 * @param createdAt Date of creation
	 */
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	/**
	 * Last modification Date setter
	 *
	 * @param lastModifiedAt Last modification Date
	 */
	public void setLastModifiedAt(Date lastModifiedAt) {
		this.lastModifiedAt = lastModifiedAt;
	}

	/**
	 * Title setter
	 *
	 * @param title Title
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Text setter
	 *
	 * @param text Text
	 */
	public void setText(String text) {
		this.text = text;
	}

	/**
	 * Creatior setter
	 *
	 * @param creator Creator
	 */
	public void setCreator(BlogUser creator) {
		this.creator = creator;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		BlogEntry blogEntry = (BlogEntry) o;
		return Objects.equals(id, blogEntry.id);
	}

	@Override
	public int hashCode() {

		return Objects.hash(id);
	}
}