package hr.fer.zemris.java.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;

import hr.fer.zemris.java.dao.DAO;
import hr.fer.zemris.java.dao.DAOException;
import hr.fer.zemris.java.model.BlogComment;
import hr.fer.zemris.java.model.BlogEntry;
import hr.fer.zemris.java.model.BlogUser;

/**
 * This class is used to implement {@link DAO}. It enables communication with
 * database.
 * 
 * @author ivona
 *
 */
public class JPADAOImpl implements DAO {

	@Override
	public BlogEntry getBlogEntry(Long id) throws DAOException {
		BlogEntry blogEntry = JPAEMProvider.getEntityManager().find(BlogEntry.class, id);
		return blogEntry;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BlogUser> getBlogUsers() {
		List<BlogUser> list = (List<BlogUser>) JPAEMProvider.getEntityManager()
				.createQuery("select b from BlogUser as b").getResultList();
		JPAEMProvider.close();
		return list;
	}

	@Override
	public BlogUser getBlogUserByNick(String nick) {
		BlogUser blogUser = new BlogUser();

		blogUser = null;
		try {
			blogUser = (BlogUser) JPAEMProvider.getEntityManager()
					.createQuery("select u from BlogUser as u where u.nick=:nick").setParameter("nick", nick)
					.getSingleResult();
		} catch (NoResultException ex) {
		}
		JPAEMProvider.close();
		return blogUser;
	}

	@Override
	public void createNewBlogUser(BlogUser blogUser) {
		JPAEMProvider.getEntityManager().persist(blogUser);
		JPAEMProvider.close();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<BlogEntry> getEntriesOfUser(BlogUser blogUser) {

		EntityManager em = JPAEMProvider.getEntityManager();
		List<BlogEntry> entries = null;
		try {
			entries = (List<BlogEntry>) em.createQuery("select u from BlogEntry u where u.creator=:creator")
					.setParameter("creator", blogUser).getResultList();
		} catch (NoResultException e) {
		}
		JPAEMProvider.close();
		return entries;
	}

	@Override
	public void createNewBlogEntry(BlogEntry blogEntry) {
		JPAEMProvider.getEntityManager().persist(blogEntry);
		JPAEMProvider.close();
	}

	@Override
	public void addNewComment(BlogComment blogComment) {
		JPAEMProvider.getEntityManager().persist(blogComment);
		JPAEMProvider.close();
	}

}