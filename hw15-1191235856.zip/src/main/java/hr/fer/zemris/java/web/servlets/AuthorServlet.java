package hr.fer.zemris.java.web.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogEntry;
import hr.fer.zemris.java.model.BlogUser;

/**
 * This class is used to represent servlet whose task is to enable
 * "communication" with user.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/author/*")
public class AuthorServlet extends HttpServlet {

	/**
	 * Default serial Version
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// immidiately here enable watching others blogs
		req.setAttribute("users", DAOProvider.getDAO().getBlogUsers());

		String pathInfo = req.getPathInfo().substring(1);

		String[] parts = pathInfo.split("/");

		if (parts.length == 1) {
			String nick = parts[0];
			req.setAttribute("nick", nick);
			listAllEntries(req, resp, nick);
		}

		if (parts.length == 2) {
			String nick = parts[0];
			req.setAttribute("nick", nick);
			String idString = parts[1];
			Long id = null;

			boolean isIdSet = false;
			try {
				id = Long.parseLong(idString);
				isIdSet = true;
			} catch (RuntimeException ex) {
			}

			if (isIdSet) {
				req.setAttribute("id", id);
				showBlogEntry(req, resp, id);
			} else {
				String string = parts[1];
				req.setAttribute("option", string);

				if (string.equals("new") || string.equals("edit")) {
					edit(req, resp, string);
				}
			}
		}

	}

	/**
	 * This method is used to edit Blog Entry whose id is given in input.
	 * 
	 * @param req    request
	 * @param resp   response
	 * @param string string id of Blog Entry to be edited
	 * @throws ServletException ServletException
	 * @throws IOException      IOException
	 */
	private void edit(HttpServletRequest req, HttpServletResponse resp, String string)
			throws ServletException, IOException {
		if (string.equals("edit")) {
			String idString = req.getParameter("id");
			Long id = null;

			if (idString != null) {
				try {
					id = Long.parseLong(idString);
				} catch (RuntimeException ex) {
				}

				if (id != null) {
					BlogEntry blogEntry = DAOProvider.getDAO().getBlogEntry(id);
					// req.setAttribute("blogEntry", blogEntry);
					req.getSession().setAttribute("blogEntry", blogEntry);
					req.getSession().setAttribute("id", id);

				}
			}

		}

		req.getRequestDispatcher("/WEB-INF/pages/BlogEntryEditor.jsp").forward(req, resp);

	}

	/**
	 * This method is used to show Blog Entry when user clicks on it. Id od Blog
	 * Entry is given in input
	 * 
	 * @param req  request
	 * @param resp response
	 * @param id   of Blog Entry
	 * @throws ServletException ServletException
	 * @throws IOException      IOException
	 */
	private void showBlogEntry(HttpServletRequest req, HttpServletResponse resp, Long id)
			throws ServletException, IOException {
		BlogEntry blogEntry = new BlogEntry();

		blogEntry = DAOProvider.getDAO().getBlogEntry(id);

		if (blogEntry != null) {
			req.setAttribute("blogEntry", blogEntry);
		}

		req.getRequestDispatcher("/WEB-INF/pages/BlogEntryPage.jsp").forward(req, resp);
	}

	/**
	 * This method is used to list all Blog Entries of Blog user whose nick name is
	 * given in input
	 * 
	 * @param req  request
	 * @param resp response
	 * @param nick nickname of Blog user
	 * @throws ServletException ServletExcetion
	 * @throws IOException      IOException
	 */
	private void listAllEntries(HttpServletRequest req, HttpServletResponse resp, String nick)
			throws ServletException, IOException {
		BlogUser user = DAOProvider.getDAO().getBlogUserByNick(nick);
		List<BlogEntry> list = DAOProvider.getDAO().getEntriesOfUser(user);
		req.setAttribute("blogEntries", list);
		req.getRequestDispatcher("/WEB-INF/pages/authorPage.jsp").forward(req, resp);

	}

}
