package hr.fer.zemris.java.dao;

import hr.fer.zemris.java.dao.jpa.JPADAOImpl;

/**
 * This class is used to implement object who return appropriate provider to
 * database.
 * 
 * @author ivona
 *
 */
public class DAOProvider {

	/**
	 * Instance of DAO
	 */
	private static DAO dao = new JPADAOImpl();

	/**
	 * DAO Instance getter
	 * 
	 * @return
	 */
	public static DAO getDAO() {
		return dao;
	}

}