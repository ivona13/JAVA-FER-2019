package hr.fer.zemris.java.dao.jpa;

import javax.persistence.EntityManager;

import hr.fer.zemris.java.dao.DAOException;

/**
 * This class is used to implement JPA Entity Manager Provider. It enables
 * access to database and writing to it.
 * 
 * @author ivona
 *
 */
public class JPAEMProvider {

	/**
	 * Local thread
	 */
	private static ThreadLocal<EntityManager> locals = new ThreadLocal<>();

	/**
	 * Entity Manager getter
	 * 
	 * @return Entity Manager
	 */
	public static EntityManager getEntityManager() {
		EntityManager em = locals.get();
		if (em == null) {
			em = JPAEMFProvider.getEmf().createEntityManager();
			em.getTransaction().begin();
			locals.set(em);
		}
		return em;
	}

	/**
	 * This method is used to commit and close Entity Manager to this thread and
	 * deletes it from local thread map.
	 * 
	 * @throws DAOException
	 */
	public static void close() throws DAOException {
		EntityManager em = locals.get();
		if (em == null) {
			return;
		}
		DAOException dex = null;
		try {
			em.getTransaction().commit();
		} catch (Exception ex) {
			dex = new DAOException("Unable to commit transaction.", ex);
		}
		try {
			em.close();
		} catch (Exception ex) {
			if (dex != null) {
				dex = new DAOException("Unable to close entity manager.", ex);
			}
		}
		locals.remove();
		if (dex != null)
			throw dex;
	}

}