package hr.fer.zemris.java.web.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogUser;
import hr.fer.zemris.java.util.Crypt;

/**
 * This class is used to implement servlet whose task is to handle register
 * process - future user has to give some informations and all of them has to be
 * correct - nicknames are unique.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/register")
public class RegisterServlet extends HttpServlet {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/register.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String firstName = req.getParameter("firstName");
		String lastName = req.getParameter("lastName");
		String nick = req.getParameter("nick");
		String email = req.getParameter("email");
		String password = req.getParameter("pass");

		boolean errorHappened = false;

		if (firstName == null || lastName == null || nick == null || email == null || password == null) {
			resp.sendError(400);
			errorHappened = true;
		}

		if (firstName.trim().isEmpty()) {
			req.getSession().setAttribute("registrationError", "Name can't be empty");
			errorHappened = true;

		}
		if (lastName.trim().isEmpty()) {
			req.getSession().setAttribute("registrationError", "Surname can't be empty");
			errorHappened = true;

		}
		if (nick.trim().isEmpty() || DAOProvider.getDAO().getBlogUserByNick(nick) != null) {
			req.getSession().setAttribute("registrationError", "Invalid nick");
			errorHappened = true;

		}
		if (password.trim().isEmpty()) {
			req.getSession().setAttribute("registrationError", "Password can't be empty");
			errorHappened = true;

		}

		if (!errorHappened) {
			BlogUser user = new BlogUser();
			user.setFirstName(firstName);
			user.setLastName(lastName);
			user.setEmail(email);
			user.setNick(nick);
			user.setPasswordHash(Crypt.crypt(password));
			DAOProvider.getDAO().createNewBlogUser(user);
			resp.sendRedirect("/blog/servleti/main");

		} else {
			doGet(req, resp);
		}

	}
}
