package hr.fer.zemris.java.dao;

/**
 * This class is used to implement possible Exceptions by DAO.
 * 
 * @author ivona
 *
 */
public class DAOException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor
	 * 
	 * @param message message
	 * @param cause   cause
	 */
	public DAOException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * Constructor
	 * 
	 * @param message message
	 */
	public DAOException(String message) {
		super(message);
	}
}