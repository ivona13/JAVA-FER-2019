package hr.fer.zemris.java.model;

import java.util.List;
import java.util.Objects;

import javax.persistence.Cacheable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * This class is used to model blog users.
 * 
 * @author ivona
 *
 */
@Entity
@Table(name = "blog_users")
@Cacheable(false)
public class BlogUser {

	/**
	 * User id
	 */
	private Long id;

	/**
	 * User first name
	 */
	private String firstName;

	/**
	 * User last name
	 */
	private String lastName;

	/**
	 * User nickname
	 */
	private String nick;

	/**
	 * User email
	 */
	private String email;

	/**
	 * User password hash
	 */
	private String passwordHash;

	/**
	 * User blog entries
	 */
	private List<BlogEntry> entries;

	/**
	 * Id getter
	 *
	 * @return id
	 */
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	/**
	 * First name getter
	 *
	 * @return First name
	 */
	@Column(length = 200, nullable = false)
	public String getFirstName() {
		return firstName;
	}

	/**
	 * Last name getter
	 *
	 * @return Last name
	 */
	@Column(length = 200, nullable = false)
	public String getLastName() {
		return lastName;
	}

	/**
	 * Nickname getter
	 *
	 * @return Nickname
	 */
	@Column(length = 200, nullable = false, unique = true)
	public String getNick() {
		return nick;
	}

	/**
	 * Email getter
	 *
	 * @return Email
	 */
	@Column(length = 200, nullable = false)
	public String getEmail() {
		return email;
	}

	/**
	 * Password hash getter
	 *
	 * @return Password hash
	 */
	@Column(length = 200, nullable = false)
	public String getPasswordHash() {
		return passwordHash;
	}

	/**
	 * User entries getter
	 *
	 * @return Entries
	 */
	@OneToMany(mappedBy = "creator", fetch = FetchType.LAZY, cascade = CascadeType.PERSIST, orphanRemoval = true)
	public List<BlogEntry> getEntries() {
		return entries;
	}

	/**
	 * Id setter
	 *
	 * @param id id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * First name setter
	 *
	 * @param firstName first name
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * Last name setter
	 *
	 * @param lastName last name
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Nickname setter
	 *
	 * @param nick Nickname
	 */
	public void setNick(String nick) {
		this.nick = nick;
	}

	/**
	 * Email setter
	 *
	 * @param email Email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Password hash setter
	 *
	 * @param passwordHash Password hash
	 */
	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	/**
	 * Blog entries setter
	 *
	 * @param entries Entries
	 */
	public void setEntries(List<BlogEntry> entries) {
		this.entries = entries;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		BlogUser blogUser = (BlogUser) o;
		return Objects.equals(id, blogUser.id);
	}

	@Override
	public int hashCode() {

		return Objects.hash(id);
	}

}
