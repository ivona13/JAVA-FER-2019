package hr.fer.zemris.java.dao.jpa;

import javax.persistence.EntityManagerFactory;

/**
 * This class provides Entity Manager Factory for out Entity Manager.
 * 
 * @author ivona
 *
 */
public class JPAEMFProvider {

	/**
	 * Entity Manager Factory
	 */
	public static EntityManagerFactory emf;

	/**
	 * Entity Manager Factory getter
	 * 
	 * @return Entity Manager Factory
	 */
	public static EntityManagerFactory getEmf() {
		return emf;
	}

	/**
	 * Entity Manager Factory setter
	 * 
	 * @param emf Entity Manager Factory
	 */
	public static void setEmf(EntityManagerFactory emf) {
		JPAEMFProvider.emf = emf;
	}
}