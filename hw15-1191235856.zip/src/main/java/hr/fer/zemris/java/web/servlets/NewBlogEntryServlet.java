package hr.fer.zemris.java.web.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogEntry;
import hr.fer.zemris.java.model.BlogUser;

/**
 * This class is used to impelemnt servlet whose task is to create new Blog
 * Entry and store it to database.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/new")
public class NewBlogEntryServlet extends HttpServlet {

	/**
	 * serialVersion UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String title = req.getParameter("title");
		String text = req.getParameter("text");
		String nick = (String) req.getSession().getAttribute("current.user.nick");

		BlogUser creator = DAOProvider.getDAO().getBlogUserByNick(nick);

		BlogEntry blogEntry = new BlogEntry();
		blogEntry.setTitle(title);
		blogEntry.setText(text);
		blogEntry.setCreatedAt(new Date());
		blogEntry.setCreator(creator);
		blogEntry.setLastModifiedAt(new Date());

		DAOProvider.getDAO().createNewBlogEntry(blogEntry);
		resp.sendRedirect("/blog/servleti/author/" + nick);
	}

}
