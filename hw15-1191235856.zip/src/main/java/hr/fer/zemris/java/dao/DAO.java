package hr.fer.zemris.java.dao;

import java.util.List;

import hr.fer.zemris.java.model.BlogComment;
import hr.fer.zemris.java.model.BlogEntry;
import hr.fer.zemris.java.model.BlogUser;

/**
 * This class is used to communicate with database.
 * 
 * @author ivona
 *
 */
public interface DAO {

	/**
	 * Dohvaća entry sa zadanim <code>id</code>-em. Ako takav entry ne postoji,
	 * vraća <code>null</code>.
	 * 
	 * @param id ključ zapisa
	 * @return entry ili <code>null</code> ako entry ne postoji
	 * @throws DAOException ako dođe do pogreške pri dohvatu podataka
	 */
	public BlogEntry getBlogEntry(Long id) throws DAOException;

	/**
	 * This method is used to get list of all users of blog.
	 * 
	 * @return list of all blog users
	 */
	public List<BlogUser> getBlogUsers();

	/**
	 * This method is used to get blog user by its nick name.
	 * 
	 * @param nick nick name to get user by it
	 * @return Blog User with appropriate nick name
	 */
	public BlogUser getBlogUserByNick(String nick);

	/**
	 * This method is used to create new Blog user in database
	 * 
	 * @param blogUser blogUser to insert to database
	 */
	public void createNewBlogUser(BlogUser blogUser);

	/**
	 * This method is used to get all Blog Entries of some blog user
	 * 
	 * @param blogUser blog user to get all blog entries written by him
	 * @return list of Blog Entries
	 */
	public List<BlogEntry> getEntriesOfUser(BlogUser blogUser);

	/**
	 * This method is used to create new blog
	 * 
	 * @param blogEntry blog Entry to be created in database
	 */
	void createNewBlogEntry(BlogEntry blogEntry);

	/**
	 * This method is used to add new comment to database
	 * 
	 * @param blogComment blogComment to be added
	 */
	void addNewComment(BlogComment blogComment);
}
