package hr.fer.zemris.java.web.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogUser;
import hr.fer.zemris.java.util.Crypt;

/**
 * This class is used to implement servlet whose task is to handle login proces.
 * It coudl accept login (if nick and password are correct), or it could give
 * appropriate message of the problem.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/login")
public class LoginServlet extends HttpServlet {

	/**
	 * serialVersionUid
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// to enable to see others blogs
		req.setAttribute("users", DAOProvider.getDAO().getBlogUsers());

		String nick = req.getParameter("nick");
		String password = req.getParameter("pass");

		if (nick == null || nick.trim() == "") {
			req.getSession().setAttribute("error", "You must provide nickname.");
		}

		if (password == null) {
			req.getSession().setAttribute("error", "You must provide password.");
		}

		BlogUser user = DAOProvider.getDAO().getBlogUserByNick(nick.trim());

		if (user == null) {
			req.getSession().setAttribute("error", "This user does not exit. Please, register first.");
		} else {
			
			if (user.getPasswordHash().equals(Crypt.crypt(password))) {
				req.getSession().setAttribute("current.user.id", user.getId());
				req.getSession().setAttribute("current.user.fn", user.getFirstName());
				req.getSession().setAttribute("current.user.ln", user.getLastName());
				req.getSession().setAttribute("current.user.nick", user.getNick());

			} else {
				req.getSession().setAttribute("error", "Password is not correct.");
			}
		}

		req.getRequestDispatcher("/WEB-INF/pages/home.jsp").forward(req, resp);

	}

}
