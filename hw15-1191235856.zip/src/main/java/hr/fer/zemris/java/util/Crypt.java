package hr.fer.zemris.java.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * This class is used as util class to implement crypting of password -
 * generating it.
 * 
 * @author ivona
 *
 */
public class Crypt {

	/**
	 * This method is used to crypt given password.
	 * 
	 * @param password password to be crypted
	 * @return hashed password
	 */
	public static String crypt(String password) {
		byte[] buff = password.getBytes();
		MessageDigest digest = null;
		try {
			digest = MessageDigest.getInstance("SHA-1");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}

		digest.update(buff, 0, buff.length);

		byte[] sum = digest.digest();

		StringBuilder sb = new StringBuilder();

		for (Byte b : sum) {
			sb.append(String.format("%02x", b));
		}

		return sb.toString();
	}
}
