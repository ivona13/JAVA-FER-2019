package hr.fer.zemris.java.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * This class is used to model Blog comments. I
 * 
 * @author ivona
 *
 */
@Entity
@Table(name = "blog_comments")
@Cacheable()
public class BlogComment {

	/**
	 * comment id
	 */
	private Long id;

	/**
	 * Entry where comment is
	 */
	private BlogEntry blogEntry;

	/**
	 * Email of user who left comment
	 */
	private String usersEMail;

	/**
	 * Comment message
	 */
	private String message;

	/**
	 * Date of posting
	 */
	private Date postedOn;

	/**
	 * Id getter
	 *
	 * @return Id
	 */
	@Id
	@GeneratedValue
	public Long getId() {
		return id;
	}

	/**
	 * Blog entry getter
	 *
	 * @return {@link BlogEntry}
	 */
	@ManyToOne
	@JoinColumn(nullable = false)
	public BlogEntry getBlogEntry() {
		return blogEntry;
	}

	/**
	 * Email getter
	 *
	 * @return email
	 */
	@Column(length = 100, nullable = false)
	public String getUsersEMail() {
		return usersEMail;
	}

	/**
	 * Message getter
	 *
	 * @return message
	 */
	@Column(length = 4096, nullable = false)
	public String getMessage() {
		return message;
	}

	/**
	 * Posted on date getter
	 *
	 * @return Posted on date
	 */
	@Temporal(TemporalType.TIMESTAMP)
	@Column(nullable = false)
	public Date getPostedOn() {
		return postedOn;
	}

	/**
	 * id setter
	 *
	 * @param id Id
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * Blog Entry setter
	 *
	 * @param blogEntry Blog entry
	 */
	public void setBlogEntry(BlogEntry blogEntry) {
		this.blogEntry = blogEntry;
	}

	/**
	 * Setter for user email.
	 *
	 * @param usersEMail User email
	 */
	public void setUsersEMail(String usersEMail) {
		this.usersEMail = usersEMail;
	}

	/**
	 * Setter for message.
	 *
	 * @param message Message
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Posted on date setter
	 * 
	 * @param postedOn Posted on date
	 */
	public void setPostedOn(Date postedOn) {
		this.postedOn = postedOn;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		BlogComment that = (BlogComment) o;
		return Objects.equals(id, that.id);
	}

	@Override
	public int hashCode() {

		return Objects.hash(id);
	}
}