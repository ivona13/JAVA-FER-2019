package hr.fer.zemris.java.web.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogComment;
import hr.fer.zemris.java.model.BlogEntry;

/**
 * This class is used implement Blog Comment servlet whose task is to enable
 * user to leave comment to some Blog.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/comment")
public class CommentServlet extends HttpServlet {

	/**
	 * Default serail Version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String idString = req.getParameter("id");
		String email = req.getParameter("email");
		String message = req.getParameter("message");

		Long id = null;

		try {
			id = Long.parseLong(idString);
		} catch (RuntimeException ex) {
		}

		if (id != null) {
			BlogComment blogComment = new BlogComment();

			blogComment.setUsersEMail(email);
			blogComment.setMessage(message);
			blogComment.setPostedOn(new Date());
			BlogEntry blogEntry = DAOProvider.getDAO().getBlogEntry(id);
			blogComment.setBlogEntry(blogEntry);
			blogEntry.getComments().add(blogComment);
		} else {
			req.getRequestDispatcher("main").forward(req, resp);
		}

		resp.sendRedirect("author/" + req.getParameter("nick") + "/" + id);
	}
}
