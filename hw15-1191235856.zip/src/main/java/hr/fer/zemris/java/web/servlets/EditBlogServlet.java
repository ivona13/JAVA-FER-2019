package hr.fer.zemris.java.web.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hr.fer.zemris.java.dao.DAOProvider;
import hr.fer.zemris.java.model.BlogEntry;

/**
 * This class is used to implement servlet whose task is to enable editing Blog
 * Entry - only for user of it.
 * 
 * @author ivona
 *
 */
@WebServlet("/servleti/edit")
public class EditBlogServlet extends HttpServlet {

	/**
	 * serial Version UID
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String text = req.getParameter("text");

		Long id = (Long) req.getSession().getAttribute("id");
		System.out.println("ID = " + id);

		System.out.println("Ovdje sam");

		if (id != null) {
			BlogEntry blogEntry = DAOProvider.getDAO().getBlogEntry(id);

			// ovdje cu zadrzati sve postojece poruke i dodati novu - takva pretpostavka da
			// blog cuva sve do sada pohranjeno
			String string = text + "\n" + blogEntry.getText();
			System.out.println(string);
			blogEntry.setText(string);
			blogEntry.setTitle(blogEntry.getTitle());
			blogEntry.setLastModifiedAt(new Date());
			blogEntry.setId(id);

		}

		resp.sendRedirect("author/" + (String) req.getSession().getAttribute("current.user.nick") + "/" + id);
	}
}
